import React, { useState } from 'react';
import type { SimulationResult } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ReferenceLine, ComposedChart } from 'recharts';
import { Card, CardContent, CardHeader } from './Card';
import { ChartIcon, LoaderIcon } from './icons';

interface ConeOfUncertaintyChartProps {
  result: SimulationResult | null;
  totalBudget?: number;
  totalPoints?: number;
  isSimulating?: boolean;
  theme?: 'light' | 'dark';
  forceTab?: 'time' | 'cost';
}

const CustomTooltip: React.FC<any> = ({ active, payload, label, deviations, activeTab }) => {
  if (active && payload && payload.length) {
    const dataPoint = payload[0].payload;
    const isTimeChart = activeTab === 'time';
    
    const data = isTimeChart ? dataPoint.time : dataPoint.cost;
    const unit = isTimeChart ? 'punten' : '€';
    const formatter = isTimeChart 
        ? (val: number) => val.toFixed(0) 
        : (val: number) => new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' }).format(val);

    const d = deviations || { optimistic: 0, pessimistic: 0 };

    return (
      <div className="bg-surface/90 backdrop-blur-sm p-3 rounded-lg border border-border-default shadow-lg">
        <p className="font-semibold text-text-primary">{`Na ${label} sprint(s)`}</p>
        <p className="text-sm text-warning">{`Optimistisch (+${d.optimistic}%): ${formatter(data.optimistic)} ${unit}`}</p>
        <p className="text-sm text-primary">{`Baseline: ${formatter(data.baseline)} ${unit}`}</p>
        <p className="text-sm text-error">{`Pessimistisch (-${d.pessimistic}%): ${formatter(data.pessimistic)} ${unit}`}</p>
        {dataPoint.actualPoints != null && isTimeChart && <p className="text-sm text-text-primary mt-1 pt-1 border-t border-border-default">{`Historisch: ${formatter(dataPoint.actualPoints)} punten`}</p>}
        {dataPoint.actualCost != null && !isTimeChart && <p className="text-sm text-text-primary mt-1 pt-1 border-t border-border-default">{`Historisch: ${formatter(dataPoint.actualCost)}`}</p>}
      </div>
    );
  }
  return null;
};

const ConeOfUncertaintyChart: React.FC<ConeOfUncertaintyChartProps> = ({ result, totalBudget, totalPoints, isSimulating, theme = 'light', forceTab }) => {
  const [internalTab, setInternalTab] = useState<'time' | 'cost'>('time');
  
  const activeTab = forceTab || internalTab;

  const deviations = result?.usedDeviations;
  const chartData = result?.timeSeries || [];
  
  const renderChart = (type: 'time' | 'cost') => {
    const isTime = type === 'time';
    const dataKeys = isTime 
      ? { optimistic: 'time.optimistic', baseline: 'time.baseline', pessimistic: 'time.pessimistic', actual: 'actualPoints' } 
      : { optimistic: 'cost.optimistic', baseline: 'cost.baseline', pessimistic: 'cost.pessimistic', actual: 'actualCost' };
    
    const yAxisLabel = isTime ? "Voltooide Punten" : "Gemaakte Kosten";
    const yAxisUnit = isTime ? "" : "€";
    const currencyFormatter = (value: number) => new Intl.NumberFormat('nl-NL', { notation: 'compact', compactDisplay: 'short' }).format(value);
    
    return (
        <div className="h-96 w-full">
            <ResponsiveContainer>
              <ComposedChart data={chartData} margin={{ top: 10, right: 30, left: 20, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" strokeOpacity={0.4} />
                <XAxis dataKey="sprint" name="Sprint" unit="" allowDecimals={false} tick={{ fill: 'var(--color-text-secondary)' }} />
                <YAxis 
                    label={{ value: yAxisLabel, angle: -90, position: 'insideLeft', offset: -10, fill: 'var(--color-text-primary)' }} 
                    unit={yAxisUnit} 
                    tickFormatter={isTime ? undefined : currencyFormatter}
                    domain={[0, 'dataMax']}
                    tick={{ fill: 'var(--color-text-secondary)' }}
                />
                <Tooltip content={<CustomTooltip deviations={deviations} activeTab={activeTab} />} />
                <Legend wrapperStyle={{ color: 'var(--color-text-primary)' }} />
                <defs>
                  <linearGradient id="colorUncertainty" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-primary-main)" stopOpacity={theme === 'dark' ? 0.4 : 0.3}/>
                    <stop offset="95%" stopColor="var(--color-primary-main)" stopOpacity={theme === 'dark' ? 0.1 : 0.05}/>
                  </linearGradient>
                </defs>
                <Area 
                    type="monotone" 
                    dataKey={(data) => [data[type].pessimistic, data[type].optimistic]} 
                    stroke="none" 
                    fill="url(#colorUncertainty)" 
                    name={`Onzekerheidsmarge`} 
                />
                <Line type="monotone" dataKey={dataKeys.optimistic} stroke="var(--color-warning-main)" strokeWidth={2} dot={false} name={`Optimistisch (+${deviations?.optimistic}%)`} />
                <Line type="monotone" dataKey={dataKeys.pessimistic} stroke="var(--color-error-main)" strokeWidth={2} dot={false} name={`Pessimistisch (-${deviations?.pessimistic}%)`} />
                <Line type="monotone" dataKey={dataKeys.baseline} stroke="var(--color-primary-main)" strokeWidth={3} dot={false} name="Baseline (Gemiddelde)" strokeDasharray="5 5" />
                <Line type="monotone" dataKey={dataKeys.actual} stroke={'var(--color-text-primary)'} strokeWidth={3} dot={{ r: 4, fill: 'var(--color-text-primary)' }} activeDot={{ r: 6 }} name="Historisch" connectNulls={false} />

                {isTime && totalPoints && totalPoints > 0 && (
                  <ReferenceLine y={totalPoints} label={{ value: 'Totale Scope', position: 'insideTopLeft', fill: 'var(--color-text-primary)' }} stroke="var(--color-primary-main)" strokeDasharray="3 3" strokeWidth={2} />
                )}
                {!isTime && totalBudget && totalBudget > 0 && (
                  <ReferenceLine y={totalBudget} label={{ value: 'Totaal Budget', position: 'insideTopLeft', fill: 'var(--color-text-primary)' }} stroke="var(--color-error-main)" strokeDasharray="3 3" strokeWidth={2} />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
    )
  }

  return (
    <Card>
      <CardHeader icon={<ChartIcon className="w-6 h-6" />}>
        <div className="flex justify-between items-center w-full">
            {forceTab ? `Prognose: ${forceTab === 'time' ? 'Tijd' : 'Budget'}` : 'Prognose: Tijd & Budget'}
            {!forceTab && (
              <div className="flex items-center gap-1 bg-background p-1 rounded-lg">
                  <button onClick={() => setInternalTab('time')} className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${activeTab === 'time' ? 'bg-surface dark:bg-black/20 text-primary shadow-sm' : 'text-text-secondary hover:bg-black/5 dark:hover:bg-white/5'}`}>Tijd</button>
                  <button onClick={() => setInternalTab('cost')} className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${activeTab === 'cost' ? 'bg-surface dark:bg-black/20 text-primary shadow-sm' : 'text-text-secondary hover:bg-black/5 dark:hover:bg-white/5'}`}>Budget</button>
              </div>
            )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
             {isSimulating && !forceTab && (
                <div className="absolute inset-0 bg-surface/60 backdrop-blur-sm flex items-center justify-center z-10 rounded-xl">
                    <div className="flex items-center gap-2 text-text-secondary">
                        <LoaderIcon className="w-5 h-5" />
                        <span>Prognose berekenen...</span>
                    </div>
                </div>
            )}
            
            {renderChart(activeTab)}

            {(!result || result.timeSeries.length <= 1) && !isSimulating && (
              <div className="absolute inset-0 flex items-center justify-center text-center text-text-secondary/80 px-4 pointer-events-none">
                <p>Pas de resultaten van een sprint aan om de prognose te genereren.</p>
              </div>
            )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ConeOfUncertaintyChart;