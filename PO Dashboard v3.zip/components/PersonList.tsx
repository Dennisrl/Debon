

import React, { useMemo } from 'react';
import type { Person, WorkPattern } from '../types';
import { Card, CardContent } from './Card';
import { EditIcon, TrashIcon } from './icons';

const calculateAverageHours = (pattern: WorkPattern): number => {
    if (pattern.type === 'even-odd' && pattern.evenWeekHours && pattern.oddWeekHours) {
        const even = Object.values(pattern.evenWeekHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
        const odd = Object.values(pattern.oddWeekHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
        return (even + odd) / 2;
    }
    return Object.values(pattern.standardHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
};

interface PersonListProps {
    persons: Person[];
    onEditPerson: (id: string) => void;
    onDeletePerson: (id: string) => void;
}

const PersonList: React.FC<PersonListProps> = ({ persons, onEditPerson, onDeletePerson }) => {
    const getPersonSummary = (person: Person) => {
        const today = new Date().toISOString().split('T')[0];
        const currentPatternEntry = [...person.workPatterns]
            .filter(p => p.startDate <= today)
            .sort((a, b) => b.startDate.localeCompare(a.startDate))[0];
        
        const avgHours = currentPatternEntry ? calculateAverageHours(currentPatternEntry.pattern) : 0;
        const startDate = person.contractStartDate ? new Date(person.contractStartDate + 'T00:00:00').toLocaleDateString('nl-NL') : 'N/A';
        
        return { avgHours, startDate };
    };

    const handleDeleteClick = (person: Person) => {
        onDeletePerson(person.id);
    };

    return (
        <Card>
            <CardContent className="p-0">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-text-secondary uppercase bg-surface/50">
                            <tr>
                                <th className="px-6 py-3">Naam</th>
                                <th className="px-6 py-3">Gem. uren/week</th>
                                <th className="px-6 py-3">Startdatum Contract</th>
                                <th className="px-6 py-3 text-right">Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            {persons.map(person => {
                                const { avgHours, startDate } = getPersonSummary(person);
                                return (
                                    <tr key={person.id} className="bg-surface border-b border-border-default hover:bg-background dark:hover:bg-black/10">
                                        <td className="px-6 py-4 font-medium text-text-primary whitespace-nowrap">{person.name}</td>
                                        <td className="px-6 py-4">{avgHours.toFixed(1)}</td>
                                        <td className="px-6 py-4">{startDate}</td>
                                        <td className="px-6 py-4 text-right whitespace-nowrap">
                                            <button onClick={() => onEditPerson(person.id)} className="font-medium text-primary hover:underline inline-flex items-center gap-1.5">
                                                <EditIcon className="w-4 h-4"/>Bewerken
                                            </button>
                                            <button onClick={() => handleDeleteClick(person)} className="font-medium text-error hover:underline ml-4 inline-flex items-center gap-1.5">
                                                <TrashIcon className="w-4 h-4"/>Verwijderen
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </CardContent>
        </Card>
    );
};

export default PersonList;