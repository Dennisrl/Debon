
import React, { useMemo } from 'react';
import type { SprintCapacityResult, ProjectAllocation, Project } from '../types';

const VerticalCapacityIndicator: React.FC<{
    capacity: SprintCapacityResult;
    allocations: ProjectAllocation[];
    projects: Project[];
}> = ({ capacity, allocations, projects }) => {
    const totalCapacity = capacity.totalRawHours;
    if (totalCapacity === 0) return <div className="h-full w-full bg-border-default rounded-md"></div>;

    const projectMap = useMemo(() => new Map(projects.map(p => [p.id, p])), [projects]);

    const sortedAllocations = useMemo(() => {
        return [...allocations].sort((a, b) => {
            const projectA = projectMap.get(a.projectId);
            const projectB = projectMap.get(b.projectId);
            return (projectA?.name || '').localeCompare(projectB?.name || '');
        });
    }, [allocations, projectMap]);

    const plannedProjectHours = sortedAllocations.reduce((sum, alloc) => sum + (parseFloat(alloc.plannedHours) || 0), 0);
    const totalPlanned = capacity.adhocHours + capacity.scrumHours + plannedProjectHours;
    const isOverbooked = totalPlanned > totalCapacity;

    const getHeight = (hours: number) => (hours / totalCapacity) * 100;

    const tooltipContent = (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max max-w-xs bg-neutral-black text-neutral-white text-xs rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 shadow-lg">
            <h4 className="font-bold border-b border-border-default pb-1 mb-1">Urenverdeling</h4>
            <div className="space-y-0.5">
                <div className="flex justify-between gap-4"><span className="text-warning">Ad-hoc / SLA:</span><span>{capacity.adhocHours.toFixed(1)}u</span></div>
                <div className="flex justify-between gap-4"><span className="text-secondary">Scrum Events:</span><span>{capacity.scrumHours.toFixed(1)}u</span></div>
                {sortedAllocations.map(alloc => {
                    const project = projectMap.get(alloc.projectId);
                    return (
                        <div key={alloc.id} className="flex justify-between gap-4">
                            <span style={{ color: project?.color || '#FFFFFF' }}>{project?.name || 'Onbekend'}:</span>
                            <span>{(parseFloat(alloc.plannedHours) || 0).toFixed(1)}u</span>
                        </div>
                    )
                })}
            </div>
            <div className="border-t border-border-default pt-1 mt-1 font-semibold flex justify-between gap-4">
                <span>Totaal Gepland:</span>
                <span>{totalPlanned.toFixed(1)}u</span>
            </div>
        </div>
    );

    return (
        <div className="group relative w-full h-full">
            {tooltipContent}
            <div className={`relative h-full w-full flex flex-col-reverse overflow-hidden rounded-md ${isOverbooked ? 'bg-error' : 'bg-border-default'}`}>
                {/* Reversed order for bottom-up stacking */}
                {sortedAllocations.map(alloc => (
                    <div key={alloc.id} style={{ height: `${getHeight(parseFloat(alloc.plannedHours) || 0)}%`, backgroundColor: projectMap.get(alloc.projectId)?.color || '#ccc' }} className="w-full"></div>
                ))}
                <div style={{ height: `${getHeight(capacity.scrumHours)}%` }} className="bg-secondary w-full"></div>
                <div style={{ height: `${getHeight(capacity.adhocHours)}%` }} className="bg-warning w-full"></div>
            </div>
        </div>
    );
};

export default VerticalCapacityIndicator;
