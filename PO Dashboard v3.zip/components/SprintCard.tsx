import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import type { Project, SprintDetails } from '../types';
import { TrashIcon } from './icons';

export const SprintCard: React.FC<{
    sprint: SprintDetails;
    project: Project;
    disabled: boolean;
}> = ({ sprint, project, disabled }) => {
    const { updateProject } = useData();
    const [points, setPoints] = useState(sprint.actualPoints);
    const [hours, setHours] = useState(sprint.actualHours);
    const cardRef = useRef<HTMLDivElement>(null);

    const isAutomated = !!sprint.isAutomated;

    useEffect(() => {
        setPoints(sprint.actualPoints);
        setHours(sprint.actualHours);
    }, [sprint.actualPoints, sprint.actualHours]);
    
    const handleUpdate = () => {
        if (isAutomated) return;
        if (points !== sprint.actualPoints || hours !== sprint.actualHours) {
            const updatedSprints = project.sprints.map(s => s.id === sprint.id ? { ...s, actualPoints: points, actualHours: hours } : s);
            updateProject({ id: project.id, sprints: updatedSprints });
        }
    };

    const handleBlur = (event: React.FocusEvent<HTMLDivElement>) => {
        if (!cardRef.current?.contains(event.relatedTarget as Node)) {
            handleUpdate();
        }
    };
    
    const handleDelete = () => {
        if (isAutomated) return;
        const updatedSprints = project.sprints
            .filter(s => s.id !== sprint.id)
            .map((s, index) => ({ ...s, sprintNumber: index + 1 }));
        updateProject({ id: project.id, sprints: updatedSprints });
    };

    return (
        <div ref={cardRef} onBlur={handleBlur} tabIndex={-1} className={`group relative flex-shrink-0 w-48 bg-surface/70 p-3 rounded-lg border border-border-default mb-4 ${!isAutomated ? 'focus:outline-none focus:ring-2 focus:ring-primary' : ''}`}>
            <h5 className="font-bold text-sm text-text-primary text-center mb-2">Sprint {sprint.sprintNumber}</h5>
            {!isAutomated && (
                <button onClick={handleDelete} className="absolute top-1 right-1 p-1 text-text-secondary/70 hover:text-error rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10" aria-label="Verwijder sprint">
                    <TrashIcon className="w-4 h-4"/>
                </button>
            )}
            <div className="space-y-2">
                <div>
                    <label className="text-xs font-medium text-text-secondary block text-center">Behaalde Punten</label>
                    <input type="number" value={points} onChange={(e) => setPoints(e.target.value)} className="w-full px-2 py-2.5 text-base bg-background border border-border-default rounded-md focus:ring-1 focus:ring-primary text-center disabled:bg-background/50" disabled={disabled || isAutomated} min="0" />
                </div>
                <div>
                    <label className="text-xs font-medium text-text-secondary block text-center">Behaalde Uren</label>
                    <input type="number" value={hours} onChange={(e) => setHours(e.target.value)} className="w-full px-2 py-2.5 text-base bg-background border border-border-default rounded-md focus:ring-1 focus:ring-primary text-center disabled:bg-background/50" disabled={disabled || isAutomated} min="0" />
                </div>
            </div>
        </div>
    );
};