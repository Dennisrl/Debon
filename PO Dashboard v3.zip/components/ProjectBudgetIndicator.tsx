

import React from 'react';
import { Tooltip } from './Tooltip';

interface ProjectBudgetIndicatorProps {
    budget: number;
    actual: number;
    planned: number;
    isBudgetSet: boolean;
}

const ProjectBudgetIndicator: React.FC<ProjectBudgetIndicatorProps> = ({ budget, actual, planned, isBudgetSet }) => {
    const effectiveBudget = isBudgetSet ? budget : actual + planned;
    
    if (effectiveBudget <= 0) {
        return <div className="h-2.5 w-full bg-border-default rounded-full" title="Geen budget of uren"></div>;
    }

    const actualPercentage = (actual / effectiveBudget) * 100;
    const plannedPercentage = (planned / effectiveBudget) * 100;
    const isOverBudget = isBudgetSet && (actual + planned > budget);

    const tooltipContent = (
        <div className="text-xs space-y-1">
            <h5 className="font-bold border-b border-gray-400 pb-1 mb-1">Budget Status</h5>
            <div className="flex justify-between">
                <span>{isBudgetSet ? 'Budget:' : 'Budget (Dynamisch):'}</span>
                <span className="font-semibold">{effectiveBudget.toFixed(0)}u</span>
            </div>
            <div className="flex justify-between"><span>Werkelijk:</span><span className="font-semibold">{actual.toFixed(0)}u</span></div>
            <div className="flex justify-between"><span>Gepland:</span><span className="font-semibold">{planned.toFixed(0)}u</span></div>
            {isBudgetSet && (
                <div className={`flex justify-between font-bold border-t border-gray-400 pt-1 mt-1 ${isOverBudget ? 'text-red-400' : 'text-text-primary'}`}>
                    <span>Resterend:</span>
                    <span>{(budget - actual - planned).toFixed(0)}u</span>
                </div>
            )}
        </div>
    );

    return (
        <Tooltip content={tooltipContent} position="top">
            <div className={`relative h-2.5 w-full rounded-full flex overflow-hidden ${isOverBudget ? 'bg-error/30' : 'bg-border-default'}`}>
                <div 
                    className={`${isOverBudget ? 'bg-error' : 'bg-secondary'}`}
                    style={{ width: `${Math.min(actualPercentage, 100)}%` }}
                ></div>
                <div 
                    className={`${isOverBudget ? 'bg-error' : 'bg-primary'}`}
                    style={{ width: `${Math.min(plannedPercentage, 100 - actualPercentage)}%` }}
                ></div>
            </div>
        </Tooltip>
    );
};

export default ProjectBudgetIndicator;