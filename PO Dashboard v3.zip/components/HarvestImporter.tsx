import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { useData } from '../context/DataContext';
import type { ActualHoursEntry } from '../types';
import { Card, CardContent, CardHeader } from './Card';
import { ClockIcon, CheckIcon, GlobeIcon, Wand2Icon, PlusIcon } from './icons';
import InsightCard from './InsightCard';
import { generateImportAnalysis } from '../services/analysisService';

interface RawRow {
  [key:string]: any;
}

const HarvestImporter: React.FC = () => {
    const { data, setActualHours } = useData();
    const { persons = [], projects = [], globalEvents = [], actualHours = [], teamMembers = [] } = data || {};

    const [importMessage, setImportMessage] = useState<string | null>(null);
    const [isError, setIsError] = useState(false);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        setImportMessage(null);
        setIsError(false);

        const reader = new FileReader();
        reader.onload = (e) => {
            const data = e.target?.result;
            parseXlsx(data);
        };
        reader.onerror = () => {
            setImportMessage("Fout bij het lezen van het bestand.");
            setIsError(true);
        };
        reader.readAsArrayBuffer(file);
        event.target.value = ''; // Reset file input
    };

    const parseXlsx = (data: any) => {
        try {
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const json: RawRow[] = XLSX.utils.sheet_to_json(worksheet);

            if (json.length === 0) {
                setImportMessage("Het geselecteerde XLSX-bestand is leeg.");
                setIsError(true);
                return;
            }

            const headers = Object.keys(json[0]);
            const requiredHeaders = ["Date", "Hours", "First Name", "Last Name", "Project"];
            if (!requiredHeaders.every(h => headers.includes(h))) {
                setImportMessage(`XLSX-bestand mist een of meerdere verplichte kolommen. Vereist: ${requiredHeaders.join(', ')}.`);
                setIsError(true);
                return;
            }
            
            processAndImport(json);

        } catch (e) {
            console.error("Error parsing XLSX file:", e);
            setImportMessage("Bestand kon niet worden verwerkt. Is het een geldig .xlsx-bestand?");
            setIsError(true);
        }
    };
    
    const processAndImport = (data: RawRow[]) => {
        const personMapByName = new Map(persons.map(p => [p.name.trim().toLowerCase(), p.id]));
        const projectMapByName = new Map(projects.map(p => [p.name.trim().toLowerCase(), p.id]));
        
        const excelDateToJSDate = (excelDate: number) => new Date(Math.round((excelDate - 25569) * 86400 * 1000));

        const newEntries: ActualHoursEntry[] = data.map((row): ActualHoursEntry | null => {
            const personName = `${row['First Name'] || ''} ${row['Last Name'] || ''}`.trim();
            if (!personName) return null;
            
            const personId = personMapByName.get(personName.toLowerCase());
            
            const projectNameFromFile = String(row['Project'] || '').trim();
            const projectId = projectMapByName.get(projectNameFromFile.toLowerCase());

            let date;
            if (typeof row['Date'] === 'number') { date = excelDateToJSDate(row['Date']); } 
            else if (typeof row['Date'] === 'string') { date = new Date(row['Date']); } 
            else { return null; }
            
            if (isNaN(date.getTime())) return null;

            const hours = parseFloat(String(row['Hours']).replace(',', '.')) || 0;
            if (hours <= 0) return null;

            return {
                id: crypto.randomUUID(),
                date: date.toISOString().split('T')[0],
                personId: personId,
                personName: personName,
                projectId: projectId,
                projectName: projectNameFromFile,
                hours,
                billable: String(row['Billable?']).trim().toLowerCase() === 'yes',
                client: String(row['Client'] || ''),
                projectCode: String(row['Project Code'] || ''),
                task: String(row['Task'] || ''),
                notes: String(row['Notes'] || ''),
                billableRate: parseFloat(String(row['Billable Rate']).replace(',', '.')) || undefined,
                billableAmount: parseFloat(String(row['Billable Amount']).replace(',', '.')) || undefined,
                invoiced: String(row['Invoiced?']).trim().toLowerCase() === 'yes',
                roles: String(row['Roles'] || ''),
                isEmployee: String(row['Employee?']).trim().toLowerCase() === 'yes',
                costRate: parseFloat(String(row['Cost Rate']).replace(',', '.')) || undefined,
                costAmount: parseFloat(String(row['Cost Amount']).replace(',', '.')) || undefined,
                currency: String(row['Currency'] || ''),
                externalReferenceUrl: String(row['External Reference URL'] || ''),
            };
        }).filter((e): e is ActualHoursEntry => e !== null);

        setActualHours(newEntries);
        setImportMessage(`${newEntries.length} urenregistraties succesvol opgeslagen in het systeem.`);
        setIsError(false);
    };

    const sortedActualHours = useMemo(() => {
        if (!actualHours) return [];
        return [...actualHours].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    }, [actualHours]);

    const allColumns = ["Datum", "Medewerker", "Project", "Uren", "Factureerbaar", "Taak"];

    const analysisExplanation = (
        <div>
            <p>Deze AI-assistent controleert of de geboekte uren van teamleden overeenkomen met hun capaciteit op de betreffende dagen.</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
                <li><strong>Exclusief PO's:</strong> De analyse wordt alleen uitgevoerd voor personen die lid zijn van een team.</li>
                <li><strong>Vergelijking:</strong> De analyse vergelijkt de som van de geboekte uren per dag met de verwachte uren volgens het werkpatroon.</li>
                <li><strong>Houdt rekening met:</strong> Zowel persoonlijke agenda-items (zoals vakantie of ziekte) als globale evenementen (zoals feestdagen) worden meegenomen in de capaciteitsberekening.</li>
                <li><strong>Melding:</strong> U krijgt een melding als een teamlid op een werkdag meer dan 2 uur minder heeft geboekt dan zijn of haar capaciteit.</li>
            </ul>
        </div>
    );

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <div className="mb-6">
                <h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">Uren Importeren (XLSX)</h2>
                <p className="mt-2 text-text-secondary">Importeer uren uit een XLSX-export. De bestaande uren worden direct overschreven.</p>
            </div>
            
             <Card>
                <CardHeader>
                    <div className="flex justify-between items-center w-full">
                        Import & Analyse
                        <div className="flex items-center gap-4">
                           <input type="file" id="xlsx-upload" className="hidden" accept=".xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={handleFileChange} />
                           <label htmlFor="xlsx-upload" className="cursor-pointer text-sm font-semibold text-neutral-white bg-primary px-4 py-2 rounded-lg hover:bg-primary-hover transition-all">
                                {actualHours.length > 0 ? 'Nieuw Bestand Importeren' : 'Importeer XLSX'}
                           </label>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    {importMessage && <p className={`my-4 p-3 rounded-lg ${isError ? 'text-error bg-error/10' : 'text-success bg-success/10'}`}>{importMessage}</p>}
                    
                    <InsightCard 
                        title="AI Analyse van Import"
                        explanation={analysisExplanation}
                        onGenerateAnalysis={() => generateImportAnalysis(actualHours, persons, globalEvents, teamMembers)}
                    />

