

import React, { useMemo } from 'react';
import type { SprintCapacityResult, ProjectAllocation, Project } from '../types';

const CapacityBar: React.FC<{
    capacity: SprintCapacityResult;
    allocations: ProjectAllocation[];
    projects: Project[];
}> = ({ capacity, allocations, projects }) => {
    const totalCapacity = capacity.totalRawHours;
    if (totalCapacity === 0) return <div className="h-6 w-full bg-border-default rounded-md"></div>;

    const projectMap = useMemo(() => new Map(projects.map(p => [p.id, p])), [projects]);

    const sortedAllocations = useMemo(() => {
        // Sort by project name for consistency, unlinked projects (where name is in ID) will be sorted alphabetically too
        return [...allocations].sort((a, b) => {
            const projectA = projectMap.get(a.projectId);
            const projectB = projectMap.get(b.projectId);
            const nameA = projectA?.name || a.projectId;
            const nameB = projectB?.name || b.projectId;
            return nameA.localeCompare(nameB);
        });
    }, [allocations, projectMap]);

    const plannedProjectHours = sortedAllocations.reduce((sum, alloc) => sum + (parseFloat(alloc.plannedHours) || 0), 0);
    const totalPlanned = capacity.adhocHours + capacity.scrumHours + plannedProjectHours;
    const isOverbooked = totalPlanned > totalCapacity;

    const getWidth = (hours: number) => (hours / totalCapacity) * 100;
    
    const tooltipContent = (
        <div className="absolute bottom-full mb-2 w-max max-w-xs bg-neutral-black text-neutral-white text-xs rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 shadow-lg left-1/2 -translate-x-1/2">
            <h4 className="font-bold border-b border-border-default pb-1 mb-1">Urenverdeling</h4>
            <div className="space-y-0.5">
                <div className="flex justify-between gap-4"><span className="text-warning">Ad-hoc / SLA:</span><span>{capacity.adhocHours.toFixed(1)}u</span></div>
                <div className="flex justify-between gap-4"><span className="text-secondary">Scrum Events:</span><span>{capacity.scrumHours.toFixed(1)}u</span></div>
                {sortedAllocations.map(alloc => {
                    const project = projectMap.get(alloc.projectId);
                    const displayName = project?.name || alloc.projectId; // Fallback to the identifier in projectId
                    const displayColor = project?.color || '#A9A9A9'; // Default grey for unlinked
                    return (
                        <div key={alloc.id} className="flex justify-between gap-4">
                            <span style={{ color: displayColor }}>{displayName}:</span>
                            <span>{(parseFloat(alloc.plannedHours) || 0).toFixed(1)}u</span>
                        </div>
                    )
                })}
            </div>
            <div className="border-t border-border-default pt-1 mt-1 font-semibold flex justify-between gap-4">
                <span>Totaal Ingevuld:</span>
                <span>{totalPlanned.toFixed(1)}u</span>
            </div>
        </div>
    );

    return (
        <div className="space-y-1 group relative">
            {tooltipContent}
            <div className={`relative h-6 w-full flex overflow-hidden rounded-md text-white text-xs font-bold ${isOverbooked ? 'bg-error' : 'bg-border-default'}`}>
                <div style={{ width: `${getWidth(capacity.adhocHours)}%` }} className="bg-warning h-full"></div>
                <div style={{ width: `${getWidth(capacity.scrumHours)}%` }} className="bg-secondary h-full"></div>
                {sortedAllocations.map(alloc => {
                     const project = projectMap.get(alloc.projectId);
                     const displayColor = project?.color || '#A9A9A9'; // Default grey for unlinked
                    return (
                        <div key={alloc.id} style={{ width: `${getWidth(parseFloat(alloc.plannedHours) || 0)}%`, backgroundColor: displayColor }} className="h-full"></div>
                    )
                })}
            </div>
        </div>
    );
};

export default CapacityBar;
