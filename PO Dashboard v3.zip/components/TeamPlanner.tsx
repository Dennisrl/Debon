import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import { calculateSprintCapacity, expandRecurringEvents, generateSprintsForYear } from '../services/planningService';
import { ChevronLeftIcon, ChevronRightIcon, PlusIcon, TrashIcon, Wand2Icon, ChevronDownIcon, BriefcaseIcon, InfoIcon, EyeIcon, EyeOffIcon } from './icons';
import type { SprintPlan, Team, SprintCapacityResult, Project, TeamMember, ProjectAllocation, Person, CalendarEvent, GlobalEvent, ActualHoursEntry, ProjectAssignment } from '../types';
import { Tooltip } from './Tooltip';
import DebouncedInput from './DebouncedInput';
import BulkPlannerModal from './BulkPlannerModal';
import SprintDetailPanel from './SprintDetailPanel';
import DesktopSprintCard from './DesktopSprintCard';
import MobileSprintListItem from './MobileSprintListItem';
import ProjectBudgetIndicator from './ProjectBudgetIndicator';


// --- Helper Components ---

const SummaryStatCard: React.FC<{ title: string; value: string; subtext?: string; }> = ({ title, value, subtext }) => (
    <div className="bg-background p-3 rounded-lg text-center">
        <p className="text-xs font-medium text-text-secondary">{title}</p>
        <p className="text-2xl font-bold text-primary mt-1">{value}</p>
        {subtext && <p className="text-xs text-text-secondary mt-1">{subtext}</p>}
    </div>
);

// --- Main Planner ---
const TeamPlanner: React.FC = () => {
    const { data, addTeam, deleteTeam, updateTeam, setTeamMembers, setSprintPlans, addProjectAssignment, updateProjectAssignment, deleteProjectAssignment, setAllAllocations, updateProject, updateSprintPlan, updateSprintEndDateAndCascade } = useData();
    const { teams = [], persons = [], projects = [], teamMembers = [], sprintPlans = [], projectAllocations = [], globalEvents = [], actualHours = [], projectAssignments = [] } = data || {};

    const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
    const [editingSprintId, setEditingSprintId] = useState<string | null>(null);
    const [viewYear, setViewYear] = useState(new Date().getFullYear());
    const [isBulkPlannerOpen, setIsBulkPlannerOpen] = useState(false);
    const [bulkPlanningProject, setBulkPlanningProject] = useState<Project | null>(null);
    const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
    const [showArchived, setShowArchived] = useState(false);
    
    const gridContainerRef = useRef<HTMLDivElement>(null);
    const addMemberButtonRef = useRef<HTMLButtonElement>(null);
    const addMemberDropdownRef = useRef<HTMLDivElement>(null);


    // --- State & Memoized Selectors ---
    const today = useMemo(() => new Date().toISOString().split('T')[0], []);

    useEffect(() => {
        if (!selectedTeamId && teams.length > 0) setSelectedTeamId(teams[0].id);
        else if (teams.length > 0 && !teams.some(t => t.id === selectedTeamId)) setSelectedTeamId(teams[0].id);
        else if (teams.length === 0) setSelectedTeamId(null);
    }, [teams, selectedTeamId]);
    
    const selectedTeam = useMemo(() => teams.find(t => t.id === selectedTeamId), [teams, selectedTeamId]);
    
    const sprintsForTeamAndYear = useMemo(() => 
        sprintPlans
            .filter(s => s.teamId === selectedTeam?.id && new Date(s.startDate).getFullYear() === viewYear)
            .sort((a,b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime()), 
        [sprintPlans, selectedTeam, viewYear]
    );

    const assignmentsForTeam = useMemo(() => {
        if (!selectedTeam) return [];
        return projectAssignments.filter(pa => pa.teamId === selectedTeam.id);
    }, [projectAssignments, selectedTeam]);
    
    const projectsToShowInView = useMemo(() => {
        if (!selectedTeam) return [];
        
        // Start with projects that have an assignment overlapping the current year
        const yearStart = new Date(viewYear, 0, 1);
        const yearEnd = new Date(viewYear, 11, 31);
        const projectIdsInView = new Set<string>();

        assignmentsForTeam.forEach(pa => {
            const assignStart = new Date(pa.startDate);
            const assignEnd = pa.endDate ? new Date(pa.endDate) : yearEnd;
            if (assignStart <= yearEnd && assignEnd >= yearStart) {
                projectIdsInView.add(pa.projectId);
            }
        });

        // Also include projects with historical hours from this team in this year, even if assignment ended
        const teamMemberIds = new Set(teamMembers.filter(m => m.teamId === selectedTeam.id).map(m => m.personId));
        actualHours.forEach(ah => {
            if (ah.projectId && teamMemberIds.has(ah.personId!) && new Date(ah.date).getFullYear() === viewYear) {
                projectIdsInView.add(ah.projectId);
            }
        });
        
        return projects.filter(p => projectIdsInView.has(p.id) && (showArchived ? true : !p.isHidden));

    }, [projects, selectedTeam, assignmentsForTeam, teamMembers, actualHours, viewYear, showArchived]);


    const availableProjectsToAdd = useMemo(() => {
        const assignedProjectIds = new Set(assignmentsForTeam.map(a => a.projectId));
        return projects.filter(p => !assignedProjectIds.has(p.id));
    }, [projects, assignmentsForTeam]);

    const availableMembersToAdd = useMemo(() => {
        if (!selectedTeam) return [];
        const currentMemberIds = new Set(teamMembers.filter(m => m.teamId === selectedTeam.id).map(m => m.personId));
        return persons.filter(p => !currentMemberIds.has(p.id));
    }, [persons, teamMembers, selectedTeam]);
    
    const allocationsPerSprint = useMemo(() => {
        return sprintsForTeamAndYear.reduce((map, sprint) => {
            map.set(sprint.id, projectAllocations.filter(a => a.sprintId === sprint.id));
            return map;
        }, new Map<string, ProjectAllocation[]>());
    }, [projectAllocations, sprintsForTeamAndYear]);

    const projectBudgetSummary = useMemo(() => {
        if (!selectedTeam) return [];

        const teamMemberIds = new Set(teamMembers.filter(m => m.teamId === selectedTeam.id).map(m => m.personId));

        return projectsToShowInView.map(p => {
            const budgetHours = parseFloat(p.budgetHours) || 0;
            const isBudgetSet = budgetHours > 0;
            const assignment = assignmentsForTeam.find(a => a.projectId === p.id);
            
            // Filter actuals by team members
            const historicalActuals = actualHours
                .filter(ah => ah.projectId === p.id && teamMemberIds.has(ah.personId!))
                .reduce((sum, ah) => sum + ah.hours, 0);

            // Filter planned hours by team sprints and assignment dates
            const futurePlanned = projectAllocations
                .filter(pa => {
                    if (pa.projectId !== p.id) return false;
                    const sprint = sprintPlans.find(s => s.id === pa.sprintId);
                    // Must be a future sprint for the correct team
                    if (!sprint || sprint.teamId !== selectedTeam.id || sprint.startDate < today) return false;
                    
                    // If assigned, sprint must be within assignment dates
                    if (assignment) {
                        const sprintStart = new Date(sprint.startDate);
                        const assignmentStart = new Date(assignment.startDate);
                        const assignmentEnd = assignment.endDate ? new Date(assignment.endDate) : new Date('9999-12-31');
                        if (sprintStart < assignmentStart || sprintStart > assignmentEnd) return false;
                    } else {
                        return false; // Not assigned, so no future planning
                    }
                    return true;
                })
                .reduce((sum, pa) => sum + (parseFloat(pa.plannedHours) || 0), 0);
            
            const effectiveBudget = isBudgetSet ? budgetHours : historicalActuals + futurePlanned;
            const remaining = isBudgetSet ? budgetHours - historicalActuals - futurePlanned : 0;
            
            return {
                projectId: p.id,
                name: p.name,
                color: p.color,
                budgetHours: effectiveBudget,
                isBudgetSet,
                actualBudget: budgetHours,
                historicalActuals,
                futurePlanned,
                remaining
            };
        });
    }, [selectedTeam, teamMembers, projectsToShowInView, actualHours, projectAllocations, sprintPlans, today, assignmentsForTeam]);
    
    // --- Data Calculation ---
    useEffect(() => {
        if (selectedTeam && sprintsForTeamAndYear.length === 0 && viewYear > 0) {
            const newSprints = generateSprintsForYear(selectedTeam, viewYear, sprintPlans);
            if (newSprints.length > 0) setSprintPlans([...sprintPlans, ...newSprints]);
        }
    }, [selectedTeam, sprintsForTeamAndYear.length, viewYear, sprintPlans, setSprintPlans]);

    const expandedEvents = useMemo(() => {
        if (!sprintsForTeamAndYear.length) return { global: [], personal: new Map() };
        const viewStart = new Date(sprintsForTeamAndYear[0].startDate + 'T00:00:00');
        const viewEnd = new Date(sprintsForTeamAndYear[sprintsForTeamAndYear.length - 1].endDate + 'T00:00:00');
        
        const allExpandedGlobalEvents = expandRecurringEvents(globalEvents, viewStart, viewEnd);
        const allExpandedPersonEvents = new Map(persons.map(p => [
            p.id,
            expandRecurringEvents(p.events as (CalendarEvent[] | undefined), viewStart, viewEnd) as (CalendarEvent & { originalId: string; })[]
        ]));

        return { global: allExpandedGlobalEvents, personal: allExpandedPersonEvents };
    }, [sprintsForTeamAndYear, globalEvents, persons]);
    
    const capacityResults = useMemo(() => {
        if (!selectedTeam || sprintsForTeamAndYear.length === 0) return new Map<string, SprintCapacityResult>();
        return new Map(sprintsForTeamAndYear.map(sprint => 
            [sprint.id, calculateSprintCapacity(sprint, selectedTeam, teamMembers, persons, expandedEvents.global as GlobalEvent[], expandedEvents.personal)]
        ));
    }, [sprintsForTeamAndYear, selectedTeam, teamMembers, persons, expandedEvents]);

    const sprintRenderDetails = useMemo(() => {
        if (!selectedTeam) return [];

        const teamPersonIds = new Set(teamMembers.filter(m => m.teamId === selectedTeam.id).map(m => m.personId));
        const scrumKeywords = ['scrum', 'daily', 'planning', 'review', 'retro', 'refinement'];
        const adhocKeywords = ['sla', 'support', 'onderhoud', 'ad-hoc'];

        return sprintsForTeamAndYear.map((sprint, index) => {
            const plannedCapacity = capacityResults.get(sprint.id);
            if (!plannedCapacity) return null;

            const isPastSprint = sprint.endDate < today;
            const sprintNumber = index + 1;

            if (isPastSprint) {
                const sprintStart = new Date(sprint.startDate + 'T00:00:00');
                const sprintEnd = new Date(sprint.endDate + 'T23:59:59');

                const sprintActuals = actualHours.filter(entry => {
                    const entryDate = new Date(entry.date + 'T00:00:00');
                    return entryDate >= sprintStart && entryDate <= sprintEnd;
                });

                const teamActuals = sprintActuals.filter(entry => {
                    return entry.personId ? teamPersonIds.has(entry.personId) : false;
                });
                
                const adhocActuals = teamActuals.filter(e => !e.projectName && adhocKeywords.some(k => e.task?.toLowerCase().includes(k))).reduce((s, e) => s + e.hours, 0);
                const scrumActuals = teamActuals.filter(e => !e.projectName && scrumKeywords.some(k => e.task?.toLowerCase().includes(k))).reduce((s, e) => s + e.hours, 0);
                
                const projectHoursMap = teamActuals
                    .filter(entry => entry.projectId)
                    .reduce((map, entry) => {
                        map.set(entry.projectId!, (map.get(entry.projectId!) || 0) + entry.hours);
                        return map;
                    }, new Map<string, number>());
                
                const actualAllocations = Array.from(projectHoursMap.entries()).map(([projectId, hours]) => ({
                    id: `proj-actual-${sprint.id}-${projectId}`,
                    sprintId: sprint.id,
                    projectId: projectId,
                    plannedHours: String(hours),
                }));
                
                const actualCapacity: SprintCapacityResult = {
                    ...plannedCapacity,
                    adhocHours: adhocActuals,
                    scrumHours: scrumActuals,
                };
                
                return {
                    sprint,
                    sprintNumber,
                    isPastSprint,
                    capacity: actualCapacity,
                    allocations: actualAllocations,
                    actualHoursData: teamActuals,
                };

            } else { // Future sprint
                const plannedAllocations = allocationsPerSprint.get(sprint.id) || [];
                return {
                    sprint,
                    sprintNumber,
                    isPastSprint,
                    capacity: plannedCapacity,
                    allocations: plannedAllocations,
                    actualHoursData: [],
                };
            }
        }).filter((d): d is NonNullable<typeof d> => d !== null);
    }, [sprintsForTeamAndYear, capacityResults, allocationsPerSprint, actualHours, teamMembers, selectedTeam, today, persons]);
    
    const yearlySummary = useMemo(() => {
        if (sprintRenderDetails.length === 0) return { totalCapacity: 0, totalFilledIn: 0, totalRemaining: 0, utilization: 0 };
        let totalCapacity = 0, totalFilledIn = 0;
        
        for (const details of sprintRenderDetails) {
            totalCapacity += details.capacity.totalRawHours;
            const projectHours = details.allocations.reduce((sum, alloc) => sum + (parseFloat(alloc.plannedHours) || 0), 0);
            totalFilledIn += details.capacity.adhocHours + details.capacity.scrumHours + projectHours;
        }
        return { totalCapacity, totalFilledIn, totalRemaining: totalCapacity - totalFilledIn, utilization: totalCapacity > 0 ? (totalFilledIn / totalCapacity) * 100 : 0 };
    }, [sprintRenderDetails]);

    // --- Effects & Handlers ---
    useEffect(() => {
        if (editingSprintId !== null) return; // Don't scroll when detail panel is open
        const timer = setTimeout(() => {
            if (!sprintsForTeamAndYear.length) return;
            const currentSprint = sprintsForTeamAndYear.find(s => s.startDate <= today && s.endDate >= today);
            if (currentSprint && gridContainerRef.current) {
                const sprintElement = gridContainerRef.current.querySelector(`[data-sprint-id="${currentSprint.id}"]`) as HTMLElement;
                if (sprintElement) sprintElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 150);
        return () => clearTimeout(timer);
    }, [selectedTeamId, viewYear, editingSprintId, sprintsForTeamAndYear, today]); // Auto-scroll only when team or year changes
    
    // Click outside handler for add project dropdown
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (isAddMemberOpen && addMemberDropdownRef.current && !addMemberDropdownRef.current.contains(event.target as Node) && !addMemberButtonRef.current?.contains(event.target as Node)) {
                setIsAddMemberOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [isAddMemberOpen]);
    
    const editingSprintDetails = useMemo(() => sprintRenderDetails.find(d => d.sprint.id === editingSprintId), [sprintRenderDetails, editingSprintId]);
    const handleTeamConfigChange = (field: keyof Team, value: any) => selectedTeam && updateTeam({ id: selectedTeam.id, [field]: value });

    const handleTeamMemberChange = (personId: string, isMember: boolean, field?: 'startDate' | 'endDate', value?: string) => {
        if (!selectedTeam) return;
        let newTeamMembers = [...teamMembers];
        const memberIndex = newTeamMembers.findIndex(m => m.teamId === selectedTeam.id && m.personId === personId);
        if (isMember) {
            if (memberIndex > -1) {
                if (field && value !== undefined) newTeamMembers[memberIndex] = { ...newTeamMembers[memberIndex], [field]: value };
            } else {
                const person = persons.find(p => p.id === personId);
                if (person) newTeamMembers.push({ id: crypto.randomUUID(), teamId: selectedTeam.id, personId, startDate: person.contractStartDate, endDate: person.contractEndDate || '' });
            }
        } else if (memberIndex > -1) newTeamMembers.splice(memberIndex, 1);
        setTeamMembers(newTeamMembers);
    };

    const handleAddTeam = () => { addTeam({ name: 'Nieuw Team', defaultAdhocPct: '10', defaultScrumPct: '10', defaultSprintLengthWeeks: '2' }); };
    const handleDeleteTeam = () => {
        if (selectedTeam && teams.length > 1) {
            deleteTeam(selectedTeam.id);
            const nextTeamId = teams.find(t => t.id !== selectedTeam.id)?.id || null;
            setSelectedTeamId(nextTeamId);
        }
    };

    const handleAddNewAssignment = () => {
        if (!selectedTeam) return;
        const newAssignment: ProjectAssignment = {
            id: crypto.randomUUID(),
            teamId: selectedTeam.id,
            projectId: '', // Empty initially, user will select
            startDate: new Date(viewYear, 0, 1).toISOString().split('T')[0],
            endDate: ''
        };
        addProjectAssignment(newAssignment);
    };
    
    if (teams.length === 0) {
        return <div className="container mx-auto p-8 text-center flex flex-col items-center justify-center h-full">
            <p className="text-lg font-semibold">Er zijn geen teams geconfigureerd.</p>
            <button onClick={handleAddTeam} className="mt-4 flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold text-neutral-white bg-primary rounded-lg hover:bg-primary-hover transition-all"><PlusIcon className="w-4 h-4"/>Voeg een team toe</button>
        </div>;
    }

    return (
        <div className="relative">
            {isBulkPlannerOpen && bulkPlanningProject && (
                <BulkPlannerModal
                    project={bulkPlanningProject}
                    sprints={sprintsForTeamAndYear}
                    allAllocations={projectAllocations}
                    onClose={() => setIsBulkPlannerOpen(false)}
                    onSave={(updated) => setAllAllocations(updated)}
                />
            )}
            <div className={`transition-all duration-300 ease-in-out ${editingSprintId ? 'pr-0 lg:pr-[400px]' : 'pr-0'}`}>
                <header className="sticky top-16 bg-background z-30 border-b border-border-default">
                    <div className="container mx-auto p-4 sm:p-6 lg:p-8 pb-4">
                        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                            <div className="flex-grow">
                                <div className="flex items-center gap-2">
                                    <select value={selectedTeamId || ''} onChange={e => { setSelectedTeamId(e.target.value); setEditingSprintId(null); }} className="text-xl font-bold bg-transparent p-2 rounded-md focus:ring-1 focus:ring-primary border-transparent hover:border-border-default border">
                                        {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                                    </select>
                                    <button onClick={handleAddTeam} className="p-2 text-text-secondary hover:text-primary rounded-md"><PlusIcon className="w-5 h-5"/></button>
                                    {teams.length > 1 && <button onClick={handleDeleteTeam} className="p-2 text-text-secondary hover:text-error rounded-md"><TrashIcon className="w-5 h-5"/></button>}
                                </div>
                            </div>
                            <div className="flex items-center gap-4 self-end lg:self-center">
                                <div className="flex items-center gap-2">
                                    <button onClick={() => setViewYear(y => y - 1)} className="p-2 rounded-md hover:bg-surface" aria-label="Vorig jaar"><ChevronLeftIcon className="w-5 h-5"/></button>
                                    <span className="text-lg font-bold text-text-primary tabular-nums">{viewYear}</span>
                                    <button onClick={() => setViewYear(y => y + 1)} className="p-2 rounded-md hover:bg-surface" aria-label="Volgend jaar"><ChevronRightIcon className="w-5 h-5"/></button>
                                </div>
                            </div>
                        </div>
                        
                        {selectedTeam && (
                             <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
                                <SummaryStatCard title="Totale Capaciteit" value={`${yearlySummary.totalCapacity.toFixed(0)} u`} />
                                <SummaryStatCard title="Totaal Ingepland" value={`${yearlySummary.totalFilledIn.toFixed(0)} u`} />
                                <SummaryStatCard title="Resterend" value={`${yearlySummary.totalRemaining.toFixed(0)} u`} />
                                <SummaryStatCard title="Bezettingsgraad" value={`${yearlySummary.utilization.toFixed(0)}%`} />
                            </div>
                        )}
                        {selectedTeam && (
                             <details className="group/summary mt-4" open>
                                <summary className="list-none cursor-pointer flex justify-between items-center w-full">
                                    <div className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-primary font-semibold">
                                        <BriefcaseIcon className="w-5 h-5" />
                                        Projectoverzicht & Budgetten
                                        <ChevronDownIcon className="w-4 h-4 transition-transform group-open/summary:rotate-180" />
                                    </div>
                                     <Tooltip content={showArchived ? "Verberg gearchiveerde projecten" : "Toon gearchiveerde projecten"} position="left">
                                        <button
                                            onClick={(e) => { e.preventDefault(); e.stopPropagation(); setShowArchived(s => !s); }}
                                            className="p-1.5 text-text-secondary/80 hover:text-primary rounded-md"
                                        >
                                            {showArchived ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                                        </button>
                                    </Tooltip>
                                </summary>
                                <div className="mt-3 border border-border-default rounded-lg overflow-hidden">
                                    {/* Header */}
                                    <div className="grid grid-cols-[minmax(0,3fr),minmax(0,1.5fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),auto] gap-x-4 items-center bg-surface px-4 py-2 text-xs font-bold text-text-secondary">
                                        <div className="truncate">Project & Toewijzing</div>
                                        <div className="truncate">Budget Gebruik</div>
                                        <div className="text-right truncate">Budget</div>
                                        <div className="text-right truncate">Actueel</div>
                                        <div className="text-right truncate">Gepland</div>
                                        <div className="text-right truncate">Resterend</div>
                                        <div className="w-20"></div>
                                    </div>
                                    {/* Body */}
                                    <div className="divide-y divide-border-default">
                                        {assignmentsForTeam.map(assignment => {
                                            const project = projects.find(p => p.id === assignment.projectId);
                                            const summary = project ? projectBudgetSummary.find(s => s.projectId === project.id) : null;
                                            
                                            if (!assignment.projectId) { // Render row for new, unselected assignment
                                                return (
                                                    <div key={assignment.id} className="grid grid-cols-[minmax(0,3fr),minmax(0,1.5fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),auto] gap-x-4 items-center px-4 py-3 group/row">
                                                        <select
                                                            value=""
                                                            onChange={(e) => updateProjectAssignment({ ...assignment, projectId: e.target.value })}
                                                            className="w-full text-sm bg-surface p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default"
                                                        >
                                                            <option value="" disabled>Selecteer een project...</option>
                                                            {availableProjectsToAdd.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                                                        </select>
                                                        <div/>
                                                        <div className="text-right text-sm text-text-secondary">-</div>
                                                        <div className="text-right text-sm text-text-secondary">-</div>
                                                        <div className="text-right text-sm text-text-secondary">-</div>
                                                        <div className="text-right text-sm font-bold">-</div>
                                                        <div className="flex items-center justify-end w-20">
                                                            <Tooltip content="Verwijder" position="top">
                                                                <button onClick={() => deleteProjectAssignment(assignment.id)} className="p-1.5 text-text-secondary/70 hover:text-error rounded-md"><TrashIcon className="w-4 h-4"/></button>
                                                            </Tooltip>
                                                        </div>
                                                    </div>
                                                );
                                            }

                                            if (!project || !summary) return null; // Don't render if project is not in the filtered view

                                            return (
                                                <div key={assignment.id} className="grid grid-cols-[minmax(0,3fr),minmax(0,1.5fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),minmax(0,1fr),auto] gap-x-4 items-center px-4 py-3 hover:bg-surface group/row">
                                                    <div>
                                                        <div className="flex items-center gap-2 truncate">
                                                            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: summary.color }}></div>
                                                            <span className="font-semibold text-sm truncate">{summary.name}</span>
                                                        </div>
                                                        <div className="flex items-center gap-1">
                                                            <DebouncedInput type="date" value={assignment.startDate} onChange={val => updateProjectAssignment({ ...assignment, startDate: val })} className="p-1 text-xs rounded bg-background border-border-default w-full" />
                                                            <span className="text-xs text-text-secondary">-</span>
                                                            <DebouncedInput type="date" value={assignment.endDate || ''} onChange={val => updateProjectAssignment({ ...assignment, endDate: val })} placeholder="nvt" className="p-1 text-xs rounded bg-background border-border-default w-full" />
                                                        </div>
                                                    </div>
                                                    <div><ProjectBudgetIndicator budget={summary.budgetHours} actual={summary.historicalActuals} planned={summary.futurePlanned} isBudgetSet={summary.isBudgetSet} /></div>
                                                    <div className="text-right text-sm text-text-secondary">{summary.isBudgetSet ? `${summary.actualBudget.toFixed(0)}u` : '-'}</div>
                                                    <div className="text-right text-sm text-text-secondary">{summary.historicalActuals.toFixed(0)}u</div>
                                                    <div className="text-right text-sm text-text-secondary">{summary.futurePlanned.toFixed(0)}u</div>
                                                    <div className={`text-right text-sm font-bold ${summary.remaining < 0 ? 'text-error' : 'text-text-primary'}`}>{summary.isBudgetSet ? `${summary.remaining.toFixed(0)}u` : '-'}</div>
                                                    <div className="flex items-center justify-end w-20">
                                                        <div className="flex items-center opacity-0 group-hover/row:opacity-100 transition-opacity">
                                                            <Tooltip content={project.isHidden ? "Toon Project" : "Archiveer Project"} position="top">
                                                                <button 
                                                                    onClick={(e) => { e.stopPropagation(); updateProject({ id: project.id, isHidden: !project.isHidden }); }} 
                                                                    className="p-1.5 text-text-secondary/70 hover:text-primary rounded-md"
                                                                >
                                                                    {project.isHidden ? <EyeIcon className="w-4 h-4"/> : <EyeOffIcon className="w-4 h-4"/>}
                                                                </button>
                                                            </Tooltip>
                                                            <Tooltip content="Bulk Planner" position="top">
                                                                <button onClick={() => { setBulkPlanningProject(project); setIsBulkPlannerOpen(true); }} className="p-1.5 text-text-secondary/70 hover:text-primary rounded-md"><Wand2Icon className="w-4 h-4"/></button>
                                                            </Tooltip>
                                                            <Tooltip content="Verwijder Toewijzing" position="top">
                                                                <button onClick={() => deleteProjectAssignment(assignment.id)} className="p-1.5 text-text-secondary/70 hover:text-error rounded-md"><TrashIcon className="w-4 h-4"/></button>
                                                            </Tooltip>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                        {projectBudgetSummary.length === 0 && <p className="text-center text-xs text-text-secondary p-4">{showArchived ? "Geen projecten gekoppeld." : "Geen actieve projecten gekoppeld. Toon gearchiveerde projecten om ze te zien."}</p>}
                                    </div>
                                     {/* Footer */}
                                    <div className="bg-surface px-4 py-2">
                                        <button onClick={handleAddNewAssignment} disabled={availableProjectsToAdd.length === 0} className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold text-primary bg-primary/10 rounded-md hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed">
                                            <PlusIcon className="w-4 h-4" /> Koppel Nieuw Project
                                        </button>
                                    </div>
                                </div>
                            </details>
                        )}
                    </div>
                </header>

                <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                     {selectedTeam && (
                        <details className="group mb-4">
                            <summary className="list-none cursor-pointer inline-flex items-center gap-1 text-xs text-text-secondary hover:text-primary font-semibold">
                                Team Configuratie
                                <ChevronDownIcon className={`w-4 h-4 transition-transform group-open:rotate-180`}/>
                            </summary>
                            <div className="bg-surface p-6 rounded-xl mt-4 hidden group-open:block">
                                <div className="space-y-8">
                                    {/* General Settings */}
                                    <div>
                                        <h4 className="font-semibold mb-3 text-text-primary">Algemene Instellingen</h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                                            <div className="space-y-4">
                                                <div>
                                                    <label className="text-xs font-medium text-text-secondary block mb-1">Teamnaam</label>
                                                    <DebouncedInput value={selectedTeam.name} onChange={(val) => handleTeamConfigChange('name', val)} type="text" className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default" />
                                                </div>
                                                <div>
                                                    <label className="text-xs font-medium text-text-secondary block mb-1 flex items-center gap-1.5">
                                                        Sprintlengte (weken)
                                                        <Tooltip content="De duur van een sprint in weken. Wordt gebruikt om automatisch een jaarplanning te genereren voor dit team.">
                                                           <InfoIcon className="w-4 h-4 text-text-secondary/70" />
                                                        </Tooltip>
                                                    </label>
                                                    <DebouncedInput value={selectedTeam.defaultSprintLengthWeeks || '2'} onChange={(val) => handleTeamConfigChange('defaultSprintLengthWeeks', val)} className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default" />
                                                </div>
                                            </div>
                                            <div className="space-y-4">
                                                <div>
                                                    <label className="text-xs font-medium text-text-secondary block mb-1">Ad-hoc / SLA (%)</label>
                                                    <DebouncedInput value={selectedTeam.defaultAdhocPct} onChange={(val) => handleTeamConfigChange('defaultAdhocPct', val)} className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default" />
                                                </div>
                                                <div>
                                                    <label className="text-xs font-medium text-text-secondary block mb-1">Scrum Events (%)</label>
                                                    <DebouncedInput value={selectedTeam.defaultScrumPct} onChange={(val) => handleTeamConfigChange('defaultScrumPct', val)} className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Team Members */}
                                    <div>
                                        <div className="flex justify-between items-center mb-3">
                                            <h4 className="font-semibold text-text-primary">Teamleden</h4>
                                            <div className="relative">
                                                 <button ref={addMemberButtonRef} onClick={() => setIsAddMemberOpen(p => !p)} disabled={availableMembersToAdd.length === 0} className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-primary bg-primary/10 rounded-full hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed">
                                                    <PlusIcon className="w-4 h-4"/> Toevoegen
                                                </button>
                                                {isAddMemberOpen && (
                                                     <div ref={addMemberDropdownRef} className="absolute right-0 mt-2 w-60 bg-surface rounded-lg shadow-xl border border-border-default z-20 overflow-hidden">
                                                        <div className="max-h-60 overflow-y-auto">
                                                            {availableMembersToAdd.map(p => (
                                                                <button key={p.id} onClick={() => { handleTeamMemberChange(p.id, true); setIsAddMemberOpen(false); }} className="w-full text-left px-3 py-2 text-sm hover:bg-background">
                                                                    {p.name}
                                                                </button>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <div className="space-y-2">
                                            {teamMembers.filter(m => m.teamId === selectedTeam.id).map(memberInfo => {
                                                const person = persons.find(p => p.id === memberInfo.personId);
                                                if (!person) return null;
                                                return (
                                                    <div key={memberInfo.id} className="grid grid-cols-1 md:grid-cols-[1fr_auto_auto_auto] gap-x-4 gap-y-2 items-center p-2 bg-background rounded-lg">
                                                        <span className="font-medium">{person.name}</span>
                                                        <input type="date" title="Startdatum" value={memberInfo.startDate} onChange={e => handleTeamMemberChange(person.id, true, 'startDate', e.target.value)} className="p-1.5 text-xs rounded bg-surface border-border-default w-full" />
                                                        <input type="date" title="Einddatum" value={memberInfo.endDate || ''} onChange={e => handleTeamMemberChange(person.id, true, 'endDate', e.target.value)} className="p-1.5 text-xs rounded bg-surface border-border-default w-full" placeholder="nvt" />
                                                        <button onClick={() => handleTeamMemberChange(person.id, false)} className="p-1.5 text-text-secondary/70 hover:text-error rounded-md justify-self-end"><TrashIcon className="w-4 h-4"/></button>
                                                    </div>
                                                )
                                            })}
                                            {teamMembers.filter(m => m.teamId === selectedTeam.id).length === 0 && (
                                                 <p className="text-center text-sm text-text-secondary py-4">Geen teamleden. Voeg leden toe met de '+' knop.</p>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </details>
                    )}
                    
                    {/* Desktop Grid */}
                    <div ref={gridContainerRef} className="hidden lg:grid lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 mt-4">
                        {selectedTeam ? sprintRenderDetails.map(details => (
                                <DesktopSprintCard
                                    key={details.sprint.id}
                                    {...details}
                                    allProjects={projects}
                                    isCurrentSprint={today >= details.sprint.startDate && today <= details.sprint.endDate}
                                    isEditing={editingSprintId === details.sprint.id}
                                    onClick={() => setEditingSprintId(details.sprint.id)}
                                />
                            )
                        ) : <div className="text-center p-8 col-span-full">Selecteer een team om de planning te zien.</div>}
                    </div>
                    
                    {/* Mobile List */}
                     <div className="block lg:hidden space-y-4 mt-4">
                        {selectedTeam ? sprintRenderDetails.map(details => (
                                <MobileSprintListItem
                                    key={details.sprint.id}
                                    {...details}
                                    allProjects={projects}
                                    isCurrentSprint={today >= details.sprint.startDate && today <= details.sprint.endDate}
                                    isEditing={editingSprintId === details.sprint.id}
                                    onClick={() => setEditingSprintId(details.sprint.id)}
                                />
                            )
                        ) : <div className="text-center p-8">Selecteer een team om de planning te zien.</div>}
                    </div>

                </div>
            </div>

            <aside className={`fixed top-16 right-0 h-[calc(100vh-4rem)] w-full md:w-[400px] bg-surface/80 backdrop-blur-sm border-l border-border-default shadow-2xl transition-transform duration-300 ease-in-out z-40 ${editingSprintId ? 'translate-x-0' : 'translate-x-full'}`}>
                {editingSprintDetails && selectedTeam && (
                    <SprintDetailPanel
                        {...editingSprintDetails}
                        team={selectedTeam}
                        allTeamProjects={projectsToShowInView}
                        projectAssignments={assignmentsForTeam}
                        allAllocations={projectAllocations}
                        persons={persons}
                        globalEvents={globalEvents}
                        expandedGlobalEvents={expandedEvents.global}
                        expandedPersonEvents={expandedEvents.personal}
                        onClose={() => setEditingSprintId(null)}
                        updateSprintPlan={updateSprintPlan}
                        updateSprintEndDateAndCascade={updateSprintEndDateAndCascade}
                        setAllAllocations={setAllAllocations}
                    />
                )}
            </aside>
        </div>
    );
};

export default TeamPlanner;
