import React, { useState } from 'react';
import { Card, CardContent } from './Card';
import { Wand2Icon, ChevronDownIcon, LoaderIcon, AlertTriangleIcon, ChevronLeftIcon, ChevronRightIcon } from './icons';

interface DiscrepancyEntry {
    date: string;
    capacityHours: string;
    bookedHours: string;
    difference: string;
}

interface MonthDiscrepancies {
    [monthYear: string]: DiscrepancyEntry[];
}

interface PersonDiscrepancyGroup {
    personName: string;
    months: MonthDiscrepancies;
}

interface AnalysisResult {
    introduction: string;
    discrepancies: PersonDiscrepancyGroup[];
}

const PersonMonthNavigator: React.FC<{ group: PersonDiscrepancyGroup }> = ({ group }) => {
    const monthKeys = Object.keys(group.months);
    const [currentMonthIndex, setCurrentMonthIndex] = useState(0);
    
    if (monthKeys.length === 0) return null;

    const currentMonthKey = monthKeys[currentMonthIndex];
    const currentMonthData = group.months[currentMonthKey];

    return (
        <details className="group/person bg-background rounded-lg p-3">
            <summary className="list-none flex justify-between items-center cursor-pointer">
                <h5 className="font-bold text-text-primary">{group.personName}</h5>
                <div className="flex items-center gap-2">
                    <span className="text-sm text-error font-semibold">{monthKeys.length} maand(en) met afwijkingen</span>
                     <ChevronDownIcon className="w-5 h-5 transition-transform group-open/person:rotate-180" />
                </div>
            </summary>
            <div className="mt-4">
                 <div className="flex justify-between items-center mb-2">
                    <button 
                        onClick={() => setCurrentMonthIndex(i => i - 1)} 
                        disabled={currentMonthIndex === 0}
                        className="p-1 rounded-full hover:bg-surface disabled:opacity-50"
                        aria-label="Vorige maand"
                    >
                        <ChevronLeftIcon className="w-5 h-5" />
                    </button>
                    <span className="font-semibold text-primary">{currentMonthKey}</span>
                     <button 
                        onClick={() => setCurrentMonthIndex(i => i + 1)} 
                        disabled={currentMonthIndex >= monthKeys.length - 1}
                        className="p-1 rounded-full hover:bg-surface disabled:opacity-50"
                        aria-label="Volgende maand"
                    >
                        <ChevronRightIcon className="w-5 h-5" />
                    </button>
                 </div>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-border-default">
                        <thead className="bg-surface/50">
                            <tr>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Datum</th>
                                <th scope="col" className="px-4 py-2 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">Capaciteit</th>
                                <th scope="col" className="px-4 py-2 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">Geboekt</th>
                                <th scope="col" className="px-4 py-2 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">Verschil</th>
                            </tr>
                        </thead>
                        <tbody className="bg-background divide-y divide-border-default">
                            {currentMonthData.map(entry => (
                                <tr key={entry.date}>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-text-secondary">{entry.date}</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-text-secondary">{entry.capacityHours} u</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-text-secondary">{entry.bookedHours} u</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-right font-semibold text-error">{entry.difference} u</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </details>
    )
}

interface InsightCardProps {
    title: string;
    explanation: React.ReactNode;
    onGenerateAnalysis: () => Promise<any>;
}

const InsightCard: React.FC<InsightCardProps> = ({ title, explanation, onGenerateAnalysis }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState<any | null>(null);

    const handleGenerate = async () => {
        setIsLoading(true);
        setError(null);
        setAnalysis(null);
        try {
            const result = await onGenerateAnalysis();
            setAnalysis(result);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Onbekende fout.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderMarkdown = (text: string) => {
        const html = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/(\r\n|\n|\r)/gm, '<br />');
        return { __html: html };
    };

    const renderAnalysis = () => {
        if (!analysis) return null;

        if (typeof analysis === 'string') {
            return <div className="mt-4 p-4 bg-background rounded-lg prose prose-sm max-w-none text-text-primary" dangerouslySetInnerHTML={renderMarkdown(analysis)} />;
        }
        
        if (typeof analysis === 'object' && analysis.discrepancies) {
            const result = analysis as AnalysisResult;
            return (
                 <div className="mt-4 space-y-4 text-sm">
                    <p className="text-text-secondary">{result.introduction}</p>
                    {result.discrepancies.length > 0 ? (
                        <div className="space-y-2">
                            {result.discrepancies.map(personGroup => (
                                <PersonMonthNavigator key={personGroup.personName} group={personGroup} />
                            ))}
                        </div>
                    ) : null}
                </div>
            );
        }
        
        return null;
    }

    return (
        <Card className="bg-primary/5 dark:bg-primary/10 border-primary/20">
            <CardContent>
                <details className="group">
                    <summary className="list-none flex justify-between items-center cursor-pointer">
                        <h4 className="font-bold text-lg text-primary">{title}</h4>
                        <div className="flex items-center gap-2 text-sm font-semibold text-primary">
                            Hoe werkt dit?
                            <ChevronDownIcon className="w-5 h-5 transition-transform group-open:rotate-180" />
                        </div>
                    </summary>
                    <div className="mt-4 prose prose-sm max-w-none text-text-secondary">
                        {explanation}
                    </div>
                </details>

                <div className="mt-4 pt-4 border-t border-primary/20">
                    <div className="flex justify-between items-center">
                        <h5 className="font-semibold text-text-primary flex items-center gap-2">
                           <Wand2Icon className="w-5 h-5 text-primary"/>
                            Automatische Analyse & Advies
                        </h5>
                        <button 
                            onClick={handleGenerate} 
                            disabled={isLoading}
                            className="px-4 py-2 text-sm font-semibold text-white bg-primary hover:bg-primary-hover rounded-lg flex items-center gap-2 disabled:bg-secondary disabled:cursor-wait"
                        >
                            {isLoading ? <LoaderIcon className="w-5 h-5"/> : <Wand2Icon className="w-4 h-4" />}
                            {isLoading ? 'Analyseren...' : 'Genereer'}
                        </button>
                    </div>
                    {error && (
                        <div className="mt-4 p-3 bg-error/10 text-error text-sm rounded-lg flex items-start gap-3">
                             <AlertTriangleIcon className="w-5 h-5 mt-0.5 flex-shrink-0" />
                            <div>
                                <p className="font-bold">Fout bij Analyse</p>
                                <p>{error}</p>
                            </div>
                        </div>
                    )}
                    {renderAnalysis()}
                </div>
            </CardContent>
        </Card>
    );
};

export default InsightCard;