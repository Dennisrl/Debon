import React, { useState, useMemo, useEffect } from 'react';
import DebouncedInput from './DebouncedInput';
import { XIcon, PlusIcon, TrashIcon, InfoIcon } from './icons';
import type { SprintPlan, Team, SprintCapacityResult, Project, ProjectAllocation, Person, WorkPattern, CalendarEvent, GlobalEvent, WorkPatternEntry, ActualHoursEntry, ProjectAssignment } from '../types';
import { Tooltip } from './Tooltip';

const getWeekNumber = (d: Date): number => {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return weekNo;
};

const getScheduledHoursForDay = (person: Person, date: Date, workPatterns: WorkPatternEntry[]): number => {
    const dayStr = date.toISOString().split('T')[0];
    const applicablePatternEntry = workPatterns
        .filter(p => p.startDate <= dayStr)
        .sort((a, b) => b.startDate.localeCompare(a.startDate))[0];

    if (!applicablePatternEntry) return 0;
    const workPattern = applicablePatternEntry.pattern;
    
    const dayOfWeekIndex = (date.getUTCDay() + 6) % 7; // Monday = 0
    const dayKey = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'][dayOfWeekIndex] as keyof WorkPattern['standardHours'];

    if (workPattern.type === 'even-odd' && workPattern.evenWeekHours && workPattern.oddWeekHours) {
        return parseFloat((getWeekNumber(date) % 2 === 0 ? workPattern.evenWeekHours : workPattern.oddWeekHours)?.[dayKey] || '0');
    }
    return parseFloat(workPattern.standardHours?.[dayKey] || '0');
};


const CapacityTooltipContent: React.FC<{
    person: Person;
    sprint: SprintPlan;
    expandedGlobalEventsInSprint: (GlobalEvent & { originalId: string })[];
    expandedPersonalEventsInSprint: (CalendarEvent & { originalId: string })[];
    allGlobalEvents: GlobalEvent[];
}> = ({ person, sprint, expandedGlobalEventsInSprint, expandedPersonalEventsInSprint, allGlobalEvents }) => {

    const sprintStart = new Date(sprint.startDate + 'T00:00:00.000Z');
    const sprintEnd = new Date(sprint.endDate + 'T00:00:00.000Z');

    const combinedEvents = [
        ...expandedGlobalEventsInSprint.map(e => ({ ...e, isGlobal: true })),
        ...expandedPersonalEventsInSprint.map(e => ({ ...e, isGlobal: false })),
    ];
    
    const groupedEvents = combinedEvents.reduce((acc, event) => {
        const key = event.originalId;
        if (!acc[key]) {
            acc[key] = [];
        }
        acc[key].push(event);
        return acc;
    }, {} as Record<string, typeof combinedEvents>);


    const eventDetails = Object.values(groupedEvents).map(instances => {
        const firstInstance = instances[0];
        const originalEvent = firstInstance.isGlobal
            ? allGlobalEvents.find(e => e.id === firstInstance.originalId)
            : person.events?.find(e => e.id === firstInstance.originalId);

        if (!originalEvent) return null;

        let totalImpactHours = 0;
        let minDateInSprint: Date | null = null;
        let maxDateInSprint: Date | null = null;

        for (const instance of instances) {
            const instanceStart = new Date(instance.startDate + 'T00:00:00.000Z');
            const instanceEnd = new Date(instance.endDate + 'T00:00:00.000Z');

            for (let d = new Date(instanceStart.getTime()); d <= instanceEnd; d.setUTCDate(d.getUTCDate() + 1)) {
                if (d < sprintStart || d > sprintEnd) continue;
                
                if (!minDateInSprint || d < minDateInSprint) minDateInSprint = new Date(d.getTime());
                if (!maxDateInSprint || d > maxDateInSprint) maxDateInSprint = new Date(d.getTime());
                
                const dayOfWeek = d.getUTCDay();
                if (dayOfWeek === 0 || dayOfWeek === 6) continue;

                if (instance.durationType === 'hours') {
                    const hours = parseFloat(instance.hours || '0');
                    if (instance.type === 'extra') {
                        totalImpactHours += hours;
                    } else {
                        totalImpactHours -= hours;
                    }
                } else {
                    const scheduledHours = getScheduledHoursForDay(person, d, person.workPatterns);
                    totalImpactHours -= scheduledHours;
                }
            }
        }
        
        if (totalImpactHours === 0 && (!minDateInSprint || !maxDateInSprint)) {
            return null;
        }

        const dateDisplay = minDateInSprint && maxDateInSprint
            ? minDateInSprint.getTime() === maxDateInSprint.getTime()
                ? minDateInSprint.toLocaleDateString('nl-NL', { month: 'short', day: 'numeric', timeZone: 'UTC' })
                : `${minDateInSprint.toLocaleDateString('nl-NL', { month: 'short', day: 'numeric', timeZone: 'UTC' })} - ${maxDateInSprint.toLocaleDateString('nl-NL', { month: 'short', day: 'numeric', timeZone: 'UTC' })}`
            : "Geen impact in sprint";


        return {
            id: originalEvent.id,
            title: originalEvent.title,
            dateDisplay,
            impact: totalImpactHours,
            isRecurring: !!originalEvent.recurrenceRule,
            isExtra: originalEvent.type === 'extra'
        };
    }).filter((e): e is NonNullable<typeof e> => e !== null).sort((a,b) => a.title.localeCompare(b.title));

    return (
        <div className="text-left font-normal max-w-xs text-xs">
            <h5 className="font-bold text-sm mb-1 pb-1 border-b border-border-default">Capaciteitsinvloeden</h5>
            {eventDetails.length > 0 ? (
                <ul className="space-y-1 mt-1">
                    {eventDetails.map(e => (
                        <li key={e.id} className="flex justify-between items-center">
                            <span className="truncate pr-2">{e.title} {e.isRecurring && '(H)'}</span>
                            <span className={`font-semibold whitespace-nowrap ${e.isExtra ? 'text-success' : 'text-error'}`}>{e.impact > 0 ? '+' : ''}{e.impact.toFixed(1)}u</span>
                        </li>
                    ))}
                </ul>
            ) : <p className="text-text-secondary italic">Geen invloeden in deze sprint.</p>}
        </div>
    );
};


const SprintDetailPanel: React.FC<{
    sprint: SprintPlan;
    sprintNumber: number;
    team: Team;
    capacity: SprintCapacityResult;
    allocations: ProjectAllocation[];
    allTeamProjects: Project[];
    projectAssignments: ProjectAssignment[];
    allAllocations: ProjectAllocation[];
    isPastSprint: boolean;
    persons: Person[];
    globalEvents: GlobalEvent[];
    expandedGlobalEvents: (GlobalEvent & { originalId: string; })[];
    expandedPersonEvents: Map<string, (CalendarEvent & { originalId: string; })[]>;
    actualHoursData?: ActualHoursEntry[];
    onClose: () => void;
    dispatch: React.Dispatch<any>;
}> = ({ sprint, sprintNumber, team, capacity, allocations, allTeamProjects, projectAssignments, allAllocations, isPastSprint, persons, globalEvents, expandedGlobalEvents, expandedPersonEvents, actualHoursData, onClose, dispatch }) => {
    
    const [adhocOverride, setAdhocOverride] = useState(sprint.adhocPctOverride ?? '');
    const [scrumOverride, setScrumOverride] = useState(sprint.scrumPctOverride ?? '');
    const [projectAllocations, setProjectAllocations] = useState(allocations);
    const [localStartDate, setLocalStartDate] = useState(sprint.startDate);
    const [localEndDate, setLocalEndDate] = useState(sprint.endDate);

    const projectMap = useMemo(() => new Map(allTeamProjects.map(p => [p.id, p])), [allTeamProjects]);

    useEffect(() => {
        setProjectAllocations(allocations);
        setLocalStartDate(sprint.startDate);
        setLocalEndDate(sprint.endDate);
    }, [allocations, sprint.startDate, sprint.endDate]);

    const handleAllocationChange = (projectId: string, hours: string) => {
        const newAllocations = [...projectAllocations];
        const existingIndex = newAllocations.findIndex(a => a.projectId === projectId);
        if (existingIndex > -1) {
            newAllocations[existingIndex] = { ...newAllocations[existingIndex], plannedHours: hours };
        } else {
            newAllocations.push({ id: crypto.randomUUID(), sprintId: sprint.id, projectId, plannedHours: hours });
        }
        setProjectAllocations(newAllocations);
    };
    
    const handleSaveAllocations = () => {
        const otherAllocations = allAllocations.filter(a => a.sprintId !== sprint.id);
        const thisSprintFinalAllocations = projectAllocations.filter(a => parseFloat(a.plannedHours) > 0);
        dispatch({ type: 'SET_ALLOCATIONS', payload: [...otherAllocations, ...thisSprintFinalAllocations] });
    };

    const totalProjectHours = projectAllocations.reduce((sum, alloc) => sum + (parseFloat(alloc.plannedHours) || 0), 0);
    const totalFilledIn = capacity.adhocHours + capacity.scrumHours + totalProjectHours;
    const remainingHours = capacity.totalAvailableHours - totalProjectHours;
    
    const projectsToDisplay = useMemo(() => {
        const sprintStart = new Date(sprint.startDate);
        const sprintEnd = new Date(sprint.endDate);

        const projectsWithActiveAssignment = allTeamProjects.filter(p => {
            const assignment = projectAssignments.find(pa => pa.projectId === p.id);
            if (!assignment) return false;

            const assignmentStart = new Date(assignment.startDate);
            const assignmentEnd = assignment.endDate ? new Date(assignment.endDate) : new Date('9999-12-31');

            return sprintStart <= assignmentEnd && sprintEnd >= assignmentStart;
        });
        
        // For past sprints, also show projects that have allocations, even if assignment ended.
        if (isPastSprint) {
            const projectsWithAllocations = new Set(allocations.map(a => a.projectId));
            allTeamProjects.forEach(p => {
                if(projectsWithAllocations.has(p.id) && !projectsWithActiveAssignment.some(pa => pa.id === p.id)) {
                    projectsWithActiveAssignment.push(p);
                }
            });
        }
        
        return projectsWithActiveAssignment;
    }, [allTeamProjects, projectAssignments, sprint, isPastSprint, allocations]);


    return (
        <div className="h-full flex flex-col">
            <header className="p-4 border-b border-border-default flex justify-between items-center flex-shrink-0">
                <div>
                    <h3 className="text-xl font-bold text-text-primary">{sprint.name}</h3>
                    <p className="text-sm text-text-secondary">{new Date(sprint.startDate+'T00:00:00').toLocaleDateString('nl-NL')} - {new Date(sprint.endDate+'T00:00:00').toLocaleDateString('nl-NL')}</p>
                </div>
                <button onClick={onClose} aria-label="Sluiten" className="p-1 text-text-secondary hover:text-text-primary"><XIcon className="w-5 h-5"/></button>
            </header>

            <div className="flex-grow overflow-y-auto p-4 space-y-4">
                <div className="bg-background rounded-lg p-3">
                    <div className="grid grid-cols-3 text-center text-xs">
                        <div>
                            <p className="font-bold text-lg">{capacity.totalAvailableHours.toFixed(0)}</p>
                            <p className="text-text-secondary">Beschikbaar</p>
                        </div>
                        <div>
                            <p className="font-bold text-lg">{totalProjectHours.toFixed(0)}</p>
                            <p className="text-text-secondary">Projectwerk</p>
                        </div>
                        <div>
                            <p className={`font-bold text-lg ${remainingHours < 0 ? 'text-error' : 'text-success'}`}>{remainingHours.toFixed(0)}</p>
                            <p className="text-text-secondary">Resterend</p>
                        </div>
                    </div>
                </div>

                <h4 className="font-semibold text-text-primary pt-2">Sprint Instellingen</h4>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs font-medium text-text-secondary block mb-1">Startdatum</label>
                         <input
                            type="date"
                            value={localStartDate}
                            onChange={(e) => setLocalStartDate(e.target.value)}
                            onBlur={() => dispatch({ type: 'UPDATE_SPRINT_PLAN', payload: { id: sprint.id, startDate: localStartDate } })}
                            className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default disabled:opacity-50"
                        />
                    </div>
                    <div>
                        <label className="text-xs font-medium text-text-secondary block mb-1">Einddatum (cascadeert)</label>
                         <input
                            type="date"
                            value={localEndDate}
                            onChange={(e) => setLocalEndDate(e.target.value)}
                            onBlur={() => dispatch({ type: 'UPDATE_SPRINT_END_DATE_AND_CASCADE', payload: { sprintId: sprint.id, newEndDate: localEndDate, teamId: team.id }})}
                            className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default disabled:opacity-50"
                        />
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs font-medium text-text-secondary block mb-1">Ad-hoc / SLA (%)</label>
                        <DebouncedInput value={adhocOverride} onChange={(val) => { setAdhocOverride(val); dispatch({ type: 'UPDATE_SPRINT_PLAN', payload: { id: sprint.id, adhocPctOverride: val }})}} placeholder={team.defaultAdhocPct} disabled={isPastSprint} className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default disabled:opacity-50"/>
                    </div>
                     <div>
                        <label className="text-xs font-medium text-text-secondary block mb-1">Scrum Events (%)</label>
                        <DebouncedInput value={scrumOverride} onChange={(val) => { setScrumOverride(val); dispatch({ type: 'UPDATE_SPRINT_PLAN', payload: { id: sprint.id, scrumPctOverride: val }})}} placeholder={team.defaultScrumPct} disabled={isPastSprint} className="w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default disabled:opacity-50"/>
                    </div>
                </div>

                <h4 className="font-semibold text-text-primary pt-2">{isPastSprint ? "Werkelijke uren" : "Geplande uren"}</h4>
                <div className="space-y-2">
                    {projectsToDisplay.map(p => {
                        const allocation = projectAllocations.find(a => a.projectId === p.id);
                        if (!allocation && isPastSprint) return null; // Only show projects with hours in past sprints
                        return (
                            <div key={p.id} className="grid grid-cols-[auto,1fr,80px] items-center gap-3">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color}}></div>
                                <span className="text-sm font-medium truncate">{p.name}</span>
                                <DebouncedInput
                                    value={allocation?.plannedHours || ''}
                                    onChange={(val) => handleAllocationChange(p.id, val)}
                                    onBlur={handleSaveAllocations}
                                    disabled={isPastSprint}
                                    placeholder="0"
                                    className="w-full text-sm text-right bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default disabled:opacity-50"
                                />
                            </div>
                        );
                    })}
                </div>

                <h4 className="font-semibold text-text-primary pt-2">Teamcapaciteit</h4>
                <div className="space-y-1">
                    {capacity.personHours.map(({ personId, hours }) => {
                        const person = persons.find(p => p.id === personId);
                        if (!person) return null;
                        
                        const sprintStart = new Date(sprint.startDate + 'T00:00:00.000Z');
                        const sprintEnd = new Date(sprint.endDate + 'T00:00:00.000Z');

                        const expandedPersonalEventsInSprint = (expandedPersonEvents.get(personId) || []).filter(e => {
                            const eventStart = new Date(e.startDate + 'T00:00:00.000Z');
                            const eventEnd = new Date(e.endDate + 'T00:00:00.000Z');
                            return eventStart <= sprintEnd && eventEnd >= sprintStart;
                        });

                        const expandedGlobalEventsInSprint = expandedGlobalEvents.filter(e => {
                            const eventStart = new Date(e.startDate + 'T00:00:00.000Z');
                            const eventEnd = new Date(e.endDate + 'T00:00:00.000Z');
                            return eventStart <= sprintEnd && eventEnd >= sprintStart;
                        });
                        
                        return (
                             <div key={personId} className="flex justify-between items-center text-sm p-2 bg-background rounded-md">
                                <span className="font-medium">{person.name}</span>
                                <div className="flex items-center gap-2">
                                    {(expandedPersonalEventsInSprint.length > 0 || expandedGlobalEventsInSprint.length > 0) && (
                                        <Tooltip position="left" content={
                                            <CapacityTooltipContent 
                                                person={person} 
                                                sprint={sprint} 
                                                expandedGlobalEventsInSprint={expandedGlobalEventsInSprint} 
                                                expandedPersonalEventsInSprint={expandedPersonalEventsInSprint}
                                                allGlobalEvents={globalEvents}
                                            />
                                        }>
                                            <InfoIcon className="w-4 h-4 text-text-secondary/70 hover:text-text-primary" />
                                        </Tooltip>
                                    )}
                                    <span className="font-semibold">{hours.toFixed(1)}u</span>
                                </div>
                            </div>
                        )
                    })}
                </div>

            </div>
        </div>
    );
};

export default SprintDetailPanel;