import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  leftIcon?: React.ReactNode;
  size?: 'normal' | 'large';
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', leftIcon, size = 'normal', ...props }) => {
  const baseClasses =
    'inline-flex items-center justify-center gap-2 font-semibold rounded-lg shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';

  const sizeClasses = {
    normal: 'px-4 py-2 text-sm',
    large: 'px-8 py-3 text-base',
  };

  const variantClasses = {
    primary:
      'bg-primary text-neutral-white hover:bg-primary-hover focus:ring-primary',
    secondary:
      'bg-secondary text-neutral-white hover:bg-secondary-hover focus:ring-secondary',
  };

  return (
    <button className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]}`} {...props}>
      {leftIcon && <span className="mr-1">{leftIcon}</span>}
      {children}
    </button>
  );
};

export default Button;