import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from './Card';
import { SlidersIcon, InfoIcon, AlertTriangleIcon } from './icons';
import { Tooltip } from './Tooltip';

const InputGroup: React.FC<{
  label: string;
  tooltip: string;
  value: string;
  setValue: (val: string) => void;
  placeholder: string;
  type?: string;
  disabled: boolean;
}> = ({ label, tooltip, value, setValue, placeholder, type = 'number', disabled }) => {
    const [internalValue, setInternalValue] = useState(value);

    useEffect(() => {
        // Sync with parent state if it changes from outside
        if (value !== internalValue) {
            setInternalValue(value);
        }
    }, [value]);

    const handleBlur = () => {
        // Only trigger update if the value has actually changed
        if (value !== internalValue) {
            setValue(internalValue);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleBlur();
            (e.target as HTMLInputElement).blur();
        }
    };

    return (
        <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">
                {label}
                <Tooltip content={tooltip}>
                    <InfoIcon className="inline-block ml-2 text-text-secondary/80 hover:text-text-primary cursor-help" />
                </Tooltip>
            </label>
            <input
                type={type}
                value={internalValue}
                onChange={(e) => setInternalValue(e.target.value)}
                onBlur={handleBlur}
                onKeyDown={handleKeyDown}
                placeholder={placeholder}
                className="w-full px-4 py-2.5 text-base text-text-primary bg-background border border-border-default rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition disabled:bg-background/50"
                disabled={disabled}
                min="0"
            />
        </div>
    );
};

interface SimulationInputsProps {
  totalPoints: string;
  setTotalPoints: (value: string) => void;
  avgHoursPerPoint: string;
  setAvgHoursPerPoint: (value: string) => void;
  velocityPerSprint: string;
  setVelocityPerSprint: (value: string) => void;
  totalBudget: string;
  setTotalBudget: (value: string) => void;
  hourlyRate: string;
  setHourlyRate: (value: string) => void;
  rangePercentage: string;
  setRangePercentage: (value: string) => void;
  disabled: boolean;
  error: string | null;
  info: string | null;
}

const SimulationInputs: React.FC<SimulationInputsProps> = ({
  totalPoints, setTotalPoints,
  avgHoursPerPoint, setAvgHoursPerPoint,
  velocityPerSprint, setVelocityPerSprint,
  totalBudget, setTotalBudget,
  hourlyRate, setHourlyRate,
  rangePercentage, setRangePercentage,
  disabled, error, info
}) => {
  return (
    <Card>
      <CardHeader icon={<SlidersIcon className="w-6 h-6"/>}>Basisparameters</CardHeader>
      <CardContent className="space-y-4">
        {info && !error && (
             <div className="bg-primary/10 border border-primary/30 text-primary px-4 py-3 rounded-lg flex items-start gap-3">
                <InfoIcon className="w-5 h-5 mt-0.5 text-primary"/>
                <p className="text-sm">{info}</p>
            </div>
        )}
        {error && (
            <div className="bg-error/10 border border-error/30 text-error px-4 py-3 rounded-lg flex items-start gap-3">
                <AlertTriangleIcon className="w-5 h-5 mt-0.5 text-error"/>
                <div>
                    <h4 className="font-bold">Invoerfout</h4>
                    <p className="text-sm">{error}</p>
                </div>
            </div>
        )}
        
        <div className="space-y-4">
             <InputGroup
                label="Totaal aantal story points"
                tooltip="Het totaal aantal te voltooien story points voor dit project of deze epic."
                value={totalPoints}
                setValue={setTotalPoints}
                placeholder="bijv. 250"
                disabled={disabled}
            />
             <div className="grid grid-cols-2 gap-4">
                <InputGroup
                    label="Gem. uren per point"
                    tooltip="De verwachte gemiddelde hoeveelheid uren die nodig is om één story point te voltooien."
                    value={avgHoursPerPoint}
                    setValue={setAvgHoursPerPoint}
                    placeholder="bijv. 4"
                    disabled={disabled}
                />
                <InputGroup
                    label="Geplande velocity per sprint"
                    tooltip="De geplande hoeveelheid story points die het team per sprint denkt te voltooien. Dit bepaalt de initiële sprintlijst en prognose."
                    value={velocityPerSprint}
                    setValue={setVelocityPerSprint}
                    placeholder="bijv. 20"
                    disabled={disabled}
                />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <InputGroup
                    label="Budget (€)"
                    tooltip="Het totale beschikbare budget voor dit project. Dit wordt als lijn in de budgetgrafiek getoond."
                    value={totalBudget}
                    setValue={setTotalBudget}
                    placeholder="bijv. 50000"
                    disabled={disabled}
                />
                <InputGroup
                    label="Uurtarief (€)"
                    tooltip="De gemiddelde kosten per uur voor een teamlid. Wordt gebruikt om de kosten te berekenen."
                    value={hourlyRate}
                    setValue={setHourlyRate}
                    placeholder="bijv. 85"
                    disabled={disabled}
                />
            </div>
            <InputGroup
                label="Onzekerheidsmarge (%)"
                tooltip="De procentuele afwijking voor de optimistische en pessimistische scenario's. 20% betekent 20% sneller én 20% langzamer."
                value={rangePercentage}
                setValue={setRangePercentage}
                placeholder="bijv. 20"
                disabled={disabled}
            />
        </div>
      </CardContent>
    </Card>
  );
};

export default SimulationInputs;