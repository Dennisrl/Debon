import React from 'react';
import type { SprintPlan, SprintCapacityResult, ProjectAllocation, Project } from '../types';
import CapacityBar from './CapacityBar';

interface DesktopSprintCardProps {
    sprint: SprintPlan;
    capacity: SprintCapacityResult;
    allocations: ProjectAllocation[];
    allProjects: Project[];
    isPastSprint: boolean;
    isCurrentSprint: boolean;
    isEditing: boolean;
    onClick: () => void;
}

const DesktopSprintCard: React.FC<DesktopSprintCardProps> = ({
    sprint, capacity, allocations, allProjects, isPastSprint, isCurrentSprint, isEditing, onClick
}) => {
    
    const totalHours = allocations.reduce((s, a) => s + (parseFloat(a.plannedHours) || 0), 0) + capacity.adhocHours + capacity.scrumHours;
    const utilization = capacity.totalRawHours > 0 ? (totalHours / capacity.totalRawHours * 100) : 0;
    const label = isPastSprint ? 'Werkelijk' : 'Ingepland';

    return (
        <div data-sprint-id={sprint.id} onClick={onClick}
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${isEditing ? 'border-primary shadow-lg' : 'border-border-default hover:border-primary/50'} bg-surface ${isCurrentSprint ? 'ring-2 ring-warning ring-offset-2 ring-offset-background' : ''}`}>
            
            <div className="flex justify-between items-start mb-3">
                <div>
                    <p className="font-bold text-text-primary flex items-center gap-2">
                        {sprint.name}
                        {isCurrentSprint && <span className="w-2.5 h-2.5 bg-warning rounded-full" title="Huidige sprint"></span>}
                    </p>
                    <p className="text-sm text-text-secondary">
                        {new Date(sprint.startDate+'T00:00:00').toLocaleDateString('nl-NL', {day:'numeric', month:'short'})} - {new Date(sprint.endDate+'T00:00:00').toLocaleDateString('nl-NL', {day:'numeric', month:'short'})}
                    </p>
                </div>
                <div className="text-right">
                    <p className={`text-lg font-bold ${utilization > 100 ? 'text-error' : 'text-text-primary'}`}>{utilization.toFixed(0)}%</p>
                </div>
            </div>

            <CapacityBar capacity={capacity} allocations={allocations} projects={allProjects} />

            <div className="mt-3 text-xs flex justify-between items-center">
                <div className="text-text-secondary">
                    {label}: <span className={`font-semibold ${utilization > 100 ? 'text-error' : 'text-text-primary'}`}>{totalHours.toFixed(0)}u</span>
                </div>
                <div className="text-text-secondary">
                    Capaciteit: <span className="font-semibold text-text-primary">{capacity.totalRawHours.toFixed(0)}u</span>
                </div>
            </div>
        </div>
    );
};

export default DesktopSprintCard;