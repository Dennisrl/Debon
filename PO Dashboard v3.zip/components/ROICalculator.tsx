import React, { useState, useMemo, useEffect } from 'react';
import { ResponsiveContainer, ComposedChart, CartesianGrid, XAxis, YAxis, Tooltip, Area, Line, ReferenceLine } from 'recharts';
import type { Project, ROI, CostSavingItem, RevenueItem } from '../types';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader } from './Card';
import { CalculatorIcon, PlusIcon, TrashIcon, TrendingUpIcon, ChevronDownIcon } from './icons';

const formatCurrency = (value: number | undefined | null, digits: number = 0) => {
    if (value == null || isNaN(value)) return `€ 0`;
    return new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value);
};

const SummaryBox: React.FC<{ title: string; value: string; subtext?: string; }> = ({ title, value, subtext }) => (
    <div className="p-4 rounded-xl bg-background">
        <p className="text-sm font-medium text-text-secondary">{title}</p>
        <p className="text-2xl font-bold text-text-primary mt-1">{value}</p>
        {subtext && <p className="text-xs text-text-secondary mt-2">{subtext}</p>}
    </div>
);

const ROICalculator: React.FC<{ project: Project; }> = ({ project }) => {
    const { updateProject } = useData();
    const [roiState, setRoiState] = useState<ROI>(project.roi || { revenues: [], costSavings: [] });
    const inputClasses = "w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default";


    useEffect(() => setRoiState(project.roi || { revenues: [], costSavings: [] }), [project.roi]);

    const handleRoiChange = (newRoi: ROI) => {
        setRoiState(newRoi);
        updateProject({ id: project.id, roi: newRoi });
    };
    
    // --- Handlers for Revenues ---
    const addRevenue = () => {
        const newItem: RevenueItem = { id: crypto.randomUUID(), description: '', amount: '', count: '1', frequency: 'monthly' };
        handleRoiChange({ ...roiState, revenues: [...(roiState.revenues || []), newItem] });
    };
    const updateRevenue = (id: string, field: keyof RevenueItem, value: any) => {
        const updated = (roiState.revenues || []).map(item => item.id === id ? { ...item, [field]: value } : item);
        handleRoiChange({ ...roiState, revenues: updated });
    };
    const removeRevenue = (id: string) => {
        const updated = (roiState.revenues || []).filter(item => item.id !== id);
        handleRoiChange({ ...roiState, revenues: updated });
    };

    // --- Handlers for Cost Savings ---
    const addCostSaving = () => {
        const newItem: CostSavingItem = { id: crypto.randomUUID(), type: 'time', description: '', timePerAction: '', actionsPerWeek: '', timeUnit: 'minutes', frequencyUnit: 'week', hourlyRate: '' };
        handleRoiChange({ ...roiState, costSavings: [...(roiState.costSavings || []), newItem] });
    };
    const updateCostSaving = (id: string, field: string, value: any) => {
        const updated: CostSavingItem[] = (roiState.costSavings || []).map(item => {
            if (item.id === id) {
                 if (field === 'type' && value === 'fixed') {
                    return { id: item.id, type: 'fixed', description: item.description, amount: '', frequency: 'monthly' };
                }
                if (field === 'type' && value === 'time') {
                    return { id: item.id, type: 'time', description: item.description, timePerAction: '', timeUnit: 'minutes', actionsPerWeek: '', frequencyUnit: 'week', hourlyRate: '' };
                }
                const newItem = { ...item };
                (newItem as any)[field] = value;
                return newItem;
            }
            return item;
        });
        handleRoiChange({ ...roiState, costSavings: updated });
    };
    const removeCostSaving = (id: string) => {
        const updated = (roiState.costSavings || []).filter(item => item.id !== id);
        handleRoiChange({ ...roiState, costSavings: updated });
    };


    const { totalYearlyReturn, netInvestment, breakEvenInMonths, chartData, gradientOffset } = useMemo(() => {
        let totalYearlyRecurringRevenue = (roiState.revenues || []).reduce((acc, item) => {
            const total = (parseFloat(item.amount) || 0) * (parseFloat(item.count) || 1);
            if (item.frequency === 'monthly') return acc + total * 12;
            if (item.frequency === 'yearly') return acc + total;
            return acc;
        }, 0);
        let totalOneTimeRevenue = (roiState.revenues || []).reduce((acc, item) => (item.frequency === 'one-time' ? acc + (parseFloat(item.amount) || 0) * (parseFloat(item.count) || 1) : acc), 0);
        
        let totalYearlyRecurringSavings = (roiState.costSavings || []).reduce((acc, item) => {
            if (item.type === 'time') {
                const hoursPerAction = item.timeUnit === 'minutes' ? (parseFloat(item.timePerAction) || 0) / 60 : (parseFloat(item.timePerAction) || 0);
                const yearlyActions = item.frequencyUnit === 'week' ? (parseFloat(item.actionsPerWeek) || 0) * 52 : (parseFloat(item.actionsPerWeek) || 0) * 12;
                return acc + (hoursPerAction * yearlyActions * (parseFloat(item.hourlyRate) || 0));
            } else if (item.type === 'fixed') {
                const amount = parseFloat(item.amount) || 0;
                if (item.frequency === 'monthly') return acc + amount * 12;
                if (item.frequency === 'yearly') return acc + amount;
            }
            return acc;
        }, 0);
        let totalOneTimeSavings = (roiState.costSavings || []).reduce((acc, item) => (item.type === 'fixed' && item.frequency === 'one-time' ? acc + (parseFloat(item.amount) || 0) : acc), 0);

        const totalYearlyReturn = totalYearlyRecurringRevenue + totalYearlyRecurringSavings;
        const totalMonthlyReturn = totalYearlyReturn / 12;
        const netInvestment = (parseFloat(project.totalBudget) || 0) - totalOneTimeRevenue - totalOneTimeSavings;
        const breakEvenInMonths = netInvestment > 0 && totalMonthlyReturn > 0 ? netInvestment / totalMonthlyReturn : 0;
        
        let chartData: { month: number; value: number }[] = [];
        let gradientOffset = 1;
        const initialReturn = totalOneTimeRevenue + totalOneTimeSavings;
        if (netInvestment > 0 && totalMonthlyReturn > 0) {
            const displayMonths = Math.max(36, Math.ceil(breakEvenInMonths * 1.5));
            for (let i = 0; i <= displayMonths; i++) chartData.push({ month: i, value: initialReturn + (i * totalMonthlyReturn) });
            gradientOffset = Math.min(1, breakEvenInMonths / displayMonths);
        } else if (netInvestment <= 0) {
            chartData = [{ month: 0, value: initialReturn }, { month: 36, value: initialReturn + (36 * totalMonthlyReturn) }];
            gradientOffset = 0;
        }

        return { totalYearlyRecurringRevenue, totalOneTimeRevenue, totalYearlyRecurringSavings, totalOneTimeSavings, totalYearlySavings: totalYearlyRecurringSavings, totalYearlyReturn, totalMonthlyReturn, netInvestment, breakEvenInMonths, chartData, gradientOffset };
    }, [roiState, project.totalBudget]);
    
    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <div className="mb-8"><h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">ROI Calculator</h2><p className="mt-2 text-text-secondary">Analyseer de terugverdientijd van uw investering.</p></div>
            <div className="space-y-12">
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
                    <Card><CardHeader icon={<TrendingUpIcon className="w-6 h-6"/>}>Opbrengsten</CardHeader><CardContent className="space-y-4">
                        {(roiState.revenues || []).map(item => (
                            <div key={item.id} className="p-3 bg-background rounded-lg space-y-3 relative group">
                                <button onClick={() => removeRevenue(item.id)} className="absolute top-2 right-2 p-1 text-text-secondary hover:text-error rounded-md opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4"/></button>
                                <input type="text" value={item.description} onChange={e => updateRevenue(item.id, 'description', e.target.value)} placeholder="Omschrijving opbrengst" className={inputClasses} />
                                <div className="grid grid-cols-3 gap-2">
                                    <input type="number" value={item.amount} onChange={e => updateRevenue(item.id, 'amount', e.target.value)} placeholder="Bedrag" className={inputClasses}/>
                                    <input type="number" value={item.count} onChange={e => updateRevenue(item.id, 'count', e.target.value)} placeholder="Aantal" className={inputClasses}/>
                                    <select value={item.frequency} onChange={e => updateRevenue(item.id, 'frequency', e.target.value)} className={inputClasses}>
                                        <option value="one-time">Eenmalig</option><option value="monthly">Maandelijks</option><option value="yearly">Jaarlijks</option>
                                    </select>
                                </div>
                            </div>
                        ))}
                        <button onClick={addRevenue} className="w-full flex items-center justify-center gap-2 py-2 text-sm font-semibold text-primary hover:bg-primary/10 rounded-lg transition-colors"><PlusIcon className="w-4 h-4"/>Opbrengst toevoegen</button>
                    </CardContent></Card>
                    <Card><CardHeader icon={<CalculatorIcon className="w-6 h-6"/>}>Kostenbesparingen</CardHeader><CardContent className="space-y-4">
                        {(roiState.costSavings || []).map(item => (
                            <div key={item.id} className="p-3 bg-background rounded-lg space-y-3 relative group">
                                <button onClick={() => removeCostSaving(item.id)} className="absolute top-2 right-2 p-1 text-text-secondary hover:text-error rounded-md opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4"/></button>
                                <div className="grid grid-cols-2 gap-2">
                                    <input type="text" value={item.description} onChange={e => updateCostSaving(item.id, 'description', e.target.value)} placeholder="Omschrijving besparing" className={inputClasses}/>
                                    <select value={item.type} onChange={e => updateCostSaving(item.id, 'type', e.target.value)} className={inputClasses}>
                                        <option value="time">Tijdbesparing</option><option value="fixed">Vaste besparing</option>
                                    </select>
                                </div>
                                {item.type === 'time' && (
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                        <input type="number" value={item.timePerAction} onChange={e => updateCostSaving(item.id, 'timePerAction', e.target.value)} placeholder="Tijd/actie" className={inputClasses}/>
                                        <select value={item.timeUnit} onChange={e => updateCostSaving(item.id, 'timeUnit', e.target.value)} className={inputClasses}><option value="minutes">min</option><option value="hours">uur</option></select>
                                        <input type="number" value={item.actionsPerWeek} onChange={e => updateCostSaving(item.id, 'actionsPerWeek', e.target.value)} placeholder="Acties" className={inputClasses}/>
                                        <select value={item.frequencyUnit} onChange={e => updateCostSaving(item.id, 'frequencyUnit', e.target.value)} className={inputClasses}><option value="week">/ week</option><option value="month">/ mnd</option></select>
                                        <input type="number" value={item.hourlyRate} onChange={e => updateCostSaving(item.id, 'hourlyRate', e.target.value)} placeholder="Uurtarief" className={`${inputClasses} col-span-full`}/>
                                    </div>
                                )}
                                {item.type === 'fixed' && (
                                     <div className="grid grid-cols-2 gap-2">
                                        <input type="number" value={item.amount} onChange={e => updateCostSaving(item.id, 'amount', e.target.value)} placeholder="Bedrag" className={inputClasses}/>
                                        <select value={item.frequency} onChange={e => updateCostSaving(item.id, 'frequency', e.target.value)} className={inputClasses}>
                                            <option value="one-time">Eenmalig</option><option value="monthly">Maandelijks</option><option value="yearly">Jaarlijks</option>
                                        </select>
                                    </div>
                                )}
                            </div>
                        ))}
                        <button onClick={addCostSaving} className="w-full flex items-center justify-center gap-2 py-2 text-sm font-semibold text-primary hover:bg-primary/10 rounded-lg transition-colors"><PlusIcon className="w-4 h-4"/>Besparing toevoegen</button>
                    </CardContent></Card>
                </div>
                {/* Summary & Chart */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-1"><Card><CardContent className="text-center"><p className="text-lg font-semibold text-text-secondary">Terugverdientijd</p><p className="text-5xl font-extrabold text-primary my-3">{netInvestment <= 0 ? 'Direct' : breakEvenInMonths > 0 ? `${breakEvenInMonths.toFixed(1)} mnd` : 'N.v.t.'}</p></CardContent></Card></div>
                    <div className="lg:col-span-2"><Card><CardContent><h4 className="text-lg font-bold mb-4">Break-Even Prognose</h4><div className="h-72 w-full">
                        <ResponsiveContainer>
                            <ComposedChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                                <defs>
                                    <linearGradient id="roiGradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset={gradientOffset} stopColor="var(--color-error-main)" stopOpacity={0.4}/>
                                        <stop offset={gradientOffset} stopColor="var(--color-success-main)" stopOpacity={0.4}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke={'var(--color-border)'} strokeOpacity={0.4}/>
                                <XAxis dataKey="month" unit=" mnd" tick={{ fill: 'var(--color-text-secondary)' }}/>
                                <YAxis tickFormatter={val => formatCurrency(val, 0)} tick={{ fill: 'var(--color-text-secondary)' }}/>
                                <Tooltip formatter={(value: number) => [formatCurrency(value), 'Waarde']} labelFormatter={label => `Maand ${label}`}/>
                                <Area type="monotone" dataKey="value" stroke="none" fill="url(#roiGradient)" />
                                <Line type="monotone" dataKey="value" stroke="var(--color-primary-main)" strokeWidth={2} dot={false}/>
                                <ReferenceLine y={netInvestment} label={{ value: 'Investering', position: 'insideTopLeft', fill: 'var(--color-text-primary)' }} stroke="var(--color-error-main)" strokeDasharray="4 4" />
                                <ReferenceLine y={0} stroke={'var(--color-text-primary)'} strokeWidth={1} />
                            </ComposedChart>
                        </ResponsiveContainer>
                    </div></CardContent></Card></div>
                </div>
            </div>
        </div>
    );
};

export default ROICalculator;
