import React from 'react';

interface TooltipProps {
  children: React.ReactNode;
  content: React.ReactNode;
  disabled?: boolean;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

export const Tooltip: React.FC<TooltipProps> = ({ children, content, disabled = false, position = 'right' }) => {
  if (disabled) {
    return <>{children}</>;
  }

  const positionClasses = {
    right: 'left-full top-1/2 -translate-y-1/2 ml-4',
    left: 'right-full top-1/2 -translate-y-1/2 mr-4',
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
  };

  // Removed font-semibold to allow content to define its own font weight.
  const baseClasses = "absolute w-auto min-w-max max-w-xs bg-gray-800 dark:bg-black text-white dark:text-gray-200 text-xs rounded-md p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-50 shadow-lg";

  return (
    <span className="group relative">
      {children}
      <span className={`${baseClasses} ${positionClasses[position]}`}>
        {content}
      </span>
    </span>
  );
};
