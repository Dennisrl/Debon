import React from 'react';
import type { SimulationResult } from '../types';
import { Card, CardContent, CardHeader } from './Card';
import { TableIcon } from './icons';

interface ResultsSummaryProps {
  result: SimulationResult | null;
}

const formatCurrency = (value: number) => {
    if (value === 0 || !value) return 'N/A';
    return new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
};

const ResultsSummary: React.FC<ResultsSummaryProps> = ({ result }) => {
  if (!result || result.finalTime.baseline === 0) {
    return null; // Don't show card if there's no result
  }

  const deviations = result.usedDeviations;

  const showHistoricalInsights = result.historicalDataPoints > 0 &&
                                 result.historicalVelocity != null &&
                                 result.remainingSprints != null;

  return (
    <Card>
      <CardHeader icon={<TableIcon className="w-6 h-6" />}>Resultaten Samenvatting</CardHeader>
      <CardContent className="space-y-6">
        <div>
            <h4 className="text-md font-semibold text-text-secondary mb-2">Verwachte Doorlooptijd</h4>
            <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                    <p className="text-xs text-warning font-bold">OPTIMISTISCH (+{deviations.optimistic}%)</p>
                    <p className="text-2xl font-bold text-text-primary">{result.finalTime.optimistic.toFixed(0)}</p>
                    <p className="text-xs text-text-secondary">sprints</p>
                </div>
                 <div>
                    <p className="text-xs text-primary font-bold">BASELINE (GEMIDDELDE)</p>
                    <p className="text-2xl font-bold text-text-primary">{result.finalTime.baseline.toFixed(0)}</p>
                    <p className="text-xs text-text-secondary">sprints</p>
                </div>
                 <div>
                    <p className="text-xs text-error font-bold">PESSIMISTISCH (-{deviations.pessimistic}%)</p>
                    <p className="text-2xl font-bold text-text-primary">{result.finalTime.pessimistic.toFixed(0)}</p>
                    <p className="text-xs text-text-secondary">sprints</p>
                </div>
            </div>
        </div>

        <div className="border-t border-border-default pt-6">
             <h4 className="text-md font-semibold text-text-secondary mb-2">Verwachte Totale Kosten</h4>
            <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                    <p className="text-xs text-warning font-bold">OPTIMISTISCH</p>
                    <p className="text-2xl font-bold text-text-primary">{formatCurrency(result.finalCost.optimistic)}</p>
                </div>
                 <div>
                    <p className="text-xs text-primary font-bold">BASELINE</p>
                    <p className="text-2xl font-bold text-text-primary">{formatCurrency(result.finalCost.baseline)}</p>
                </div>
                 <div>
                    <p className="text-xs text-error font-bold">PESSIMISTISCH</p>
                    <p className="text-2xl font-bold text-text-primary">{formatCurrency(result.finalCost.pessimistic)}</p>
                </div>
            </div>
        </div>

        {showHistoricalInsights && (
             <div className="border-t border-border-default pt-6">
                 <h4 className="text-md font-semibold text-text-secondary mb-2">Inzichten op basis van resultaten</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                        <p className="text-xs text-primary font-bold">BEHAALDE VELOCITY</p>
                        <p className="text-2xl font-bold text-text-primary">{result.historicalVelocity!.toFixed(1)}</p>
                        <p className="text-xs text-text-secondary">punten/sprint</p>
                    </div>
                     <div>
                        <p className="text-xs text-primary font-bold">GEM. UREN PER PUNT</p>
                        <p className="text-2xl font-bold text-text-primary">{result.historicalAvgHoursPerPoint?.toFixed(1) || '0'}</p>
                        <p className="text-xs text-text-secondary">gemiddeld</p>
                    </div>
                     <div>
                        <p className="text-xs text-primary font-bold">RESTERENDE SPRINTS</p>
                        <p className="text-2xl font-bold text-text-primary">{Math.ceil(result.remainingSprints!).toFixed(0)}</p>
                        <p className="text-xs text-text-secondary">prognose</p>
                    </div>
                </div>
            </div>
        )}

      </CardContent>
    </Card>
  );
};

export default ResultsSummary;