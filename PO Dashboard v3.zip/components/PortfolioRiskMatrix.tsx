import React from 'react';
import { ResponsiveContainer, ScatterChart, XAxis, YAxis, CartesianGrid, Tooltip, Scatter, ReferenceLine, Label, Cell } from 'recharts';
import { Card, CardContent, CardHeader } from './Card';
import { AlertTriangleIcon } from './icons';
import type { AggregatedProjectData } from './ProjectPortfolioDashboard';

interface PortfolioRiskMatrixProps {
    aggregatedData: AggregatedProjectData[];
}

const CustomTooltip: React.FC<any> = ({ active, payload }) => {
    if (active && payload && payload.length) {
        const data = payload[0].payload;
        return (
            <div className="bg-surface/90 backdrop-blur-sm p-3 rounded-lg border border-border-default shadow-lg text-sm">
                <p className="font-bold text-text-primary mb-1">{data.name}</p>
                <p>Risico Vertraging: <span className="font-semibold">{data.timeRisk.toFixed(0)}%</span></p>
                <p>Risico Budget: <span className="font-semibold">{data.budgetRisk.toFixed(0)}%</span></p>
            </div>
        );
    }
    return null;
};

const PortfolioRiskMatrix: React.FC<PortfolioRiskMatrixProps> = ({ aggregatedData }) => {
    const chartData = aggregatedData.map(({ project, simulationResult }) => {
        if (!simulationResult) return null;
        
        const budget = parseFloat(project.totalBudget) || 0;
        const expectedCost = simulationResult.finalCost.baseline;
        
        const timeRisk = simulationResult.finalTime.baseline > 0 
            ? ((simulationResult.finalTime.pessimistic - simulationResult.finalTime.baseline) / simulationResult.finalTime.baseline) * 100
            : 0;

        const budgetRisk = budget > 0 
            ? ((expectedCost - budget) / budget) * 100
            : 0;
            
        return {
            name: project.name,
            budgetRisk: Math.max(0, budgetRisk), // Don't show negative risk
            timeRisk: Math.max(0, timeRisk),
            color: project.color,
        };
    }).filter((d): d is NonNullable<typeof d> => d !== null);

    const tickFormatter = (value: number) => `${value}%`;

    return (
        <Card>
            <CardHeader icon={<AlertTriangleIcon className="w-6 h-6" />}>Portfolio Risicomatrix</CardHeader>
            <CardContent>
                <div className="h-96 w-full">
                    <ResponsiveContainer>
                        <ScatterChart margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                            <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" strokeOpacity={0.4} />
                            <XAxis
                                type="number"
                                dataKey="budgetRisk"
                                name="Budgetrisico"
                                unit="%"
                                tickFormatter={tickFormatter}
                                domain={[0, 'dataMax + 10']}
                                tick={{ fill: 'var(--color-text-secondary)' }}
                            >
                                <Label value="Risico op Budgetoverschrijding" offset={-15} position="insideBottom" fill="var(--color-text-primary)" />
                            </XAxis>
                            <YAxis
                                type="number"
                                dataKey="timeRisk"
                                name="Tijdrisico"
                                unit="%"
                                tickFormatter={tickFormatter}
                                domain={[0, 'dataMax + 10']}
                                tick={{ fill: 'var(--color-text-secondary)' }}
                            >
                                <Label value="Risico op Vertraging" angle={-90} offset={0} position="insideLeft" fill="var(--color-text-primary)" style={{ textAnchor: 'middle' }} />
                            </YAxis>
                            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
                            <ReferenceLine x={20} stroke="var(--color-warning-main)" strokeDasharray="4 4">
                                <Label value="Verhoogd Risico" position="top" fill="var(--color-warning-main)" fontSize={12} />
                            </ReferenceLine>
                            <ReferenceLine y={20} stroke="var(--color-warning-main)" strokeDasharray="4 4" />
                            <Scatter name="Projecten" data={chartData} fill="var(--color-primary-main)">
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Scatter>
                        </ScatterChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
};

export default PortfolioRiskMatrix;