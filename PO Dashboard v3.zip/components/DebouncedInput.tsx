import React, { useState, useEffect, useRef } from 'react';

const DebouncedInput: React.FC<{
    value: string;
    onChange: (newValue: string) => void;
    debounceTimeout?: number;
    className?: string;
    placeholder?: string;
    type?: string;
    disabled?: boolean;
    onBlur?: () => void;
}> = ({ value, onChange, debounceTimeout = 750, className, placeholder, type="number", disabled, onBlur }) => {
    const [internalValue, setInternalValue] = useState(value);
    const debounceRef = useRef<number | null>(null);

    useEffect(() => {
        setInternalValue(value);
    }, [value]);
    
    const triggerChange = (val: string) => {
        if (debounceRef.current) {
            clearTimeout(debounceRef.current);
            debounceRef.current = null;
        }
        if (val !== value) {
            onChange(val);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value;
        setInternalValue(newValue);
        if (debounceRef.current) clearTimeout(debounceRef.current);
        debounceRef.current = window.setTimeout(() => {
            if (newValue !== value) {
                onChange(newValue);
            }
        }, debounceTimeout);
    };

    const handleBlur = () => {
        triggerChange(internalValue);
        if (onBlur) {
            onBlur();
        }
    };

    return <input type={type} value={internalValue} onChange={handleChange} onBlur={handleBlur} disabled={disabled} className={className} placeholder={placeholder} min="0"/>;
};

export default DebouncedInput;