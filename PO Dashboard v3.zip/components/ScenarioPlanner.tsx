import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { runScenarioProjection } from '../services/riskService';
import { parseScenarioQuery } from '../services/analysisService';
import { Card, CardContent, CardHeader } from './Card';
import { BrainIcon, LoaderIcon, AlertTriangleIcon } from './icons';
import type { Project, SimulationParams, SimulationResult } from '../types';

const formatCurrency = (value: number) => new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
const formatSprints = (value: number) => `${value.toFixed(1)} sprints`;

const ResultCard: React.FC<{ title: string; result: SimulationResult | null; project: Project | null }> = ({ title, result, project }) => {
    if (!result || !project) return (
        <div className="bg-background rounded-lg p-4 text-center text-text-secondary">
            <p>{title}</p>
            <p className="mt-2 text-sm italic">Voer een scenario in om de data te zien.</p>
        </div>
    );

    const isOverBudget = result.finalCost.baseline > parseFloat(project.totalBudget);

    return (
        <div className="bg-background rounded-lg p-4">
            <h4 className="font-bold text-lg text-primary text-center mb-3">{title}</h4>
            <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                    <span className="text-text-secondary">Verwachte doorlooptijd:</span>
                    <span className="font-semibold">{formatSprints(result.finalTime.baseline)}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-text-secondary">Verwachte kosten:</span>
                    <span className={`font-semibold ${isOverBudget ? 'text-error' : ''}`}>{formatCurrency(result.finalCost.baseline)}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-border-default">
                    <span className="text-text-secondary">Pessimistisch:</span>
                    <div className="text-right">
                        <span className="font-semibold">{formatSprints(result.finalTime.pessimistic)}</span> / <span className="font-semibold">{formatCurrency(result.finalCost.pessimistic)}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};


const ScenarioPlanner: React.FC = () => {
    const { state } = useData();
    const { projects } = state;
    const [query, setQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [baselineResult, setBaselineResult] = useState<SimulationResult | null>(null);
    const [scenarioResult, setScenarioResult] = useState<SimulationResult | null>(null);
    const [activeProject, setActiveProject] = useState<Project | null>(null);
    const [scenarioDescription, setScenarioDescription] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!query) return;

        setIsLoading(true);
        setError(null);
        setBaselineResult(null);
        setScenarioResult(null);
        setActiveProject(null);
        setScenarioDescription(null);

        try {
            // 1. Parse the natural language query
            const parsed = await parseScenarioQuery(query, projects);
            const { project_name, velocity_change_points, duration_sprints } = parsed;
            
            setScenarioDescription(`Scenario: ${velocity_change_points > 0 ? '+' : ''}${velocity_change_points} punten/sprint voor ${duration_sprints} sprints.`);
            
            // 2. Find the project
            const project = projects.find(p => p.name === project_name);
            if (!project) {
                throw new Error(`Project "${project_name}" niet gevonden.`);
            }
            setActiveProject(project);

            // 3. Run baseline simulation
            const baseParams: SimulationParams = {
                totalPoints: parseFloat(project.totalPoints) || 0,
                pointsPerSprint: project.sprints.map(s => parseFloat(s.actualPoints) || 0),
                hoursPerSprint: project.sprints.map(s => parseFloat(s.actualHours) || 0),
                plannedVelocity: parseFloat(project.velocityPerSprint) || 0,
                avgHoursPerPoint: parseFloat(project.avgHoursPerPoint) || 0,
                totalBudget: parseFloat(project.totalBudget) || 0,
                hourlyRate: parseFloat(project.hourlyRate) || 0,
                optimisticDeviation: parseFloat(project.rangePercentage) || 20,
                pessimisticDeviation: parseFloat(project.rangePercentage) || 20,
            };
            const baseline = await runScenarioProjection(baseParams);
            setBaselineResult(baseline);

            // 4. Calculate modified parameters for the scenario
            const baselineRemainingSprints = baseline.remainingSprints || 0;
            if (baselineRemainingSprints <= 0) {
                 setScenarioResult(baseline); // No future sprints, scenario has no effect
                 setIsLoading(false);
                 return;
            }

            const baselineVelocity = baseline.historicalVelocity || baseParams.plannedVelocity;
            
            // Create a blended velocity for the entire future of the project
            const newVelocityForDuration = baselineVelocity + velocity_change_points;
            
            let newBlendedVelocity: number;
            if (duration_sprints >= baselineRemainingSprints) {
                newBlendedVelocity = newVelocityForDuration;
            } else {
                const totalFuturePoints = baselineRemainingSprints * baselineVelocity;
                const pointsInScenarioDuration = duration_sprints * newVelocityForDuration;
                const pointsAfterScenario = (baselineRemainingSprints - duration_sprints) * baselineVelocity;
                newBlendedVelocity = (pointsInScenarioDuration + pointsAfterScenario) / baselineRemainingSprints;
            }

            const scenarioParams = { ...baseParams, plannedVelocity: newBlendedVelocity };

            // 5. Run scenario simulation
            const scenario = await runScenarioProjection(scenarioParams);
            setScenarioResult(scenario);

        } catch (err) {
            setError(err instanceof Error ? err.message : 'Een onbekende fout is opgetreden.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader icon={<BrainIcon className="w-6 h-6" />}>
                    AI Scenario Planner
                </CardHeader>
                <CardContent>
                    <p className="text-sm text-text-secondary mb-4">
                        Stel een vraag in natuurlijke taal om de impact van een verandering op een project te zien.
                        Bijvoorbeeld: <em className="italic">"Wat gebeurt er met project WGM als we de komende 3 sprints 10 uur extra per sprint plannen?"</em>
                    </p>
                    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
                        <input
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Stel uw 'wat als' vraag..."
                            className="w-full px-4 py-2.5 text-base text-text-primary bg-background border border-border-default rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition disabled:bg-background/50"
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading || !query} className="px-6 py-2.5 text-base font-semibold text-neutral-white bg-primary rounded-lg hover:bg-primary-hover transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                            {isLoading ? <LoaderIcon className="w-5 h-5"/> : <BrainIcon className="w-5 h-5"/>}
                            Analyseer
                        </button>
                    </form>
                </CardContent>
            </Card>

            {isLoading && (
                 <div className="flex items-center justify-center p-12 text-text-secondary">
                    <LoaderIcon className="w-6 h-6 mr-2" />
                    <span>Scenario wordt berekend...</span>
                </div>
            )}
            
            {error && (
                <div className="bg-error/10 border border-error/30 text-error px-4 py-3 rounded-lg flex items-start gap-3">
                    <AlertTriangleIcon className="w-5 h-5 mt-0.5 text-error"/>
                    <div>
                        <h4 className="font-bold">Fout bij Analyse</h4>
                        <p className="text-sm">{error}</p>
                    </div>
                </div>
            )}

            {!isLoading && (baselineResult || scenarioResult) && (
                <Card>
                    <CardHeader>
                        <div className="flex justify-between items-center w-full">
                            <span>Resultaten: {activeProject?.name}</span>
                            {scenarioDescription && <span className="text-sm font-normal text-text-secondary">{scenarioDescription}</span>}
                        </div>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <ResultCard title="Baseline" result={baselineResult} project={activeProject} />
                        <ResultCard title="Scenario" result={scenarioResult} project={activeProject} />
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default ScenarioPlanner;
