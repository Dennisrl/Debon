import React, { useMemo, useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { runScenarioProjection } from '../services/riskService';
import type { Project, SimulationResult } from '../types';
import { Card, CardContent, CardHeader } from './Card';
import PortfolioRiskMatrix from './PortfolioRiskMatrix';
import { BriefcaseIcon, LoaderIcon } from './icons';
import InsightCard from './InsightCard';
import { generatePortfolioAnalysis } from '../services/analysisService';

export type AggregatedProjectData = {
    project: Project;
    simulationResult: SimulationResult | null;
    totalActualHours: number;
    billablePercentage: number;
    completedPoints: number;
    cpi: number | null;
    spi: number | null;
    budgetRisk: number;
    timeRisk: number;
};

const formatCurrency = (value: number | undefined | null) => {
    if (value == null || isNaN(value)) return 'N/A';
    return new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
};

const KPIValue: React.FC<{value: number | null, isGood?: (v: number) => boolean}> = ({ value, isGood }) => {
    if (value === null) return <span className="text-text-secondary">N/A</span>;
    const isOk = isGood ? isGood(value) : true;
    return (
        <span className={`font-mono ${!isOk ? 'text-error' : 'text-success'}`}>{value.toFixed(2)}</span>
    );
};


const ProjectPortfolioDashboard: React.FC = () => {
    const { state } = useData();
    const { projects, actualHours } = state;
    const [aggregatedData, setAggregatedData] = useState<AggregatedProjectData[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const activeProjects = useMemo(() => projects.filter(p => !p.isHidden), [projects]);

    useEffect(() => {
        const analyzeProjects = async () => {
            setIsLoading(true);
            const data: AggregatedProjectData[] = [];

            for (const project of activeProjects) {
                const pointsPerSprint = project.sprints.map(s => parseFloat(s.actualPoints) || 0);
                const hoursPerSprint = project.sprints.map(s => parseFloat(s.actualHours) || 0);
                
                const simulationParams = {
                    totalPoints: parseFloat(project.totalPoints) || 0, pointsPerSprint, hoursPerSprint,
                    plannedVelocity: parseFloat(project.velocityPerSprint) || 0,
                    avgHoursPerPoint: parseFloat(project.avgHoursPerPoint) || 0,
                    totalBudget: parseFloat(project.totalBudget) || 0,
                    hourlyRate: parseFloat(project.hourlyRate) || 0,
                    optimisticDeviation: parseFloat(project.rangePercentage) || 20,
                    pessimisticDeviation: parseFloat(project.rangePercentage) || 20,
                };
                const simulationResult = await runScenarioProjection(simulationParams);

                const projectActuals = actualHours.filter(ah => ah.projectId === project.id);
                const totalActualHours = projectActuals.reduce((sum, ah) => sum + ah.hours, 0);
                const totalBillableHours = projectActuals.filter(ah => ah.billable).reduce((sum, ah) => sum + ah.hours, 0);
                const billablePercentage = totalActualHours > 0 ? (totalBillableHours / totalActualHours) * 100 : 0;
                const completedPoints = pointsPerSprint.reduce((sum, p) => sum + p, 0);
                
                const totalBudget = parseFloat(project.totalBudget) || 0;
                const totalPoints = parseFloat(project.totalPoints) || 0;
                const hourlyRate = parseFloat(project.hourlyRate) || 0;

                const actualCost = totalActualHours * hourlyRate;
                const earnedValue = totalPoints > 0 ? (completedPoints / totalPoints) * totalBudget : 0;
                const cpi = actualCost > 0 ? earnedValue / actualCost : null;
                
                const expectedSprints = simulationResult?.finalTime.baseline ?? 0;
                const sprintsPassed = project.sprints.length;
                const plannedValue = expectedSprints > 0 ? (sprintsPassed / expectedSprints) * totalBudget : 0;
                const spi = plannedValue > 0 ? earnedValue / plannedValue : null;

                const budgetRisk = totalBudget > 0 && simulationResult ? ((simulationResult.finalCost.baseline - totalBudget) / totalBudget) * 100 : 0;
                const timeRisk = simulationResult?.finalTime.baseline > 0 ? ((simulationResult.finalTime.pessimistic - simulationResult.finalTime.baseline) / simulationResult.finalTime.baseline) * 100 : 0;

                data.push({
                    project, simulationResult, totalActualHours, billablePercentage,
                    completedPoints, cpi, spi, budgetRisk: Math.max(0, budgetRisk), timeRisk: Math.max(0, timeRisk)
                });
            }
            setAggregatedData(data.sort((a,b) => (parseFloat(b.project.totalBudget) || 0) - (parseFloat(a.project.totalBudget) || 0) ));
            setIsLoading(false);
        };

        if (activeProjects.length > 0) analyzeProjects();
        else setIsLoading(false);
    }, [activeProjects, actualHours]);

    if (isLoading) {
        return (
            <div className="flex items-center justify-center p-12 text-text-secondary">
                <LoaderIcon className="w-6 h-6 mr-2" />
                <span>Dashboard data wordt berekend...</span>
            </div>
        );
    }
    
    const explanation = (
        <div>
          <p>Dit dashboard biedt een overzicht van alle actieve projecten en hun belangrijkste prestatie-indicatoren (KPI's), waardoor u snel de gezondheid van de gehele portfolio kunt beoordelen.</p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li><strong>Voortgang:</strong> Visuele weergave van voltooide scope en verbruikt budget.</li>
            <li><strong>CPI (Cost Performance Index):</strong> Meet kostenefficiëntie. Een waarde {'>'} 1 is gunstig (onder budget), {'<'} 1 is ongunstig.</li>
            <li><strong>SPI (Schedule Performance Index):</strong> Meet de efficiëntie van de planning. Een waarde {'>'} 1 betekent voor op schema, {'<'} 1 is achter op schema.</li>
            <li><strong>Verw. Kosten (EAC):</strong> De geschatte totale kosten bij voltooiing (Estimate At Completion), gebaseerd op de huidige prestaties.</li>
            <li><strong>Facturabiliteit:</strong> Het percentage van de totale uren dat facturabel is.</li>
          </ul>
        </div>
    );

    return (
        <div className="space-y-6">
            <InsightCard 
                title="Portfolio Analyse"
                explanation={explanation}
                onGenerateAnalysis={() => generatePortfolioAnalysis(aggregatedData)}
            />
            <Card>
                <CardHeader icon={<BriefcaseIcon className="w-6 h-6" />}>Portfolio Overzicht</CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="text-left text-xs text-text-secondary uppercase">
                                <tr>
                                    <th className="p-2">Project</th>
                                    <th className="p-2 w-32">Voortgang Scope</th>
                                    <th className="p-2 w-32">Budgetverbruik</th>
                                    <th className="p-2 text-center">CPI</th>
                                    <th className="p-2 text-center">SPI</th>
                                    <th className="p-2 text-right">Verw. Kosten</th>
                                    <th className="p-2 text-right">Facturabiliteit</th>
                                </tr>
                            </thead>
                            <tbody>
                                {aggregatedData.map(({ project, simulationResult, totalActualHours, billablePercentage, completedPoints, cpi, spi }) => {
                                    const totalBudget = parseFloat(project.totalBudget) || 0;
                                    const totalPoints = parseFloat(project.totalPoints) || 0;
                                    const hourlyRate = parseFloat(project.hourlyRate) || 0;

                                    const budgetUsage = totalBudget > 0 ? (totalActualHours * hourlyRate / totalBudget) * 100 : 0;
                                    const scopeProgress = totalPoints > 0 ? (completedPoints / totalPoints) * 100 : 0;
                                    
                                    const expectedCost = simulationResult?.finalCost.baseline ?? 0;
                                    const isOverBudget = totalBudget > 0 && expectedCost > totalBudget;

                                    return (
                                        <tr key={project.id} className="border-t border-border-default">
                                            <td className="p-3 font-semibold">{project.name}</td>
                                            <td className="p-3">
                                                <div className="w-full bg-border-default rounded-full h-2.5" title={`${scopeProgress.toFixed(0)}%`}>
                                                    <div className="bg-success h-2.5 rounded-full" style={{ width: `${Math.min(scopeProgress, 100)}%` }}></div>
                                                </div>
                                            </td>
                                            <td className="p-3">
                                                <div className="w-full bg-border-default rounded-full h-2.5" title={`${budgetUsage.toFixed(0)}%`}>
                                                    <div className={`h-2.5 rounded-full ${budgetUsage > 100 ? 'bg-error' : 'bg-primary'}`} style={{ width: `${Math.min(budgetUsage, 100)}%` }}></div>
                                                </div>
                                            </td>
                                            <td className="p-3 text-center"><KPIValue value={cpi} isGood={(v) => v >= 1.0} /></td>
                                            <td className="p-3 text-center"><KPIValue value={spi} isGood={(v) => v >= 1.0} /></td>
                                            <td className={`p-3 text-right font-mono ${isOverBudget ? 'text-error' : ''}`}>{formatCurrency(expectedCost)}</td>
                                            <td className="p-3 text-right font-mono">{billablePercentage.toFixed(0)}%</td>
                                        </tr>
                                    );
                                })}
                                 {aggregatedData.length === 0 && (
                                    <tr>
                                        <td colSpan={7} className="text-center p-8 text-text-secondary">Geen actieve projecten om weer te geven.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <PortfolioRiskMatrix aggregatedData={aggregatedData} />
        </div>
    );
};

export default ProjectPortfolioDashboard;