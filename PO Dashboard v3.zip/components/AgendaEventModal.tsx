import React, { useState, useEffect, useMemo } from 'react';
import type { Person, GlobalEvent, CalendarEvent, RecurrenceRule, GlobalEventType, CalendarEventType } from '../types';
import { useData } from '../context/DataContext';
import { TrashIcon, XIcon } from './icons';

type EditableEvent = { type: 'personal', event: CalendarEvent, personId: string } | { type: 'global', event: GlobalEvent };

interface AgendaEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventToEdit: EditableEvent | null;
}

const personalEventTypeOptions: { value: CalendarEventType; label: string }[] = [
    { value: 'vacation', label: 'Vakantie' }, { value: 'sick', label: 'Ziekte' },
    { value: 'extra', label: 'Extra Werk' }, { value: 'other', label: 'Overig' },
];
const globalEventTypeOptions: { value: GlobalEventType; label: string }[] = [
    { value: 'holiday', label: 'Feestdag' }, { value: 'company-day', label: 'Bedrijfsuitje / Teamdag' },
    { value: 'learning-day', label: 'Leermiddag' }, { value: 'other', label: 'Overig' },
];
const durationTypeOptions: { value: CalendarEvent['durationType'], label: string }[] = [
    { value: 'fullday', label: 'Hele dag' }, { value: 'multiday', label: 'Meerdere dagen' }, { value: 'hours', label: 'Een paar uur' },
];

const AgendaEventModal: React.FC<AgendaEventModalProps> = ({ isOpen, onClose, eventToEdit }) => {
    const { state, dispatch } = useData();
    const { persons, globalEvents } = state;
    
    // Form state
    const [isPersonal, setIsPersonal] = useState(true);
    const [title, setTitle] = useState('');
    const [personId, setPersonId] = useState('');
    const [type, setType] = useState<CalendarEventType | GlobalEventType>('vacation');
    const [durationType, setDurationType] = useState<CalendarEvent['durationType']>('fullday');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [hours, setHours] = useState('');
    const [isRecurring, setIsRecurring] = useState(false);
    const [recurrenceRule, setRecurrenceRule] = useState<Partial<RecurrenceRule>>({ frequency: 'weekly', interval: 1 });
    const [error, setError] = useState('');

    const isEditing = useMemo(() => eventToEdit !== null, [eventToEdit]);
    const modalTitleId = 'agenda-event-modal-title';

    useEffect(() => {
        if (!isOpen) return;
        setError('');
        const today = new Date().toISOString().split('T')[0];

        if (eventToEdit) {
            const isPersonalEvent = eventToEdit.type === 'personal';
            const event = eventToEdit.event;
            setIsPersonal(isPersonalEvent);
            setTitle(event.title);
            setType(event.type);
            setDurationType(event.durationType);
            setStartDate(event.startDate);
            setEndDate(event.endDate || event.startDate);
            setHours(event.hours || '');
            setIsRecurring(!!event.recurrenceRule);
            setRecurrenceRule(event.recurrenceRule || { frequency: 'weekly', interval: 1 });
            if (isPersonalEvent) {
                setPersonId(eventToEdit.personId);
            }
        } else {
            // Reset for new event
            setIsPersonal(true);
            setTitle('');
            setPersonId(persons[0]?.id || '');
            setType('vacation');
            setDurationType('fullday');
            setStartDate(today);
            setEndDate(today);
            setHours('');
            setIsRecurring(false);
            setRecurrenceRule({ frequency: 'weekly', interval: 1 });
        }
    }, [isOpen, eventToEdit, persons]);
    
    // Reset type when switching between personal/global
    useEffect(() => {
        if (isPersonal) setType('vacation');
        else setType('holiday');
    }, [isPersonal]);

    const handleSave = () => {
        if (!title || !startDate || (isPersonal && !personId)) { return setError('Type, teamlid (indien persoonlijk), titel en startdatum zijn verplicht.'); }
        let finalEndDate = startDate;
        if (durationType === 'multiday') {
            if (!endDate || new Date(endDate) < new Date(startDate)) { return setError('Geldige einddatum is verplicht.'); }
            finalEndDate = endDate;
        }
        
        const finalRecurrenceRule = isRecurring 
            ? {
                frequency: recurrenceRule.frequency || 'weekly',
                interval: Number(recurrenceRule.interval) || 1,
                until: recurrenceRule.until || undefined,
              }
            : undefined;
        
        if(finalRecurrenceRule?.interval && finalRecurrenceRule.interval < 1) {
            return setError('Herhalingsinterval moet 1 of groter zijn.');
        }

        const sharedProps = {
            title, durationType, startDate, endDate: finalEndDate,
            hours: durationType === 'hours' ? hours : undefined,
            recurrenceRule: finalRecurrenceRule,
        };

        if (isPersonal) {
            const eventToSave: CalendarEvent = {
                id: (isEditing && eventToEdit?.type === 'personal') ? eventToEdit.event.id : crypto.randomUUID(),
                type: type as CalendarEventType,
                ...sharedProps,
            };
            const person = persons.find(p => p.id === personId);
            if (!person) return;
            const otherEvents = (person.events || []).filter(e => e.id !== eventToSave.id);
            dispatch({ type: 'UPDATE_PERSON', payload: { ...person, events: [...otherEvents, eventToSave] }});
        } else { // Global
            const eventToSave: GlobalEvent = {
                id: (isEditing && eventToEdit?.type === 'global') ? eventToEdit.event.id : crypto.randomUUID(),
                type: type as GlobalEventType,
                ...sharedProps
            };
            const otherEvents = globalEvents.filter(e => e.id !== eventToSave.id);
            dispatch({ type: 'SET_GLOBAL_EVENTS', payload: [...otherEvents, eventToSave] });
        }
        onClose();
    };
    
    const handleDelete = () => {
        if (!eventToEdit) return;
        // The confirmation dialog is removed due to sandbox restrictions.
        if (eventToEdit.type === 'global') {
            dispatch({ type: 'DELETE_GLOBAL_EVENT', payload: eventToEdit.event.id });
        } else {
            dispatch({ type: 'DELETE_PERSONAL_EVENT', payload: { personId: eventToEdit.personId, eventId: eventToEdit.event.id } });
        }
        onClose();
    };

    if (!isOpen) return null;
    
    const inputClasses = "w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default";
    const labelClasses = "text-xs font-medium text-text-secondary block mb-1";
    const eventTypeOptions = isPersonal ? personalEventTypeOptions : globalEventTypeOptions;

    const getIntervalUnit = () => {
        switch(recurrenceRule.frequency) {
            case 'daily': return 'dag(en)';
            case 'weekly': return 'we(e)k(en)';
            case 'monthly': return 'maand(en)';
            case 'yearly': return 'jaar/jaren';
            default: return '';
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div role="dialog" aria-modal="true" aria-labelledby={modalTitleId} className="bg-surface rounded-xl shadow-2xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b border-border-default flex justify-between items-center">
                    <h3 id={modalTitleId} className="text-xl font-bold text-text-primary">{isEditing ? 'Evenement Bewerken' : 'Nieuw Evenement'}</h3>
                    <button onClick={onClose} aria-label="Sluiten" className="p-1 text-text-secondary hover:text-text-primary"><XIcon className="w-5 h-5"/></button>
                </header>
                <div className="p-6 space-y-4">
                    {error && <p className="text-error text-sm bg-error/10 p-3 rounded-md">{error}</p>}
                     <div className="flex items-center gap-1 bg-background p-1 rounded-lg">
                        <button onClick={() => setIsPersonal(true)} disabled={isEditing} className={`flex-1 px-3 py-1 text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed disabled:opacity-70 ${isPersonal ? 'bg-surface dark:bg-black/20 text-primary shadow-sm' : 'text-text-secondary hover:bg-black/5 dark:hover:bg-white/5'}`}>Persoonlijk</button>
                        <button onClick={() => setIsPersonal(false)} disabled={isEditing} className={`flex-1 px-3 py-1 text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed disabled:opacity-70 ${!isPersonal ? 'bg-surface dark:bg-black/20 text-primary shadow-sm' : 'text-text-secondary hover:bg-black/5 dark:hover:bg-white/5'}`}>Globaal</button>
                     </div>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {isPersonal ? (
                        <div>
                            <label htmlFor="person" className={labelClasses}>Teamlid</label>
                            <select id="person" value={personId} onChange={e => setPersonId(e.target.value)} className={inputClasses} disabled={persons.length === 0}>
                                {persons.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                            </select>
                        </div>
                        ) : <div className="hidden sm:block"></div>}
                        <div>
                            <label htmlFor="type" className={labelClasses}>Type</label>
                            <select id="type" value={type} onChange={e => setType(e.target.value as any)} className={inputClasses}>
                                {eventTypeOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                            </select>
                        </div>
                    </div>
                    <div><label htmlFor="title" className={labelClasses}>Omschrijving</label><input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className={inputClasses} placeholder="bv. Zomervakantie"/></div>
                    <div>
                        <label className={labelClasses}>Duur</label>
                        <div className="flex items-center gap-1 bg-background p-1 rounded-lg">
                           {durationTypeOptions.map(opt => (<button key={opt.value} onClick={() => setDurationType(opt.value)} className={`flex-1 px-3 py-1 text-sm font-medium rounded-md transition-colors ${durationType === opt.value ? 'bg-surface dark:bg-black/20 text-primary shadow-sm' : 'text-text-secondary hover:bg-black/5 dark:hover:bg-white/5'}`}>{opt.label}</button>))}
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {durationType !== 'multiday' && <div><label htmlFor="date" className={labelClasses}>Datum</label><input type="date" id="date" value={startDate} onChange={e => { setStartDate(e.target.value); setEndDate(e.target.value); }} className={inputClasses}/></div>}
                        {durationType === 'multiday' && (<><div><label htmlFor="startDate" className={labelClasses}>Startdatum</label><input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className={inputClasses}/></div><div><label htmlFor="endDate" className={labelClasses}>Einddatum</label><input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className={inputClasses}/></div></>)}
                        {durationType === 'hours' && <div><label htmlFor="hours" className={labelClasses}>Aantal uren</label><input type="number" id="hours" value={hours} onChange={e => setHours(e.target.value)} className={inputClasses} placeholder="bv. 4"/></div>}
                    </div>
                    <div className="border-t border-border-default pt-4"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={isRecurring} onChange={e => setIsRecurring(e.target.checked)} className="h-4 w-4 rounded border-border-default text-primary focus:ring-primary"/><span className={`${labelClasses} mb-0`}>Dit evenement herhalen</span></label></div>
                    {isRecurring && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                             <div className="col-span-2 sm:col-span-1">
                                <label className={labelClasses}>Herhaal elke</label>
                                <div className="flex gap-2">
                                    <input type="number" value={recurrenceRule?.interval || 1} onChange={e => setRecurrenceRule(prev => ({ ...prev, interval: parseInt(e.target.value, 10) || 1 }))} className={`${inputClasses} w-20 text-center`} min="1"/>
                                    <select value={recurrenceRule?.frequency || 'weekly'} onChange={e => setRecurrenceRule(prev => ({ ...prev, frequency: e.target.value as RecurrenceRule['frequency'] }))} className={inputClasses}>
                                        <option value="daily">Dag(en)</option>
                                        <option value="weekly">Weken</option>
                                        <option value="monthly">Maanden</option>
                                        <option value="yearly">Jaren</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="recurrenceUntil" className={labelClasses}>Herhalen tot (optioneel)</label>
                                <input type="date" id="recurrenceUntil" value={recurrenceRule?.until || ''} onChange={e => setRecurrenceRule(prev => ({ ...prev, until: e.target.value }))} className={inputClasses}/>
                            </div>
                        </div>
                    )}
                </div>
                <footer className="p-4 bg-surface/50 border-t border-border-default flex justify-between items-center">
                    <div>{isEditing && <button onClick={handleDelete} className="px-4 py-2 text-sm font-semibold text-white bg-error hover:bg-error-hover rounded-lg flex items-center gap-2"><TrashIcon className="w-4 h-4"/> Verwijderen</button>}</div>
                    <div className="flex gap-2"><button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-text-primary bg-surface border border-border-default rounded-lg hover:bg-background">Annuleren</button><button onClick={handleSave} className="px-4 py-2 text-sm font-semibold text-white bg-primary hover:bg-primary-hover rounded-lg">Opslaan</button></div>
                </footer>
            </div>
        </div>
    );
};

export default AgendaEventModal;