import React, { useState, useEffect } from 'react';
import type { Project, SprintPlan, ProjectAllocation } from '../types';
import { XIcon } from './icons';

const BulkPlannerModal: React.FC<{
    project: Project;
    sprints: SprintPlan[];
    allAllocations: ProjectAllocation[];
    onClose: () => void;
    onSave: (updatedAllocations: ProjectAllocation[]) => void;
}> = ({ project, sprints, allAllocations, onClose, onSave }) => {
    const [tempHours, setTempHours] = useState<Record<string, string>>({});
    const [masterHours, setMasterHours] = useState('');
    const inputClasses = "w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default";
    const modalTitleId = 'bulk-planner-title';

    useEffect(() => {
        const initialHours = sprints.reduce((acc, sprint) => {
            const existingAlloc = allAllocations.find(a => a.sprintId === sprint.id && a.projectId === project.id);
            acc[sprint.id] = existingAlloc?.plannedHours || '';
            return acc;
        }, {} as Record<string, string>);
        setTempHours(initialHours);
    }, [project, sprints, allAllocations]);

    const handleMasterChange = (value: string) => {
        setMasterHours(value);
        const newHours = { ...tempHours };
        for (const sprint of sprints) {
            newHours[sprint.id] = value;
        }
        setTempHours(newHours);
    };

    const handleSave = () => {
        const otherProjectAllocations = allAllocations.filter(
            a => a.projectId !== project.id
        );
        const thisProjectNewAllocations = sprints.map(sprint => {
            const hours = tempHours[sprint.id];
            const plannedHoursNum = parseFloat(hours || '0');
            if (plannedHoursNum > 0) {
                const existingAlloc = allAllocations.find(a => a.sprintId === sprint.id && a.projectId === project.id);
                return {
                    id: existingAlloc?.id || crypto.randomUUID(),
                    sprintId: sprint.id,
                    projectId: project.id,
                    plannedHours: String(plannedHoursNum),
                };
            }
            return null;
        }).filter((a): a is ProjectAllocation => a !== null);
        onSave([...otherProjectAllocations, ...thisProjectNewAllocations]);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div role="dialog" aria-modal="true" aria-labelledby={modalTitleId} className="bg-surface rounded-xl shadow-2xl w-full max-w-2xl h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b border-border-default flex justify-between items-center flex-shrink-0">
                    <h3 id={modalTitleId} className="text-xl font-bold text-text-primary">Bulk Planner: {project.name}</h3>
                    <button onClick={onClose} aria-label="Sluiten" className="p-1 text-text-secondary hover:text-text-primary"><XIcon className="w-5 h-5"/></button>
                </header>
                <div className="p-6 flex-shrink-0">
                    <label className="text-sm font-medium text-text-secondary">Pas alle sprints aan:</label>
                    <input type="number" value={masterHours} onChange={e => handleMasterChange(e.target.value)} placeholder="bv. 40" className={`${inputClasses} mt-1 w-full md:w-1/2`} />
                    <p className="text-xs text-text-secondary/80 mt-1">Voer hier een getal in om alle onderstaande sprints in één keer te vullen. Pas daarna individuele sprints aan.</p>
                </div>
                <div className="flex-grow p-6 pt-0 overflow-y-auto">
                    <div className="space-y-2">
                        {sprints.map(sprint => (
                            <div key={sprint.id} className="grid grid-cols-3 gap-4 items-center">
                                <span className="font-medium text-sm truncate">{sprint.name}</span>
                                <span className="text-xs text-text-secondary">{new Date(sprint.startDate+'T00:00:00').toLocaleDateString('nl-NL', {day:'2-digit', month:'2-digit'})} - {new Date(sprint.endDate+'T00:00:00').toLocaleDateString('nl-NL', {day:'2-digit', month:'2-digit'})}</span>
                                <input type="number" value={tempHours[sprint.id] || ''} onChange={e => setTempHours(prev => ({...prev, [sprint.id]: e.target.value}))} className={`${inputClasses} text-center`} placeholder="Uren"/>
                            </div>
                        ))}
                    </div>
                </div>
                <footer className="p-4 bg-surface/50 border-t border-border-default flex justify-end gap-2 flex-shrink-0">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-text-primary bg-background border border-border-default rounded-lg hover:bg-black/5 dark:hover:bg-white/5">Annuleren</button>
                    <button onClick={handleSave} className="px-4 py-2 text-sm font-semibold text-white bg-primary hover:bg-primary-hover rounded-lg">Opslaan</button>
                </footer>
            </div>
        </div>
    );
};

export default BulkPlannerModal;