import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Project } from '../types';
import { useData } from '../context/DataContext';
import { PlusIcon, TrashIcon, EditIcon, BriefcaseIcon, TeamPlannerIcon, UsersIcon, CalendarDaysIcon, ChevronLeftIcon, ChevronRightIcon, ClockIcon, EyeIcon, EyeOffIcon, DashboardIcon } from './icons';
import { Tooltip } from './Tooltip';

type View = 'risk' | 'roi' | 'team-planning' | 'capacity' | 'agenda' | 'harvest' | 'management';

// --- Sub Components ---
const ProjectNameEditor: React.FC<{ project: Project; onDone: () => void; }> = ({ project, onDone }) => {
    const { updateProject } = useData();
    const [name, setName] = useState(project.name);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => { inputRef.current?.focus(); inputRef.current?.select(); }, []);

    const handleSave = async () => {
        if (name.trim() && name.trim() !== project.name) {
            await updateProject({ id: project.id, name: name.trim() });
        }
        onDone();
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') handleSave();
        else if (e.key === 'Escape') onDone();
    };

    return (
        <input ref={inputRef} type="text" value={name} onChange={(e) => setName(e.target.value)} onBlur={handleSave} onKeyDown={handleKeyDown} className="w-full pl-2 pr-1 py-1 text-sm bg-background dark:bg-surface text-text-primary border border-primary rounded-md focus:ring-2 focus:ring-primary" onClick={e => e.stopPropagation()} />
    );
};

const ProjectItem: React.FC<{
    project: Project;
    isCollapsed: boolean;
    onNavigate: (view: View, projectId?: string) => void;
}> = ({ project, isCollapsed, onNavigate }) => {
    const { data, activeProjectId, updateProject, deleteProject } = useData();
    const projects = data?.projects || [];
    const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
    const itemRef = useRef<HTMLLIElement>(null);
    const isProjectActive = activeProjectId === project.id;
    const isEditing = editingProjectId === project.id;
    
    const handleDelete = async (e: React.MouseEvent) => {
        e.stopPropagation();
        if (projects.length > 1) {
            await deleteProject(project.id);
        }
    };
    
    const handleToggleVisibility = (e: React.MouseEvent) => {
        e.stopPropagation();
        updateProject({ id: project.id, isHidden: !project.isHidden });
    };

    if (isEditing) return (
        <li key={project.id} className="p-1">
            <div className="flex items-center gap-3 py-1.5 px-3 rounded-md bg-primary/10">
                <BriefcaseIcon className="w-5 h-5 flex-shrink-0" />
                <ProjectNameEditor project={project} onDone={() => setEditingProjectId(null)} />
            </div>
        </li>
    );

    return (
        <li ref={itemRef} className="mx-2 my-0.5">
            <div className={`group flex items-center justify-between list-none text-sm font-semibold rounded-md transition-colors cursor-pointer ${isProjectActive ? 'bg-primary/10 text-primary dark:bg-primary/20 dark:text-neutral-white' : 'text-text-secondary hover:bg-background dark:hover:bg-black/10'}`}
                onClick={() => onNavigate('risk', project.id)}
            >
                <Tooltip content={project.name} disabled={!isCollapsed}>
                    <span className={`flex items-center flex-grow py-2.5 truncate ${isCollapsed ? 'justify-center' : 'gap-3 pl-3'}`}>
                        <BriefcaseIcon className="w-5 h-5 flex-shrink-0" />
                        <span className={`truncate ${isCollapsed ? 'hidden' : 'inline-block'}`}>{project.name}</span>
                    </span>
                </Tooltip>
                {!isCollapsed && (
                    <div className="flex items-center pr-1.5">
                        <div className={`flex items-center transition-opacity ${isProjectActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                            <button onClick={handleToggleVisibility} className="p-1.5 text-text-secondary/80 hover:text-primary rounded-md">{project.isHidden ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}</button>
                            <button onClick={(e) => {e.stopPropagation(); setEditingProjectId(project.id);}} className="p-1.5 text-text-secondary/80 hover:text-primary rounded-md"><EditIcon className="w-4 h-4" /></button>
                            <button onClick={handleDelete} className={`p-1.5 text-text-secondary/80 hover:text-error rounded-md ${projects.length <= 1 ? 'cursor-not-allowed opacity-50' : ''}`} disabled={projects.length <= 1}><TrashIcon className="w-4 h-4" /></button>
                        </div>
                    </div>
                )}
            </div>
        </li>
    );
};


const NavItem: React.FC<{ label: string; view: View; isActive: boolean; onClick: () => void; icon: React.ReactNode; isCollapsed: boolean; }> = ({ label, isActive, onClick, icon, isCollapsed }) => {
    const itemClasses = `flex items-center group w-full text-left rounded-md transition-colors text-sm font-semibold ${isActive ? 'bg-primary/10 text-primary dark:bg-primary/20 dark:text-neutral-white' : 'text-text-secondary hover:bg-background dark:hover:bg-black/10'}`;
    const buttonClasses = `flex items-center flex-grow py-2.5 truncate ${isCollapsed ? 'justify-center' : 'gap-3 pl-3'}`;
    
    return (
        <li className="px-2 py-0.5">
            <Tooltip content={label} disabled={!isCollapsed}>
                <button onClick={onClick} className={`${itemClasses} ${buttonClasses}`}>
                    {icon} <span className={`truncate ${isCollapsed ? 'hidden' : 'inline-block'}`}>{label}</span>
                </button>
            </Tooltip>
        </li>
    );
};


// --- Main Sidebar Component ---
export const Sidebar: React.FC<{ onNavigate: (view: View, projectId?: string) => void; isCollapsed: boolean; onToggleCollapse: () => void; activeView: View; }> = (props) => {
    const { data, addProject } = useData();
    const projects = data?.projects || [];
    const [showHidden, setShowHidden] = useState(false);
    
    const sortedVisibleProjects = useMemo(() => {
        const visible = showHidden ? projects : projects.filter(p => !p.isHidden);
        return visible.sort((a, b) => a.name.localeCompare(b.name));
    }, [projects, showHidden]);

    const handleAddProject = async () => {
        const projectColors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#6366F1', '#F43F5E'];
        const nextColor = projectColors[projects.length % projectColors.length];
        const newProjectData: Partial<Project> = { name: `Nieuw Project`, color: nextColor, totalPoints: '250', avgHoursPerPoint: '4', velocityPerSprint: '20', totalBudget: '150000', budgetHours: '', hourlyRate: '85', rangePercentage: '20', sprints: [], roi: { revenues: [], costSavings: [] } };
        
        const newProject = await addProject(newProjectData);
        if (newProject) {
            props.onNavigate('risk', newProject.id);
        }
    }

    return (
        <aside className={`bg-surface border-r border-border-default flex flex-col flex-shrink-0 transition-all duration-300 ${props.isCollapsed ? 'w-20' : 'w-72'}`}>
            <div className="flex flex-col h-full">
                <header className={`p-4 border-b border-border-default overflow-hidden ${props.isCollapsed ? 'h-16' : 'h-auto'}`}><h2 className={`text-xl font-semibold text-text-primary transition-opacity duration-200 ${props.isCollapsed ? 'opacity-0' : 'opacity-100'}`}>PO-Suite</h2></header>
                
                <nav className="flex-grow flex flex-col pt-4 overflow-hidden">
                    <div className="flex-shrink-0 px-4 mb-1 flex justify-between items-center">
                        <h3 className={`text-xs font-bold uppercase text-text-secondary/80 transition-opacity duration-200 ${props.isCollapsed ? 'opacity-0' : 'opacity-100'}`}>Projecten</h3>
                        <Tooltip content={showHidden ? "Verberg gearchiveerde projecten" : "Toon gearchiveerde projecten"} disabled={props.isCollapsed}>
                            <button onClick={() => setShowHidden(s => !s)} className={`p-1 rounded-md text-text-secondary/80 hover:text-primary ${props.isCollapsed ? 'hidden' : ''}`}>{showHidden ? <EyeOffIcon className="w-4 h-4"/> : <EyeIcon className="w-4 h-4"/>}</button>
                        </Tooltip>
                    </div>
                    <ul className="overflow-y-auto space-y-0.5">
                        {sortedVisibleProjects.map(project => <ProjectItem key={project.id} project={project} {...props} />)}
                    </ul>
                    <div className="flex-shrink-0 mt-auto">
                        <div className="px-2 py-0.5"><Tooltip content="Nieuw Project" disabled={!props.isCollapsed}><button onClick={handleAddProject} className="flex items-center group w-full text-left rounded-md transition-colors text-sm font-semibold text-text-secondary hover:bg-background dark:hover:bg-black/10"><span className={`flex items-center flex-grow py-2.5 truncate ${props.isCollapsed ? 'justify-center' : 'gap-3 pl-3'}`}><PlusIcon className="w-5 h-5"/><span className={`truncate ${props.isCollapsed ? 'hidden' : 'inline-block'}`}>Nieuw Project</span></span></button></Tooltip></div>
                        <h3 className={`px-4 mt-4 mb-1 text-xs font-bold uppercase text-text-secondary/80 transition-opacity duration-200 ${props.isCollapsed ? 'opacity-0' : 'opacity-100'}`}>Overzicht</h3>
                         <ul>
                            <NavItem label="Management Dashboard" view="management" isActive={props.activeView === 'management'} onClick={() => props.onNavigate('management')} icon={<DashboardIcon className="w-5 h-5"/>} isCollapsed={props.isCollapsed}/>
                            <NavItem label="Teamplanning" view="team-planning" isActive={props.activeView === 'team-planning'} onClick={() => props.onNavigate('team-planning')} icon={<TeamPlannerIcon className="w-5 h-5"/>} isCollapsed={props.isCollapsed}/>
                            <NavItem label="Personenbeheer" view="capacity" isActive={props.activeView === 'capacity'} onClick={() => props.onNavigate('capacity')} icon={<UsersIcon className="w-5 h-5"/>} isCollapsed={props.isCollapsed}/>
                            <NavItem label="Agenda" view="agenda" isActive={props.activeView === 'agenda'} onClick={() => props.onNavigate('agenda')} icon={<CalendarDaysIcon className="w-5 h-5"/>} isCollapsed={props.isCollapsed}/>
                            <NavItem label="Uren Import" view="harvest" isActive={props.activeView === 'harvest'} onClick={() => props.onNavigate('harvest')} icon={<ClockIcon className="w-5 h-5"/>} isCollapsed={props.isCollapsed}/>
                        </ul>
                    </div>
                </nav>
                <div className="p-2 border-t border-border-default"><button onClick={props.onToggleCollapse} className="w-full flex items-center p-2.5 text-text-secondary hover:bg-background dark:hover:bg-black/10 rounded-md transition-colors font-semibold text-sm group"><div className={`flex items-center flex-grow ${props.isCollapsed ? 'justify-center' : ''}`}><span className={`mr-3 ${props.isCollapsed ? 'hidden' : ''}`}>{props.isCollapsed ? '' : 'Zijbalk Inklappen'}</span>{props.isCollapsed ? <ChevronRightIcon className="w-5 h-5"/> : <ChevronLeftIcon className="w-5 h-5"/>}</div></button></div>
            </div>
        </aside>
    );
};