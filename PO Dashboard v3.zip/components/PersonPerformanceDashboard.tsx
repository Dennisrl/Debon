import React, { useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader } from './Card';
import InsightCard from './InsightCard';
import { generatePersonPerformanceAnalysis } from '../services/analysisService';
import type { PersonKPIs as PersonKPIsType } from '../types';
import { UsersIcon, BriefcaseIcon, ClockIcon } from './icons';

const PersonCard: React.FC<{ kpi: PersonKPIsType }> = ({ kpi }) => {
    return (
        <Card>
            <CardHeader>
                <div className="flex justify-between items-center w-full">
                    <span className="font-bold">{kpi.person.name}</span>
                    <span className="text-sm font-mono px-2 py-1 rounded bg-background">{kpi.billablePercentage.toFixed(0)}% Facturabel</span>
                </div>
            </CardHeader>
            <CardContent className="space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                        <p className="text-2xl font-bold">{kpi.totalBookedHours.toFixed(0)}</p>
                        <p className="text-xs text-text-secondary">Geboekte Uren</p>
                    </div>
                    <div>
                        <p className="text-2xl font-bold">{kpi.focusRatio.toFixed(0)}%</p>
                        <p className="text-xs text-text-secondary">Project Focus</p>
                    </div>
                    <div>
                        <p className="text-2xl font-bold">{kpi.leaveDays.toFixed(0)}</p>
                        <p className="text-xs text-text-secondary">Verlofdagen</p>
                    </div>
                </div>
                <div>
                     <p className="text-xs font-semibold text-text-secondary mb-1">Top Projecten</p>
                     <ul className="text-sm space-y-1">
                        {kpi.topProjects.length > 0 ? kpi.topProjects.map(p => (
                             <li key={p.name} className="flex justify-between items-center bg-background p-1.5 rounded-md">
                                <span className="truncate">{p.name}</span>
                                <span className="font-semibold">{p.hours.toFixed(0)}u</span>
                            </li>
                        )) : <li className="text-xs text-text-secondary italic">Geen projecturen geboekt.</li>}
                     </ul>
                </div>
            </CardContent>
        </Card>
    );
};

const PersonPerformanceDashboard: React.FC = () => {
    const { state } = useData();
    const { persons, actualHours, projects } = state;

    const personKPIs = useMemo((): PersonKPIsType[] => {
        return persons.map(person => {
            const personActuals = actualHours.filter(ah => ah.personId === person.id);
            const totalBookedHours = personActuals.reduce((sum, ah) => sum + ah.hours, 0);
            const billableHours = personActuals.filter(ah => ah.billable).reduce((sum, ah) => sum + ah.hours, 0);
            const projectHours = personActuals.filter(ah => ah.projectId).reduce((sum, ah) => sum + ah.hours, 0);

            const projectTimeMap = personActuals
                .filter(ah => ah.projectId)
                .reduce((map, ah) => {
                    const projectName = projects.find(p => p.id === ah.projectId)?.name || ah.projectName || 'Onbekend Project';
                    map.set(projectName, (map.get(projectName) || 0) + ah.hours);
                    return map;
                }, new Map<string, number>());
            
            const topProjects = Array.from(projectTimeMap.entries())
                .sort((a,b) => b[1] - a[1])
                .slice(0, 3)
                .map(([name, hours]) => ({ name, hours }));

            const leaveDays = (person.events || []).filter(e => (e.type === 'sick' || e.type === 'vacation') && e.durationType !== 'hours').length;

            return {
                person,
                totalBookedHours,
                billablePercentage: totalBookedHours > 0 ? (billableHours / totalBookedHours) * 100 : 0,
                focusRatio: totalBookedHours > 0 ? (projectHours / totalBookedHours) * 100 : 0,
                topProjects,
                leaveDays,
            };
        });
    }, [persons, actualHours, projects]);
    
    const explanation = (
        <div>
            <p>Dit dashboard toont de belangrijkste prestatie-indicatoren voor elk individu op basis van de geïmporteerde uren. Dit helpt bij het identificeren van trends in productiviteit, facturabiliteit en werklast.</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
                <li><strong>Facturabel %:</strong> Het percentage van de totale geboekte uren dat factureerbaar was.</li>
                <li><strong>Geboekte Uren:</strong> Het totaal aantal uren dat is vastgelegd in de import.</li>
                <li><strong>Project Focus:</strong> Het percentage van de tijd dat aan specifieke projecten is besteed versus interne of niet-projectgerelateerde taken.</li>
                <li><strong>Verlofdagen:</strong> Het aantal geregistreerde ziekmeldingen of vakantiedagen.</li>
            </ul>
        </div>
    );

    return (
        <div className="space-y-6">
            <InsightCard 
                title="Analyse van Persoonlijke Prestaties"
                explanation={explanation}
                onGenerateAnalysis={() => generatePersonPerformanceAnalysis(personKPIs)}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {personKPIs.sort((a,b) => b.totalBookedHours - a.totalBookedHours).map(kpi => (
                    <PersonCard key={kpi.person.id} kpi={kpi} />
                ))}
                {personKPIs.length === 0 && (
                    <p className="col-span-full text-center text-text-secondary py-8">Er zijn geen personen om weer te geven.</p>
                )}
            </div>
        </div>
    );
};

export default PersonPerformanceDashboard;
