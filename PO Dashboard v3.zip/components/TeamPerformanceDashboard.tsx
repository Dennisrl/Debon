


import React, { useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader } from './Card';
import { UsersIcon } from './icons';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { calculateSprintCapacity, expandRecurringEvents } from '../services/planningService';
import type { Team } from '../types';
import InsightCard from './InsightCard';
import { generateTeamPerformanceAnalysis } from '../services/analysisService';

export interface TeamKPIs {
    team: Team;
    capacityUtilization: number;
    focusRatio: number;
    disruptionPercentage: number;
    hoursBreakdown: { name: string, value: number }[];
}

const COLORS = {
    'Project (Factureerbaar)': 'var(--color-primary-main)',
    'Project (Niet-Factureerbaar)': 'var(--color-secondary-main)',
    'Ad-hoc / SLA': 'var(--color-warning-main)',
    'Scrum Events': 'var(--color-error-main)',
    'Verlof / Ziekte': 'var(--color-text-secondary)',
};

const CustomTooltip: React.FC<any> = ({ active, payload }) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-surface/90 backdrop-blur-sm p-2 rounded-lg border border-border-default shadow-lg text-sm">
                <p className="font-semibold">{`${payload[0].name}: ${payload[0].value.toFixed(0)}u`}</p>
            </div>
        );
    }
    return null;
};

const TeamPerformanceDashboard: React.FC = () => {
    const { state } = useData();
    const { teams, persons, teamMembers, sprintPlans, actualHours, globalEvents } = state;

    const teamKPIs = useMemo((): TeamKPIs[] => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return teams.map(team => {
            const membersOfTeam = teamMembers.filter(tm => tm.teamId === team.id);
            const memberPersonIds = new Set(membersOfTeam.map(tm => tm.personId));
            const memberPersons = persons.filter(p => memberPersonIds.has(p.id));

            const pastSprints = sprintPlans.filter(sp => sp.teamId === team.id && new Date(sp.endDate) < today);
            
            let totalCapacity = 0;
            let totalBookedHours = 0;
            let projectHours = 0;
            let billableProjectHours = 0;
            let nonBillableProjectHours = 0;
            let adhocHours = 0;
            let scrumHours = 0;
            
            if (pastSprints.length > 0) {
                const viewStart = new Date(pastSprints[0].startDate);
                const viewEnd = new Date(pastSprints[pastSprints.length - 1].endDate);
                
                const expandedGlobal = expandRecurringEvents(globalEvents, viewStart, viewEnd);
                const expandedPersonal = new Map(memberPersons.map(p => [p.id, expandRecurringEvents(p.events, viewStart, viewEnd)]));

                for (const sprint of pastSprints) {
                    const capacityResult = calculateSprintCapacity(sprint, team, membersOfTeam, memberPersons, expandedGlobal, expandedPersonal);
                    totalCapacity += capacityResult.totalRawHours;
                }
                
                const sprintDateRanges = pastSprints.map(s => ({ start: new Date(s.startDate), end: new Date(s.endDate) }));
                const teamActuals = actualHours.filter(ah => {
                    if (!memberPersonIds.has(ah.personId!)) return false;
                    const entryDate = new Date(ah.date);
                    return sprintDateRanges.some(r => entryDate >= r.start && entryDate <= r.end);
                });

                totalBookedHours = teamActuals.reduce((sum, ah) => sum + ah.hours, 0);

                const scrumKeywords = ['scrum', 'daily', 'planning', 'review', 'retro', 'refinement'];
                const adhocKeywords = ['sla', 'support', 'onderhoud', 'ad-hoc'];

                teamActuals.forEach(ah => {
                    if (ah.projectId) {
                        projectHours += ah.hours;
                        if (ah.billable) billableProjectHours += ah.hours;
                        else nonBillableProjectHours += ah.hours;
                    } else {
                        const task = ah.task?.toLowerCase() || '';
                        if (scrumKeywords.some(k => task.includes(k))) scrumHours += ah.hours;
                        else if (adhocKeywords.some(k => task.includes(k))) adhocHours += ah.hours;
                        else adhocHours += ah.hours; // Default non-project to adhoc
                    }
                });
            }

            const capacityUtilization = totalCapacity > 0 ? (totalBookedHours / totalCapacity) * 100 : 0;
            const focusRatio = totalBookedHours > 0 ? (projectHours / totalBookedHours) * 100 : 0;
            const disruptionPercentage = totalBookedHours > 0 ? (adhocHours / totalBookedHours) * 100 : 0;

            const leaveHours = totalCapacity - totalBookedHours;

            const hoursBreakdown = [
                { name: 'Project (Factureerbaar)', value: billableProjectHours },
                { name: 'Project (Niet-Factureerbaar)', value: nonBillableProjectHours },
                { name: 'Ad-hoc / SLA', value: adhocHours },
                { name: 'Scrum Events', value: scrumHours },
                { name: 'Verlof / Ziekte', value: Math.max(0, leaveHours) }, // Can't be negative
            ].filter(d => d.value > 0.1); // Filter out tiny values for cleaner chart

            return { team, capacityUtilization, focusRatio, disruptionPercentage, hoursBreakdown };
        });
    }, [teams, persons, teamMembers, sprintPlans, actualHours, globalEvents]);
    
    const totalBreakdown = useMemo(() => {
        const total = new Map<string, number>();
        teamKPIs.forEach(kpi => {
            kpi.hoursBreakdown.forEach(breakdown => {
                total.set(breakdown.name, (total.get(breakdown.name) || 0) + breakdown.value);
            });
        });
        return Array.from(total.entries()).map(([name, value]) => ({ name, value })).filter(d => d.value > 0.1);
    }, [teamKPIs]);

    const DonutChart: React.FC<{ data: { name: string; value: number }[], title: string }> = ({ data, title }) => (
        <Card className="flex flex-col">
            <CardHeader>{title}</CardHeader>
            <CardContent className="flex-grow flex flex-col items-center justify-center">
                <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                        <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} fill="#8884d8" paddingAngle={5} labelLine={false}
                             label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                                if (percent < 0.05) return null; // Hide label for small slices
                                const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                                const x = cx + (radius + 20) * Math.cos(-midAngle * (Math.PI / 180));
                                const y = cy + (radius + 20) * Math.sin(-midAngle * (Math.PI / 180));
                                return <text x={x} y={y} fill="var(--color-text-primary)" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">{`${(percent * 100).toFixed(0)}%`}</text>;
                            }}
                        >
                            {data.map((entry, index) => <Cell key={`cell-${index}`} fill={(COLORS as any)[entry.name] || '#ccc'} />)}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                </ResponsiveContainer>
                 <div className="w-full mt-4 text-xs space-y-1 grid grid-cols-2">
                    {Object.entries(COLORS).map(([name, color]) => (
                        <div key={name} className="flex items-center">
                            <div className="w-3 h-3 rounded-sm mr-2 flex-shrink-0" style={{ backgroundColor: color }}></div>
                            <span className="truncate">{name}</span>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );

    const explanation = (
        <div>
            <p>Dit dashboard analyseert de prestaties van de teams op basis van historische sprintdata. Het geeft inzicht in hoe teams hun tijd besteden en hoe efficiënt ze hun geplande capaciteit benutten.</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
                <li><strong>Capaciteitsbenutting:</strong> Het percentage van de totale beschikbare uren dat daadwerkelijk is geboekt. Een score dicht bij 100% duidt op een goede planning.</li>
                <li><strong>Focus Ratio:</strong> Het percentage van de geboekte uren dat aan projectwerk is besteed. Een hoge ratio is wenselijk.</li>
                <li><strong>Verstoring:</strong> Het percentage van de tijd dat is besteed aan ad-hoc/ongepland werk. Een lage ratio duidt op een stabiel proces.</li>
                <li><strong>Urenverdeling (Donut Chart):</strong> Een visuele uitsplitsing van waar de tijd van het team naartoe gaat.</li>
            </ul>
        </div>
    );

    return (
        <div className="space-y-6">
             <InsightCard
                title="Analyse van Teamprestaties"
                explanation={explanation}
                onGenerateAnalysis={() => generateTeamPerformanceAnalysis(teamKPIs)}
            />
            <Card>
                <CardHeader icon={<UsersIcon className="w-6 h-6" />}>Team KPI Overzicht (Historisch)</CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="text-left text-xs text-text-secondary uppercase">
                                <tr>
                                    <th className="p-2">Team</th>
                                    <th className="p-2 text-right">Capaciteitsbenutting</th>
                                    <th className="p-2 text-right">Focus Ratio (Projectwerk)</th>
                                    <th className="p-2 text-right">Verstoring (Ongepland)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {teamKPIs.map(({ team, capacityUtilization, focusRatio, disruptionPercentage }) => (
                                    <tr key={team.id} className="border-t border-border-default">
                                        <td className="p-3 font-semibold">{team.name}</td>
                                        <td className="p-3 text-right font-mono">{capacityUtilization.toFixed(0)}%</td>
                                        <td className="p-3 text-right font-mono text-success">{focusRatio.toFixed(0)}%</td>
                                        <td className="p-3 text-right font-mono text-warning">{disruptionPercentage.toFixed(0)}%</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {teamKPIs.map(({ team, hoursBreakdown }) => (
                    <DonutChart key={team.id} data={hoursBreakdown} title={`Urenverdeling: ${team.name}`} />
                ))}
                {totalBreakdown.length > 0 && (
                    <DonutChart data={totalBreakdown} title="Urenverdeling: Totaal" />
                )}
            </div>
        </div>
    );
};

export default TeamPerformanceDashboard;