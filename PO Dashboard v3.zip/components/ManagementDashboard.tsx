



import React, { useState } from 'react';
import ProjectPortfolioDashboard from './ProjectPortfolioDashboard';
import TeamPerformanceDashboard from './TeamPerformanceDashboard';
import PersonPerformanceDashboard from './PersonPerformanceDashboard';
import ScenarioPlanner from './ScenarioPlanner';

type Tab = 'portfolio' | 'teams' | 'persons' | 'scenario';

const ManagementDashboard: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('portfolio');

    const renderTabButton = (tab: Tab, label: string) => (
         <button
            onClick={() => setActiveTab(tab)}
            className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === tab
                    ? 'border-primary text-primary'
                    : 'border-transparent text-text-secondary hover:text-text-primary hover:border-border-default'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <div className="mb-6">
                <h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">Management Dashboard</h2>
                <p className="mt-2 text-text-secondary">Overkoepelend overzicht van projecten, teams en personen.</p>
            </div>

            <div className="border-b border-border-default mb-6">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    {renderTabButton('portfolio', 'Project Portfolio')}
                    {renderTabButton('teams', 'Team Performance')}
                    {renderTabButton('persons', 'Personenoverzicht')}
                    {renderTabButton('scenario', 'Scenario Planner')}
                </nav>
            </div>

            <div>
                {activeTab === 'portfolio' && <ProjectPortfolioDashboard />}
                {activeTab === 'teams' && <TeamPerformanceDashboard />}
                {activeTab === 'persons' && <PersonPerformanceDashboard />}
                {activeTab === 'scenario' && <ScenarioPlanner />}
            </div>
        </div>
    );
};

export default ManagementDashboard;
