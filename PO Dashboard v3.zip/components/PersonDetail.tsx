import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Person, WorkPattern, WorkPatternEntry } from '../types';
import { useData } from '../context/DataContext';
import { PlusIcon, TrashIcon, CalendarIcon, ChevronLeftIcon } from './icons';

export const defaultWorkPattern: WorkPattern = {
  type: 'standard',
  standardHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '8', sat: '0', sun: '0' },
  evenWeekHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '8', sat: '0', sun: '0' },
  oddWeekHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '8', sat: '0', sun: '0' },
};

const inputClasses = "w-full text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default";
const dayInputClasses = "w-16 text-center text-sm bg-background p-2 rounded-md focus:ring-1 focus:ring-primary border border-border-default";
const dayLabelClasses = "block text-xs text-center font-medium text-text-secondary";

const calculateAverageHours = (pattern: WorkPattern): number => {
    if (pattern.type === 'even-odd' && pattern.evenWeekHours && pattern.oddWeekHours) {
        const even = Object.values(pattern.evenWeekHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
        const odd = Object.values(pattern.oddWeekHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
        return (even + odd) / 2;
    }
    return Object.values(pattern.standardHours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0);
};

const DayHoursInputGrid: React.FC<{
  title: string;
  hours: WorkPattern['standardHours'];
  onHoursChange: (day: keyof WorkPattern['standardHours'], value: string) => void;
}> = ({ title, hours, onHoursChange }) => {
    const totalHours = useMemo(() => Object.values(hours).reduce((acc, h) => acc + (parseFloat(h) || 0), 0), [hours]);

    return (
        <div className="p-3 bg-background rounded-lg">
            <div className="flex justify-between items-center mb-2">
                <h5 className="text-sm font-semibold text-text-secondary">{title}</h5>
                <p className="text-sm font-bold text-primary">Totaal: {totalHours} uur</p>
            </div>
            <div className="grid grid-cols-7 gap-2">
                {(Object.keys(hours) as Array<keyof typeof hours>).map(day => (
                    <div key={day}>
                        <label className={dayLabelClasses}>{day.toUpperCase()}</label>
                        <input type="number" value={hours[day]} onChange={(e) => onHoursChange(day, e.target.value)} className={dayInputClasses} placeholder="0" min="0" max="24" />
                    </div>
                ))}
            </div>
        </div>
    );
};

const WorkPatternEditor: React.FC<{
    entry: WorkPatternEntry;
    onUpdate: (updatedEntry: WorkPatternEntry) => void;
    onDelete: () => void;
    isFirst: boolean;
}> = ({ entry, onUpdate, onDelete, isFirst }) => {
    const [localDate, setLocalDate] = useState(entry.startDate);

    useEffect(() => {
        setLocalDate(entry.startDate);
    }, [entry.startDate]);
    
    const handleDateBlur = () => {
        if (localDate !== entry.startDate) {
            onUpdate({ ...entry, startDate: localDate });
        }
    };

    const handlePatternChange = (field: keyof WorkPattern, value: any) => {
        onUpdate({ ...entry, pattern: { ...entry.pattern, [field]: value } });
    };

    const handleDayHoursChange = (weekType: 'standardHours' | 'evenWeekHours' | 'oddWeekHours', day: keyof WorkPattern['standardHours'], value: string) => {
        const pattern = entry.pattern;
        const updatedHours = { ...(pattern[weekType] || defaultWorkPattern[weekType]), [day]: value };
        handlePatternChange(weekType, updatedHours);
    };

    const averageHours = useMemo(() => calculateAverageHours(entry.pattern), [entry.pattern]);

    return (
        <details className="group bg-surface border border-border-default rounded-xl" open>
            <summary className="flex items-center justify-between p-3 list-none cursor-pointer">
                <div className="flex items-center gap-3">
                    <CalendarIcon className="w-5 h-5 text-primary"/>
                    <input type="date" value={localDate} onChange={e => setLocalDate(e.target.value)} onBlur={handleDateBlur} className={inputClasses} />
                    <span className="text-sm font-semibold">{averageHours.toFixed(1)} uur/week</span>
                </div>
                 <div className="flex items-center gap-2">
                    {!isFirst && <button onClick={(e) => { e.preventDefault(); onDelete(); }} className="p-2 text-text-secondary/70 hover:text-error rounded-md" aria-label="Verwijder patroon"><TrashIcon className="w-4 h-4"/></button>}
                </div>
            </summary>
            <div className="p-4 border-t border-border-default space-y-4">
                 <div className="flex items-center gap-4">
                     <label className="flex items-center gap-2"><input type="radio" name={`pattern-type-${entry.id}`} value="standard" checked={entry.pattern.type === 'standard'} onChange={() => handlePatternChange('type', 'standard')} className="text-primary focus:ring-primary"/>Standaard week</label>
                     <label className="flex items-center gap-2"><input type="radio" name={`pattern-type-${entry.id}`} value="even-odd" checked={entry.pattern.type === 'even-odd'} onChange={() => handlePatternChange('type', 'even-odd')} className="text-primary focus:ring-primary"/>Even/oneven week</label>
                 </div>
                 {entry.pattern.type === 'standard' && <DayHoursInputGrid title="Standaard week" hours={entry.pattern.standardHours} onHoursChange={(d, v) => handleDayHoursChange('standardHours', d, v)}/>}
                 {entry.pattern.type === 'even-odd' && (<>
                     <DayHoursInputGrid title="Even weken" hours={entry.pattern.evenWeekHours!} onHoursChange={(d, v) => handleDayHoursChange('evenWeekHours', d, v)} />
                     <DayHoursInputGrid title="Oneven weken" hours={entry.pattern.oddWeekHours!} onHoursChange={(d, v) => handleDayHoursChange('oddWeekHours', d, v)} />
                 </>)}
            </div>
        </details>
    )
}

interface PersonDetailProps {
    person: Person;
    onBack: () => void;
}

const PersonDetail: React.FC<PersonDetailProps> = ({ person, onBack }) => {
    const { dispatch } = useData();
    const [localPerson, setLocalPerson] = useState(person);
    const debounceTimeoutRef = useRef<number | null>(null);

    useEffect(() => setLocalPerson(person), [person]);

    const triggerUpdate = (updatedPerson: Person) => {
        if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
        debounceTimeoutRef.current = window.setTimeout(() => {
            dispatch({ type: 'UPDATE_PERSON', payload: updatedPerson });
        }, 500);
    };

    const handleChange = (field: keyof Person, value: any) => {
        const updated = { ...localPerson, [field]: value };
        setLocalPerson(updated);
        triggerUpdate(updated);
    };
    
    const handlePatternUpdate = (updatedEntry: WorkPatternEntry) => {
        const updatedPatterns = localPerson.workPatterns.map(p => p.id === updatedEntry.id ? updatedEntry : p);
        const updatedPerson = { ...localPerson, workPatterns: updatedPatterns };
        setLocalPerson(updatedPerson);
        triggerUpdate(updatedPerson);
    };
    
    const handleAddPattern = () => {
        const lastPattern = [...localPerson.workPatterns].sort((a,b) => b.startDate.localeCompare(a.startDate))[0];
        const lastStartDate = new Date(lastPattern.startDate + 'T00:00:00');
        lastStartDate.setDate(lastStartDate.getDate() + 1);

        const newEntry: WorkPatternEntry = {
            id: crypto.randomUUID(),
            startDate: lastStartDate.toISOString().split('T')[0],
            pattern: JSON.parse(JSON.stringify(lastPattern.pattern))
        };
        const updatedPerson = { ...localPerson, workPatterns: [...localPerson.workPatterns, newEntry] };
        setLocalPerson(updatedPerson);
        triggerUpdate(updatedPerson);
    };
    
    const handlePatternDelete = (id: string) => {
        if (localPerson.workPatterns.length <= 1) return;
        const updatedPatterns = localPerson.workPatterns.filter(p => p.id !== id);
        const updatedPerson = { ...localPerson, workPatterns: updatedPatterns };
        setLocalPerson(updatedPerson);
        triggerUpdate(updatedPerson);
    };

    const sortedPatterns = useMemo(() => [...localPerson.workPatterns].sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime()), [localPerson.workPatterns]);
    
    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <div className="flex items-start justify-between mb-6">
                 <div>
                    <button onClick={onBack} className="flex items-center gap-2 text-sm font-semibold text-primary hover:underline mb-4">
                        <ChevronLeftIcon className="w-5 h-5" />
                        Terug naar overzicht
                    </button>
                    <h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">{localPerson.name}</h2>
                    <p className="mt-2 text-text-secondary">Beheer de contracten en werkpatronen van {localPerson.name}.</p>
                </div>
            </div>

             <div className="bg-surface border border-border-default rounded-xl shadow-sm p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                     <div>
                        <label htmlFor={`name-${person.id}`} className="text-xs font-medium text-text-secondary block mb-1">Naam</label>
                        <input id={`name-${person.id}`} type="text" value={localPerson.name} onChange={e => handleChange('name', e.target.value)} className={inputClasses} placeholder="Naam teamlid"/>
                    </div>
                     <div>
                        <label htmlFor={`start-date-${person.id}`} className="text-xs font-medium text-text-secondary block mb-1">Startdatum contract</label>
                        <input id={`start-date-${person.id}`} type="date" value={localPerson.contractStartDate} onChange={e => handleChange('contractStartDate', e.target.value)} className={inputClasses}/>
                    </div>
                     <div>
                        <label htmlFor={`end-date-${person.id}`} className="text-xs font-medium text-text-secondary block mb-1">Einddatum contract</label>
                        <input id={`end-date-${person.id}`} type="date" value={localPerson.contractEndDate} onChange={e => handleChange('contractEndDate', e.target.value)} className={inputClasses}/>
                    </div>
                </div>
                <div>
                     <div className="flex justify-between items-center mb-2">
                        <label className="text-sm font-semibold text-text-primary block">Werkpatronen</label>
                        <button onClick={handleAddPattern} className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-primary bg-primary/10 rounded-full hover:bg-primary/20"><PlusIcon className="w-4 h-4"/> Nieuw Patroon</button>
                    </div>
                     <div className="space-y-4">
                        {sortedPatterns.map((entry, index) => <WorkPatternEditor key={entry.id} entry={entry} onUpdate={handlePatternUpdate} onDelete={() => handlePatternDelete(entry.id)} isFirst={index === 0} />)}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default PersonDetail;