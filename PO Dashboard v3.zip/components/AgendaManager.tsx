


import React, { useState, useMemo } from 'react';
import type { GlobalEvent, GlobalEventType, CalendarEvent, CalendarEventType, Person } from '../types';
import { useData } from '../context/DataContext';
import AgendaEventModal from './AgendaEventModal';
import { Card, CardContent, CardHeader } from './Card';
import { PlusIcon, GlobeIcon, UsersIcon, EditIcon, TrashIcon } from './icons';
import { getDayDiff } from '../services/planningService';

type EditableEvent = { type: 'personal', event: CalendarEvent, personId: string } | { type: 'global', event: GlobalEvent };

const getDutchEventType = (type: GlobalEventType | CalendarEventType, isGlobal: boolean): string => {
    if (isGlobal) {
        return ({
            'holiday': 'Feestdag', 'company-day': 'Bedrijfsuitje / Teamdag',
            'learning-day': 'Leermiddag', 'other': 'Overig'
        })[type as GlobalEventType] || type;
    }
    return ({
        'vacation': 'Vakantie', 'sick': 'Ziekte',
        'extra': 'Extra Werk', 'other': 'Overig'
    })[type as CalendarEventType] || type;
};

const renderDateColumn = (event: GlobalEvent | CalendarEvent) => event.durationType === 'multiday' && event.endDate && event.startDate !== event.endDate
    ? `${new Date(event.startDate+'T00:00:00').toLocaleDateString('nl-NL')} - ${new Date(event.endDate+'T00:00:00').toLocaleDateString('nl-NL')}`
    : new Date(event.startDate+'T00:00:00').toLocaleDateString('nl-NL');

const renderDetailsColumn = (event: GlobalEvent | CalendarEvent) => {
    if (event.recurrenceRule) return `Herhalend (${({ 'daily': 'Dagelijks', 'weekly': 'Wekelijks', 'monthly': 'Maandelijks', 'yearly': 'Jaarlijks'})[event.recurrenceRule.frequency]})`;
    if (event.durationType === 'hours') return `${event.hours || '0'} uur`;
    if (event.durationType === 'fullday') return 'Hele dag';
    const diff = getDayDiff(new Date(event.startDate), new Date(event.endDate || event.startDate)) + 1;
    return `${diff} dag${diff > 1 ? 'en' : ''}`;
};


const AgendaManager: React.FC = () => {
    const { state, dispatch } = useData();
    const { globalEvents, persons } = state;

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [eventToEdit, setEventToEdit] = useState<EditableEvent | null>(null);

    const handleOpenModalForNew = () => {
        setEventToEdit(null);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (item: EditableEvent) => {
        setEventToEdit(item);
        setIsModalOpen(true);
    };

    const handleDeleteEvent = (item: EditableEvent) => {
        // The confirmation dialog is removed due to sandbox restrictions.
        if (item.type === 'global') {
            dispatch({ type: 'DELETE_GLOBAL_EVENT', payload: item.event.id });
        } else {
            dispatch({ type: 'DELETE_PERSONAL_EVENT', payload: { personId: item.personId, eventId: item.event.id } });
        }
    };
    
    const allPersonalEvents = useMemo(() => {
        return persons.flatMap(person => 
            (person.events || []).map(event => ({ event, personId: person.id, personName: person.name }))
        ).sort((a,b) => new Date(a.event.startDate).getTime() - new Date(b.event.startDate).getTime());
    }, [persons]);

    const sortedGlobalEvents = useMemo(() => {
        return [...globalEvents].sort((a,b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
    }, [globalEvents]);

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <AgendaEventModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} eventToEdit={eventToEdit} />

            <div className="flex items-start justify-between mb-6">
                <div>
                    <h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">Agenda & Afwezigheid</h2>
                    <p className="mt-2 text-text-secondary">Beheer alle persoonlijke en globale evenementen.</p>
                </div>
                <button onClick={handleOpenModalForNew} className="flex-shrink-0 ml-4 flex items-center justify-center gap-2 px-5 py-2.5 text-base font-semibold text-neutral-white bg-primary rounded-lg hover:bg-primary-hover transition-all"><PlusIcon className="w-5 h-5"/>Nieuw Evenement</button>
            </div>

            <div className="space-y-8">
                <Card>
                    <CardHeader icon={<GlobeIcon className="w-6 h-6"/>}>Globale Evenementen</CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="text-xs text-text-secondary uppercase bg-surface/50">
                                    <tr>
                                        <th className="px-4 py-3">Titel</th><th className="px-4 py-3">Type</th>
                                        <th className="px-4 py-3">Datum/Periode</th><th className="px-4 py-3">Details</th>
                                        <th className="px-4 py-3 text-right">Acties</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sortedGlobalEvents.length > 0 ? sortedGlobalEvents.map(event => (
                                        <tr key={event.id} className="border-b border-border-default">
                                            <td className="px-4 py-3 font-medium text-text-primary">{event.title}</td>
                                            <td className="px-4 py-3">{getDutchEventType(event.type, true)}</td>
                                            <td className="px-4 py-3">{renderDateColumn(event)}</td>
                                            <td className="px-4 py-3">{renderDetailsColumn(event)}</td>
                                            <td className="px-4 py-3 text-right">
                                                <button onClick={() => handleOpenModalForEdit({ type: 'global', event })} className="p-1.5 text-text-secondary/80 hover:text-primary rounded-md mr-2"><EditIcon className="w-4 h-4"/></button>
                                                <button onClick={() => handleDeleteEvent({ type: 'global', event })} className="p-1.5 text-text-secondary/80 hover:text-error rounded-md"><TrashIcon className="w-4 h-4"/></button>
                                            </td>
                                        </tr>
                                    )) : (
                                        <tr><td colSpan={5} className="text-center py-12 text-text-secondary">Geen globale evenementen gevonden.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader icon={<UsersIcon className="w-6 h-6"/>}>Persoonlijke Evenementen</CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="text-xs text-text-secondary uppercase bg-surface/50">
                                    <tr>
                                        <th className="px-4 py-3">Persoon</th><th className="px-4 py-3">Titel</th>
                                        <th className="px-4 py-3">Type</th><th className="px-4 py-3">Datum/Periode</th>
                                        <th className="px-4 py-3">Details</th><th className="px-4 py-3 text-right">Acties</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {allPersonalEvents.length > 0 ? allPersonalEvents.map(({ event, personId, personName }) => (
                                        <tr key={`${personId}-${event.id}`} className="border-b border-border-default">
                                            <td className="px-4 py-3 font-medium text-text-primary">{personName}</td>
                                            <td className="px-4 py-3">{event.title}</td>
                                            <td className="px-4 py-3">{getDutchEventType(event.type, false)}</td>
                                            <td className="px-4 py-3">{renderDateColumn(event)}</td>
                                            <td className="px-4 py-3">{renderDetailsColumn(event)}</td>
                                            <td className="px-4 py-3 text-right">
                                                <button onClick={() => handleOpenModalForEdit({ type: 'personal', event, personId })} className="p-1.5 text-text-secondary/80 hover:text-primary rounded-md mr-2"><EditIcon className="w-4 h-4"/></button>
                                                <button onClick={() => handleDeleteEvent({ type: 'personal', event, personId })} className="p-1.5 text-text-secondary/80 hover:text-error rounded-md"><TrashIcon className="w-4 h-4"/></button>
                                            </td>
                                        </tr>
                                    )) : (
                                        <tr><td colSpan={6} className="text-center py-12 text-text-secondary">Geen persoonlijke evenementen gevonden.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default AgendaManager;