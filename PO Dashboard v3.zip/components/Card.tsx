import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div
      className={`bg-surface border border-border-default rounded-2xl shadow-md ${className}`}
    >
      {children}
    </div>
  );
};

interface CardHeaderProps {
    children: React.ReactNode;
    className?: string;
    icon?: React.ReactNode;
}

export const CardHeader: React.FC<CardHeaderProps> = ({ children, className = '', icon }) => {
    return (
        <div className={`p-4 sm:p-6 border-b border-border-default flex items-center gap-3 ${className}`}>
            {icon && <div className="text-primary">{icon}</div>}
            <div className="text-xl font-bold text-text-primary flex-grow">{children}</div>
        </div>
    );
};


interface CardContentProps {
    children: React.ReactNode;
    className?: string;
}

export const CardContent: React.FC<CardContentProps> = ({ children, className = '' }) => {
    return (
        <div className={`p-4 sm:p-6 ${className}`}>
            {children}
        </div>
    );
};