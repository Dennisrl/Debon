import React, { useState, useMemo } from 'react';
import type { Person } from '../types';
import { useData } from '../context/DataContext';
import { Card, CardContent } from './Card';
import { PlusIcon, UsersIcon } from './icons';
import PersonList from './PersonList';
import PersonDetail, { defaultWorkPattern } from './PersonDetail';

const CapacityManager: React.FC = () => {
    const { data, addPerson, deletePerson } = useData();
    const persons = data?.persons || [];
    const [editingPersonId, setEditingPersonId] = useState<string | null>(null);

    const handleAddPerson = async () => {
        const startDate = new Date().toISOString().split('T')[0];
        const newPerson: Person = {
            id: crypto.randomUUID(),
            name: 'Nieuw Teamlid',
            contractStartDate: startDate,
            contractEndDate: '',
            workPatterns: [{
                id: crypto.randomUUID(),
                startDate: startDate,
                pattern: JSON.parse(JSON.stringify(defaultWorkPattern))
            }],
            events: [],
        };
        const createdPerson = await addPerson(newPerson);
        if (createdPerson) {
            setEditingPersonId(createdPerson.id);
        }
    };

    const handleDeletePerson = (personId: string) => {
        deletePerson(personId);
    };

    const editingPerson = useMemo(() => persons.find(p => p.id === editingPersonId), [persons, editingPersonId]);
    
    if (editingPerson) {
        return <PersonDetail key={editingPerson.id} person={editingPerson} onBack={() => setEditingPersonId(null)} />;
    }

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <div className="flex items-start justify-between mb-6">
                <div>
                    <h2 className="text-4xl sm:text-5xl font-extrabold text-text-primary">Personenbeheer</h2>
                    <p className="mt-2 text-text-secondary">Beheer de contracten en werkpatronen van je teamleden.</p>
                </div>
                <button onClick={handleAddPerson} className="flex-shrink-0 ml-4 flex items-center justify-center gap-2 px-5 py-2.5 text-base font-semibold text-neutral-white bg-primary rounded-lg hover:bg-primary-hover transition-all"><PlusIcon className="w-5 h-5"/>Teamlid Toevoegen</button>
            </div>
            
            {persons.length > 0 ? (
                <PersonList persons={persons} onEditPerson={setEditingPersonId} onDeletePerson={handleDeletePerson} />
            ) : (
                <Card>
                    <CardContent className="text-center py-12">
                        <UsersIcon className="mx-auto w-12 h-12 text-border-default dark:text-secondary"/>
                        <h3 className="mt-4 text-lg font-semibold text-text-primary">Nog geen teamleden</h3>
                        <p className="mt-1 text-sm text-text-secondary">Voeg je eerste teamlid toe om de capaciteit te beheren.</p>
                        <button onClick={handleAddPerson} className="mt-6 flex items-center justify-center gap-2 px-4 py-2 mx-auto text-sm font-semibold text-neutral-white bg-primary rounded-lg hover:bg-primary-hover transition-all"><PlusIcon className="w-4 h-4"/>Voeg Teamlid Toe</button>
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default CapacityManager;
