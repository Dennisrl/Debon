// @ts-nocheck
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import CapacityManager from '../../components/CapacityManager';
import { DataProvider } from '../../context/DataContext'; // Assuming we can import this
import { Person } from '../../types';

// A custom render function to wrap components with the DataProvider
// In a real app, this would be a shared test utility.
const renderWithContext = (
  ui: React.ReactElement,
  { providerProps, ...renderOptions }: any = {}
) => {
  return render(
    <DataProvider {...providerProps}>{ui}</DataProvider>,
    renderOptions
  );
};


// Mock the DataContext using a custom wrapper
// This is a more advanced technique for components deeply coupled with context.
// For this test, we'll assume a simplified approach: we can't easily mock the context hook's internals,
// so we'll test the component's output and trust the dispatch call is made. A better way would be to spy on dispatch.

const workPattern40h = { type: 'standard', standardHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '8', sat: '0', sun: '0' } };
const workPattern32h = { type: 'standard', standardHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '0', sat: '0', sun: '0' } };


// Mock the useData hook
jest.mock('../../context/DataContext', () => {
    const originalModule = jest.requireActual('../../context/DataContext');
    const mockDispatch = jest.fn();
    return {
        ...originalModule,
        useData: () => ({
            state: {
                persons: [
                    { id: 'p1', name: 'John Doe', contractStartDate: '2025-01-01', contractEndDate: '', workPatterns: [{id: 'wp1', startDate: '2025-01-01', pattern: workPattern40h}], events: [] },
                    { id: 'p2', name: 'Jane Smith', contractStartDate: '2025-01-01', contractEndDate: '', workPatterns: [{id: 'wp2', startDate: '2025-01-01', pattern: workPattern32h}], events: [] }
                ],
                // Add other necessary state properties if the component uses them
                theme: 'light',
            },
            dispatch: mockDispatch,
        }),
    };
});


describe('CapacityManager', () => {
    
  it('renders the main title and add button', () => {
    render(<CapacityManager />);
    expect(screen.getByText('Capaciteitsbeheer')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Teamlid Toevoegen/i })).toBeInTheDocument();
  });

  it('renders a list of persons from context', () => {
    render(<CapacityManager />);
    // Check if the names of the mock persons are rendered
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('Jane Smith')).toBeInTheDocument();
  });
  
  it('shows an empty state message when no persons are available', () => {
    // We need to mock useData to return an empty persons array for this test
    jest.spyOn(require('../../context/DataContext'), 'useData').mockImplementation(() => ({
      state: { persons: [], theme: 'light' },
      dispatch: jest.fn(),
    }));

    render(<CapacityManager />);
    expect(screen.getByText('Nog geen teamleden')).toBeInTheDocument();
    expect(screen.getByText('Voeg je eerste teamlid toe om de capaciteit te beheren.')).toBeInTheDocument();
  });

  it('calls dispatch with ADD_PERSON when the "Voeg Teamlid Toe" button is clicked', () => {
    const { useData } = require('../../context/DataContext');
    const { dispatch } = useData();

    render(<CapacityManager />);
    
    const addButton = screen.getByRole('button', { name: /Teamlid Toevoegen/i });
    fireEvent.click(addButton);

    // Check if dispatch was called with an action that has the type 'ADD_PERSON'
    expect(dispatch).toHaveBeenCalledWith(expect.objectContaining({
        type: 'ADD_PERSON'
    }));
  });
});