// @ts-nocheck
import { calculatePersonSprintHours, expandRecurringEvents } from '../../services/planningService';
import { Person, SprintPlan, GlobalEvent, CalendarEvent, WorkPattern, TeamMember, WorkPatternEntry } from '../../types';

describe('planningService', () => {

  // --- Test Data ---
  const workPattern40h: WorkPattern = {
      type: 'standard', standardHours: { mon: '8', tue: '8', wed: '8', thu: '8', fri: '8', sat: '0', sun: '0' },
  };
  const testPerson: Person = {
      id: 'p1', name: 'Test Person', contractStartDate: '2025-01-01', contractEndDate: '',
      workPatterns: [{ id: 'wp1', startDate: '2025-01-01', pattern: workPattern40h }],
      events: []
  };
  const testSprint: SprintPlan = {
      id: 's1', teamId: 't1', name: 'Test Sprint', startDate: '2025-03-03', endDate: '2025-03-14' // 10 working days
  };

  // --- Tests for expandRecurringEvents ---
  describe('expandRecurringEvents', () => {
    const viewStart = new Date('2025-01-01');
    const viewEnd = new Date('2025-12-31');

    it('should expand a daily recurring event correctly', () => {
      const dailyEvent: GlobalEvent = {
        id: 'daily-1', title: 'Daily Standup', type: 'other', durationType: 'hours', hours: '0.5',
        startDate: '2025-03-10', endDate: '2025-03-10',
        recurrenceRule: { frequency: 'daily', until: '2025-03-12' }
      };
      const expanded = expandRecurringEvents([dailyEvent], viewStart, viewEnd);
      expect(expanded).toHaveLength(3);
      expect(expanded[0].startDate).toBe('2025-03-10');
      expect(expanded[1].startDate).toBe('2025-03-11');
      expect(expanded[2].startDate).toBe('2025-03-12');
    });

    it('should expand a weekly recurring event correctly', () => {
        const weeklyEvent: CalendarEvent = {
            id: 'weekly-1', title: 'Planning', type: 'other', durationType: 'hours', hours: '4',
            startDate: '2025-03-03', endDate: '2025-03-03', // A Monday
            recurrenceRule: { frequency: 'weekly', until: '2025-03-17' }
        };
        const expanded = expandRecurringEvents([weeklyEvent], viewStart, viewEnd);
        expect(expanded).toHaveLength(3);
        expect(expanded[0].startDate).toBe('2025-03-03');
        expect(expanded[1].startDate).toBe('2025-03-10');
        expect(expanded[2].startDate).toBe('2025-03-17');
    });

    it('should not expand past the "until" date', () => {
        const event: GlobalEvent = {
            id: 'e1', title: 'Test', type: 'other', durationType: 'fullday',
            startDate: '2025-05-01', endDate: '2025-05-01',
            recurrenceRule: { frequency: 'daily', until: '2025-05-02' }
        };
        const expanded = expandRecurringEvents([event], viewStart, viewEnd);
        expect(expanded).toHaveLength(2);
    });

     it('should handle non-recurring events correctly', () => {
        const event: GlobalEvent = {
            id: 'e1', title: 'Test', type: 'other', durationType: 'fullday',
            startDate: '2025-06-01', endDate: '2025-06-01',
        };
        const expanded = expandRecurringEvents([event], viewStart, viewEnd);
        expect(expanded).toHaveLength(1);
        expect(expanded[0].id).toBe(event.id);
    });
  });

  // --- Tests for calculatePersonSprintHours ---
  describe('calculatePersonSprintHours', () => {
    
    it('should calculate full capacity for a normal 2-week sprint (80 hours)', () => {
      const hours = calculatePersonSprintHours(testPerson, testSprint, [], []);
      expect(hours).toBe(80);
    });

    it('should subtract a full-day vacation', () => {
      const vacation: CalendarEvent = { id: 'v1', title: 'Day Off', type: 'vacation', durationType: 'fullday', startDate: '2025-03-10', endDate: '2025-03-10' };
      const hours = calculatePersonSprintHours(testPerson, testSprint, [], [vacation]);
      expect(hours).toBe(72); // 80 - 8
    });
    
    it('should subtract a multi-day vacation', () => {
      const vacation: CalendarEvent = { id: 'v1', title: 'Week Off', type: 'vacation', durationType: 'multiday', startDate: '2025-03-10', endDate: '2025-03-14' };
      const hours = calculatePersonSprintHours(testPerson, testSprint, [], [vacation]);
      expect(hours).toBe(40); // 80 - (5*8)
    });

    it('should subtract hours for a partial-day event', () => {
        const event: CalendarEvent = { id: 'e1', title: 'Dentist', type: 'other', durationType: 'hours', hours: '3', startDate: '2025-03-05', endDate: '2025-03-05' };
        const hours = calculatePersonSprintHours(testPerson, testSprint, [], [event]);
        expect(hours).toBe(77); // 80 - 3
    });

    it('should add hours for an extra-work event', () => {
        const event: CalendarEvent = { id: 'e1', title: 'Overtime', type: 'extra', durationType: 'hours', hours: '4', startDate: '2025-03-04', endDate: '2025-03-04' };
        const hours = calculatePersonSprintHours(testPerson, testSprint, [], [event]);
        expect(hours).toBe(84); // 80 + 4
    });

    it('should correctly handle a global holiday', () => {
      const holiday: GlobalEvent = { id: 'h1', title: 'Holiday', type: 'holiday', durationType: 'fullday', startDate: '2025-03-11', endDate: '2025-03-11' };
      const hours = calculatePersonSprintHours(testPerson, testSprint, [holiday], []);
      expect(hours).toBe(72);
    });

    it('should prioritize personal vacation over a global partial-day event', () => {
        const vacation: CalendarEvent = { id: 'v1', title: 'Day Off', type: 'vacation', durationType: 'fullday', startDate: '2025-03-12', endDate: '2025-03-12' };
        const learning: GlobalEvent = { id: 'l1', title: 'Learning Day', type: 'learning-day', durationType: 'hours', hours: '4', startDate: '2025-03-12', endDate: '2025-03-12' };
        const hours = calculatePersonSprintHours(testPerson, testSprint, [learning], [vacation]);
        expect(hours).toBe(72); // Should only subtract 8 hours for the vacation, not 12
    });
    
    it('should respect contract start date', () => {
      const personWithLateStart = { ...testPerson, contractStartDate: '2025-03-10' };
      // Sprint is 03-03 to 03-14. Person starts on 03-10. Should only work 5 days.
      const hours = calculatePersonSprintHours(personWithLateStart, testSprint, [], []);
      expect(hours).toBe(40); // 5 * 8
    });

    it('should respect team membership end date', () => {
      const teamMember: TeamMember = { id: 'tm1', teamId: 't1', personId: 'p1', startDate: '2025-01-01', endDate: '2025-03-07' };
      // Person leaves team on Friday 03-07. Should only work 5 days of the sprint.
      const hours = calculatePersonSprintHours(testPerson, testSprint, [], [], teamMember);
      expect(hours).toBe(40); // 5 * 8
    });

    it('should handle a daily recurring global event that covers the entire sprint', () => {
        const companyShutdown: GlobalEvent = {
            id: 'shutdown', title: 'Company Shutdown', type: 'company-day', durationType: 'fullday',
            startDate: '2025-03-01', endDate: '2025-03-01',
            recurrenceRule: { frequency: 'daily', until: '2025-03-31' }
        };
        const expandedShutdown = expandRecurringEvents([companyShutdown], new Date(testSprint.startDate), new Date(testSprint.endDate));
        const hours = calculatePersonSprintHours(testPerson, testSprint, expandedShutdown, []);
        expect(hours).toBe(0);
    });
    
  });
});