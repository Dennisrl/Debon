import React, { useState, useEffect } from 'react';
import { DataProvider, useData } from './context/DataContext';
import RiskDashboard from './components/RiskDashboard';
import ROICalculator from './components/ROICalculator';
import CapacityManager from './components/CapacityManager';
import AgendaManager from './components/AgendaManager';
import TeamPlanner from './components/TeamPlanner';
import HarvestImporter from './components/HarvestImporter';
import ManagementDashboard from './components/ManagementDashboard';
import { ProLogoIcon, SunIcon, MoonIcon, LoaderIcon } from './components/icons';
import { Sidebar } from './components/Sidebar';
import ErrorBoundary from './components/ErrorBoundary';

type View = 'risk' | 'roi' | 'team-planning' | 'capacity' | 'agenda' | 'harvest' | 'management';

const AppContent: React.FC = () => {
    const { data, isLoading, error, activeProjectId, setActiveProjectId, theme, setTheme } = useData();
    const projects = data?.projects || [];

    const [activeView, setActiveView] = useState<View>('risk');
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
        return localStorage.getItem('sidebarCollapsed') === 'true';
    });

    // Effect to handle navigation state and fallbacks
    useEffect(() => {
        const isProjectView = activeView === 'risk' || activeView === 'roi';
        // If a project-specific view is active, but no project is selected, fall back to a non-project view.
        if (isProjectView && !activeProjectId && projects.length > 0) {
            setActiveProjectId(projects[0].id);
        } else if (isProjectView && projects.length === 0 && !isLoading) {
            setActiveView('team-planning');
        }
    }, [activeView, activeProjectId, projects, setActiveProjectId, isLoading]);
    
    const handleToggleSidebar = () => {
        setIsSidebarCollapsed(prev => {
            const newState = !prev;
            localStorage.setItem('sidebarCollapsed', String(newState));
            return newState;
        });
    };

    const handleToggleTheme = () => {
      setTheme(theme === 'light' ? 'dark' : 'light');
    };

    const handleNavigate = (view: View, projectId?: string) => {
        if (projectId) {
            if (activeProjectId !== projectId) {
                setActiveProjectId(projectId);
            }
            if (view !== 'risk' && view !== 'roi') {
                 setActiveView('risk');
            } else {
                 setActiveView(view);
            }
        } else {
            setActiveProjectId(null); // Clear active project for non-project views
            setActiveView(view);
        }
    };

    const activeProject = projects.find(p => p.id === activeProjectId) || null;
    
    const viewTitles: Record<View, string> = {
        'risk': 'Risico & Prognose',
        'roi': 'ROI Calculator',
        'team-planning': 'Teamplanning',
        'capacity': 'Personenbeheer',
        'agenda': 'Agenda & Afwezigheid',
        'harvest': 'Uren Importeren (Harvest)',
        'management': 'Management Dashboard'
    };
    
    const isProjectView = activeView === 'risk' || activeView === 'roi';
    const headerTitle = isProjectView && activeProject ? `${activeProject.name} / ${viewTitles[activeView]}` : viewTitles[activeView];

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex-1 flex items-center justify-center text-text-secondary">
                    <LoaderIcon className="w-8 h-8 mr-3" />
                    Data wordt geladen...
                </div>
            );
        }
        if (error) {
             return (
                <div className="flex-1 flex items-center justify-center text-error">
                    Fout bij het laden van data: {error.message}
                </div>
            );
        }

        return (
            <>
                {isProjectView && activeProject && activeView === 'risk' && <RiskDashboard key={`${activeProject.id}-risk`} project={activeProject} />}
                {isProjectView && activeProject && activeView === 'roi' && <ROICalculator key={`${activeProject.id}-roi`} project={activeProject} />}
                {isProjectView && !activeProject && (
                   <div className="container mx-auto p-8 text-center flex flex-col items-center justify-center h-full">
                       <h2 className="text-2xl font-semibold text-text-primary">Geen project geselecteerd</h2>
                       <p className="mt-2 text-text-secondary">Maak een nieuw project aan of selecteer een bestaand project in de zijbalk.</p>
                   </div>
                )}
                
                {activeView === 'team-planning' && <TeamPlanner />}
                {activeView === 'capacity' && <CapacityManager />}
                {activeView === 'agenda' && <AgendaManager />}
                {activeView === 'harvest' && <HarvestImporter />}
                {activeView === 'management' && <ManagementDashboard />}
            </>
        );
    }

    return (
        <div className={`flex h-screen bg-background text-text-primary ${theme}`}>
            <Sidebar 
                activeView={activeView} 
                onNavigate={handleNavigate} 
                isCollapsed={isSidebarCollapsed} 
                onToggleCollapse={handleToggleSidebar}
            />
            
            <div className="flex-1 flex flex-col overflow-y-auto">
                <header className="p-4 border-b border-border-default bg-surface sticky top-0 z-20">
                  <div className="container mx-auto flex items-center justify-between gap-4">
                    <div className="flex-1 flex justify-start items-center">
                       <button onClick={handleToggleTheme} aria-label="Toggle dark mode" className="ml-2 p-1 text-text-secondary hover:text-primary rounded-md">
                        {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-6 w-6" />}
                      </button>
                    </div>
                    <h1 className="flex-shrink-0 text-xl sm:text-2xl font-semibold text-text-primary truncate text-center max-w-xs sm:max-w-md">{headerTitle}</h1>
                    <div className="flex-1 flex justify-end"><ProLogoIcon className="h-7 text-text-primary" /></div>
                  </div>
                </header>
                
                <main className="flex-1 flex flex-col">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
};

const App: React.FC = () => (
    <DataProvider>
      <ErrorBoundary>
        <AppContent />
      </ErrorBoundary>
    </DataProvider>
);

export default App;