import { GoogleGenAI, Type } from "@google/genai";
import type { AggregatedProjectData } from '../components/ProjectPortfolioDashboard';
import type { TeamKPIs } from '../components/TeamPerformanceDashboard';
import type { PersonKPIs, Project, ActualHoursEntry, Person, GlobalEvent, TeamMember } from '../types';
import { calculatePersonHoursForDay, expandRecurringEvents } from './planningService';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-2.5-flash';

function sanitizeDataForPrompt(data: any[]): string {
    // Keep only essential keys and limit array length to avoid overly long prompts
    const sanitized = data.map(item => {
        const smallerItem: Record<string, any> = {};
        // Add specific logic for each data type
        if (item.project) { // AggregatedProjectData
            smallerItem.name = item.project.name;
            smallerItem.budgetRisk = item.budgetRisk?.toFixed(0) + '%';
            smallerItem.timeRisk = item.timeRisk?.toFixed(0) + '%';
            smallerItem.CPI = item.cpi?.toFixed(2);
            smallerItem.SPI = item.spi?.toFixed(2);
            smallerItem.billability = item.billablePercentage?.toFixed(0) + '%';
        } else if (item.team) { // TeamKPIs
            smallerItem.name = item.team.name;
            smallerItem.capacityUtilization = item.capacityUtilization?.toFixed(0) + '%';
            smallerItem.focusRatio = item.focusRatio?.toFixed(0) + '%';
            smallerItem.disruptionPercentage = item.disruptionPercentage?.toFixed(0) + '%';
        } else if (item.person) { // PersonKPIs
            smallerItem.name = item.person.name;
            smallerItem.billablePercentage = item.billablePercentage?.toFixed(0) + '%';
            smallerItem.totalBookedHours = item.totalBookedHours?.toFixed(0);
            smallerItem.focusRatio = item.focusRatio?.toFixed(0) + '%';
        }
        return smallerItem;
    }).slice(0, 20); // Limit to 20 items for prompt brevity

    return JSON.stringify(sanitized, null, 2);
}

async function generateAnalysis(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating analysis:", error);
        throw new Error("Er is een fout opgetreden bij het genereren van de analyse. Controleer de API-configuratie.");
    }
}

export const generatePortfolioAnalysis = (data: AggregatedProjectData[]): Promise<string> => {
    const prompt = `
Je bent een ervaren portfolio manager. Analyseer de volgende projectdata en geef een bondige samenvatting en actiegericht advies.
Beperk je tot maximaal 4 zinnen. Focus op de grootste risico's en kansen in de portfolio.
Antwoord in het Nederlands in Markdown-formaat.

**Data:**
${sanitizeDataForPrompt(data)}
`;
    return generateAnalysis(prompt);
};

export const generateTeamPerformanceAnalysis = (data: TeamKPIs[]): Promise<string> => {
    const prompt = `
Je bent een ervaren agile coach. Analyseer de volgende team performance data en geef een bondige samenvatting en actiegericht advies.
Beperk je tot maximaal 4 zinnen. Focus op opvallende verschillen tussen teams of algehele trends.
Antwoord in het Nederlands in Markdown-formaat.

**Data:**
${sanitizeDataForPrompt(data)}
`;
    return generateAnalysis(prompt);
};

export const generatePersonPerformanceAnalysis = (data: PersonKPIs[]): Promise<string> => {
    const prompt = `
Je bent een ervaren resource manager. Analyseer de volgende data over individuele prestaties en geef een bondige, algemene samenvatting.
Noem geen individuele namen. Focus op algemene trends in factureerbaarheid, over/onderbezetting, en focus. Beperk je tot maximaal 4 zinnen.
Antwoord in het Nederlands in Markdown-formaat.

**Data:**
${sanitizeDataForPrompt(data)}
`;
    return generateAnalysis(prompt);
};


export const generateImportAnalysis = async (
    data: ActualHoursEntry[],
    persons: Person[],
    globalEvents: GlobalEvent[],
    teamMembers: TeamMember[]
): Promise<any> => {
    const teamMemberIds = new Set(teamMembers.map(tm => tm.personId));

    // 1. Group imported hours by personId and date, only for team members
    const bookedHoursMap = new Map<string, Map<string, number>>();
    data.forEach(entry => {
        if (!entry.personId || !teamMemberIds.has(entry.personId)) return; // Exclude non-team members (POs)
        if (!bookedHoursMap.has(entry.personId)) {
            bookedHoursMap.set(entry.personId, new Map());
        }
        const personDateMap = bookedHoursMap.get(entry.personId)!;
        const currentHours = personDateMap.get(entry.date) || 0;
        personDateMap.set(entry.date, currentHours + entry.hours);
    });

    const discrepancies: { personName: string; date: Date; capacityHours: number; bookedHours: number; difference: number; }[] = [];
    const personMap = new Map(persons.map(p => [p.id, p]));

    const datesInData = [...new Set(data.map(d => d.date))].sort();
    if (datesInData.length === 0) return { introduction: "Geen uren gevonden voor teamleden om te analyseren.", discrepancies: [] };
    
    const viewStart = new Date(datesInData[0]);
    const viewEnd = new Date(datesInData[datesInData.length - 1]);
    const expandedGlobalEvents = expandRecurringEvents(globalEvents, viewStart, viewEnd);

    // 2. Iterate through each person who booked hours and check their days
    for (const [personId, dateMap] of bookedHoursMap.entries()) {
        const person = personMap.get(personId);
        if (!person) continue;

        const expandedPersonalEvents = expandRecurringEvents(person.events, viewStart, viewEnd);

        for (const [dateStr, bookedHours] of dateMap.entries()) {
            const date = new Date(dateStr + 'T00:00:00');
            const dayOfWeek = date.getDay();
            if (dayOfWeek === 6 || dayOfWeek === 0) continue;

            const capacityHours = calculatePersonHoursForDay(person, date, expandedGlobalEvents, expandedPersonalEvents);
            const difference = capacityHours - bookedHours;

            if (difference > 2) {
                discrepancies.push({ personName: person.name, date, capacityHours, bookedHours, difference });
            }
        }
    }
    
    // 3. Group discrepancies by personName and then by month
    const groupedByPersonAndMonth = discrepancies.reduce((acc, current) => {
        const { personName, date, capacityHours, bookedHours, difference } = current;
        if (!acc[personName]) {
            acc[personName] = { personName, months: {} };
        }
        const monthYearKey = date.toLocaleDateString('nl-NL', { month: 'long', year: 'numeric' });
        if (!acc[personName].months[monthYearKey]) {
            acc[personName].months[monthYearKey] = [];
        }
        acc[personName].months[monthYearKey].push({
            date: date.toLocaleDateString('nl-NL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
            capacityHours: capacityHours.toFixed(1),
            bookedHours: bookedHours.toFixed(1),
            difference: difference.toFixed(1)
        });
        return acc;
    }, {} as Record<string, { personName: string; months: Record<string, any[]> }>);

    // Sort entries within each month by date
    Object.values(groupedByPersonAndMonth).forEach(personGroup => {
        Object.values(personGroup.months).forEach(monthEntries => {
            monthEntries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        });
    });

    const finalGroupedData = Object.values(groupedByPersonAndMonth).sort((a, b) => a.personName.localeCompare(b.personName));

    // 4. If no discrepancies, return a happy message
    if (finalGroupedData.length === 0) {
        return {
            introduction: "Geen significante afwijkingen gevonden tussen de capaciteit en de geboekte uren van de teamleden. Goed werk!",
            discrepancies: []
        };
    }

    const prompt = `
Je bent een HR-assistent. Je hebt data geanalyseerd en afwijkingen gevonden in urenregistraties.
Schrijf een korte, vriendelijke, en algemene inleidende zin voor het rapport dat deze afwijkingen toont. Maximaal 1 zin. Antwoord alleen met de zin.
Voorbeeld: "Hieronder volgt een overzicht van dagen waarop de geboekte uren significant afwijken van de capaciteit."
`;

    try {
        const response = await ai.models.generateContent({ model, contents: prompt });
        return {
            introduction: response.text.trim(),
            discrepancies: finalGroupedData
        };
    } catch (error) {
        console.error("Error generating analysis intro:", error);
        return {
            introduction: "Analyse van afwijkingen in urenregistratie:",
            discrepancies: finalGroupedData
        };
    }
};


export const parseScenarioQuery = async (query: string, projects: Project[]): Promise<any> => {
    const projectContext = projects.map(p => ({
        name: p.name,
        avgHoursPerPoint: p.avgHoursPerPoint
    }));

    const schema = {
        type: Type.OBJECT,
        properties: {
            project_name: {
                type: Type.STRING,
                description: "De exacte naam van het project uit de context.",
            },
            velocity_change_points: {
                type: Type.NUMBER,
                description: "De verandering in velocity in punten per sprint. Dit kan positief of negatief zijn."
            },
            duration_sprints: {
                type: Type.NUMBER,
                description: "Het aantal sprints waarop deze verandering van toepassing is."
            }
        },
        required: ["project_name", "velocity_change_points", "duration_sprints"]
    };

    const prompt = `
Je bent een intelligente assistent voor een projectplanningstool. De gebruiker wil een "what-if"-scenario uitvoeren.
Parse de vraag van de gebruiker. Identificeer het project, de verandering in velocity (in story points per sprint) en de duur (in aantal sprints).
De gebruiker is Nederlands. Als de vraag een verandering in uren bevat, MOET je dit omrekenen naar punten met behulp van de 'avgHoursPerPoint' van het betreffende project uit de context.
Je antwoord moet een JSON-object zijn dat voldoet aan het opgegeven schema.

**Context (beschikbare projecten):**
${JSON.stringify(projectContext, null, 2)}

**Gebruikersvraag:**
"${query}"
`;
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            }
        });

        // The response text is a JSON string, parse it.
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);

    } catch (error) {
        console.error("Error parsing scenario query:", error);
        throw new Error("De scenario-vraag kon niet worden verwerkt. Probeer de vraag anders te formuleren.");
    }
};