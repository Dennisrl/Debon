

import type { SimulationParams, SimulationResult, ScenarioForecast, TimeSeriesDataPoint } from '../types';

export const runScenarioProjection = (params: SimulationParams): Promise<SimulationResult> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const {
        totalPoints,
        pointsPerSprint,
        hoursPerSprint,
        hourlyRate = 0,
        optimisticDeviation,
        pessimisticDeviation,
        plannedVelocity,
        avgHoursPerPoint: plannedAvgHoursPerPoint,
      } = params;
      
      const usedDeviations = { optimistic: optimisticDeviation, pessimistic: pessimisticDeviation };

      if (!totalPoints || totalPoints <= 0) {
        return resolve({
          timeSeries: [],
          finalTime: { optimistic: 0, baseline: 0, pessimistic: 0 },
          finalCost: { optimistic: 0, baseline: 0, pessimistic: 0 },
          historicalDataPoints: 0,
          usedDeviations,
        });
      }

      // --- 1. Calculate Historical Performance ---
      const totalHistoricalPoints = pointsPerSprint.reduce((a, b) => a + b, 0);
      const totalHistoricalHours = hoursPerSprint.reduce((a, b) => a + b, 0);
      const historicalVelocity = pointsPerSprint.length > 0 ? totalHistoricalPoints / pointsPerSprint.length : 0;
      const historicalAvgHoursPerPoint = totalHistoricalPoints > 0 ? totalHistoricalHours / totalHistoricalPoints : 0;
      const remainingPoints = totalPoints - totalHistoricalPoints;

      // --- 2. Define Future Scenario Parameters (prioritizing historical data) ---
      // Parameters for TIME projection (based on velocity uncertainty)
      const futureBaselineVelocity = historicalVelocity > 0 ? historicalVelocity : plannedVelocity;
      const optimisticVelocity = futureBaselineVelocity * (1 + (optimisticDeviation / 100));
      const pessimisticVelocity = Math.max(0.1, futureBaselineVelocity * (1 - (pessimisticDeviation / 100)));

      // Parameters for COST projection (based on hours/point uncertainty)
      const futureBaselineHoursPerPoint = historicalAvgHoursPerPoint > 0 ? historicalAvgHoursPerPoint : plannedAvgHoursPerPoint;
      const optimisticHoursPerPoint = futureBaselineHoursPerPoint / (1 + (optimisticDeviation / 100));
      const pessimisticHoursPerPoint = futureBaselineHoursPerPoint / (1 - (pessimisticDeviation / 100)); // Simpler, assume deviation < 100

      if (futureBaselineVelocity <= 0) {
         return resolve({
          timeSeries: [],
          finalTime: { optimistic: 0, baseline: 0, pessimistic: 0 },
          finalCost: { optimistic: 0, baseline: 0, pessimistic: 0 },
          historicalDataPoints: pointsPerSprint.length,
          usedDeviations,
        });
      }
      
      // --- 3. Calculate Final Outcomes (Historical + Future) ---
      const historicalSprints = pointsPerSprint.length;
      const totalHistoricalCost = totalHistoricalHours * hourlyRate;

      // Final Time
      const futureSprintsBaseline = remainingPoints > 0 ? remainingPoints / futureBaselineVelocity : 0;
      const futureSprintsOptimistic = remainingPoints > 0 ? remainingPoints / optimisticVelocity : 0;
      const futureSprintsPessimistic = remainingPoints > 0 ? remainingPoints / pessimisticVelocity : 0;

      const finalTime: ScenarioForecast = {
        baseline: historicalSprints + futureSprintsBaseline,
        optimistic: historicalSprints + futureSprintsOptimistic,
        pessimistic: historicalSprints + futureSprintsPessimistic,
      };

      // Final Cost
      const futureCostBaseline = remainingPoints * futureBaselineHoursPerPoint * hourlyRate;
      const futureCostOptimistic = remainingPoints * optimisticHoursPerPoint * hourlyRate;
      const futureCostPessimistic = remainingPoints * pessimisticHoursPerPoint * hourlyRate;

      const finalCost: ScenarioForecast = {
        baseline: totalHistoricalCost + futureCostBaseline,
        optimistic: totalHistoricalCost + futureCostOptimistic,
        pessimistic: totalHistoricalCost + futureCostPessimistic,
      };

      // --- 4. Generate Time Series for the Chart ---
      const maxSprints = Math.ceil(finalTime.pessimistic * 1.1) || 50;
      const timeSeries: TimeSeriesDataPoint[] = [];

      // Add sprint 0
      timeSeries.push({
          sprint: 0,
          time: { optimistic: 0, baseline: 0, pessimistic: 0 },
          cost: { optimistic: 0, baseline: 0, pessimistic: 0 },
          actualPoints: 0,
          actualCost: 0,
      });

      let cumulativeActualPoints = 0;
      let cumulativeActualCost = 0;

      for (let i = 0; i < historicalSprints; i++) {
          const s = i + 1;
          cumulativeActualPoints += pointsPerSprint[i];
          cumulativeActualCost += hoursPerSprint[i] * hourlyRate;
          
          timeSeries.push({
              sprint: s,
              actualPoints: cumulativeActualPoints,
              actualCost: cumulativeActualCost,
              time: { baseline: cumulativeActualPoints, optimistic: cumulativeActualPoints, pessimistic: cumulativeActualPoints },
              cost: { baseline: cumulativeActualCost, optimistic: cumulativeActualCost, pessimistic: cumulativeActualCost },
          });
      }

      const lastHistoricalDataPoint = timeSeries[historicalSprints] || timeSeries[0];
      const lastHistoricalPoints = lastHistoricalDataPoint.actualPoints!;
      const lastHistoricalCost = lastHistoricalDataPoint.actualCost!;


      for (let s = historicalSprints + 1; s <= maxSprints; s++) {
          const sprintsAfterHistory = s - historicalSprints;

          // Project Time (using velocity uncertainty)
          const baselinePoints = Math.min(lastHistoricalPoints + (sprintsAfterHistory * futureBaselineVelocity), totalPoints);
          const optimisticPoints = Math.min(lastHistoricalPoints + (sprintsAfterHistory * optimisticVelocity), totalPoints);
          const pessimisticPoints = Math.min(lastHistoricalPoints + (sprintsAfterHistory * pessimisticVelocity), totalPoints);

          // Project Cost (using hours/point uncertainty, anchored to baseline velocity)
          const pointsAddedSinceHistory = sprintsAfterHistory * futureBaselineVelocity;

          const baselineCost = lastHistoricalCost + (pointsAddedSinceHistory * futureBaselineHoursPerPoint * hourlyRate);
          const optimisticCost = lastHistoricalCost + (pointsAddedSinceHistory * optimisticHoursPerPoint * hourlyRate);
          const pessimisticCost = lastHistoricalCost + (pointsAddedSinceHistory * pessimisticHoursPerPoint * hourlyRate);

          timeSeries.push({
              sprint: s,
              time: { baseline: baselinePoints, optimistic: optimisticPoints, pessimistic: pessimisticPoints },
              // Use Math.min to cap the cost at the final calculated cost.
              cost: {
                  baseline: Math.min(baselineCost, finalCost.baseline),
                  optimistic: Math.min(optimisticCost, finalCost.optimistic),
                  pessimistic: Math.min(pessimisticCost, finalCost.pessimistic),
              },
          });
      }

      resolve({ 
        timeSeries: timeSeries.sort((a,b) => a.sprint - b.sprint), 
        finalTime, 
        finalCost, 
        historicalDataPoints: pointsPerSprint.length, 
        usedDeviations,
        historicalVelocity: historicalVelocity > 0 ? historicalVelocity : undefined,
        historicalAvgHoursPerPoint: historicalAvgHoursPerPoint > 0 ? historicalAvgHoursPerPoint : undefined,
        remainingSprints: futureSprintsBaseline,
      });
    }, 1000);
  });
};