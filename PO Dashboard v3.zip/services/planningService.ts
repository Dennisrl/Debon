import type { Person, GlobalEvent, SprintPlan, TeamMember, WorkPattern, Team, SprintCapacityResult, RecurrenceRule, CalendarEvent, WorkPatternEntry } from '../types';

export const getWeekNumber = (d: Date): number => {
    const date = new Date(d.valueOf());
    date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return weekNo;
};

export const getDayDiff = (d1: Date, d2: Date) => {
    const MS_PER_DAY = 1000 * 60 * 60 * 24;
    const utc1 = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
    const utc2 = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate());
    return Math.floor((utc2 - utc1) / MS_PER_DAY);
};

export const toISOLocalDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

const parseUTCDate = (dateString: string): Date => {
    return new Date(`${dateString}T00:00:00.000Z`);
}

const toISOUTCDateString = (date: Date): string => {
    return date.toISOString().split('T')[0];
}


export const expandRecurringEvents = <T extends { id: string; startDate: string; endDate: string; recurrenceRule?: RecurrenceRule; type: string; }>(
    events: T[] | undefined,
    viewStart: Date, // local date
    viewEnd: Date    // local date
): (T & { originalId: string })[] => {
    const expanded: (T & { originalId: string })[] = [];
    if (!events) return expanded;

    const viewStartUTC = new Date(Date.UTC(viewStart.getFullYear(), viewStart.getMonth(), viewStart.getDate()));
    const viewEndUTC = new Date(Date.UTC(viewEnd.getFullYear(), viewEnd.getMonth(), viewEnd.getDate()));

    for (const event of events) {
        if (event.recurrenceRule) {
            const { recurrenceRule, startDate, endDate } = event;
            let currentStartDateUTC = parseUTCDate(startDate);
            const originalEndDateUTC = parseUTCDate(endDate);
            const recurrenceUntilUTC = recurrenceRule.until ? parseUTCDate(recurrenceRule.until) : viewEndUTC;
            
            const eventDurationDays = Math.round((originalEndDateUTC.getTime() - currentStartDateUTC.getTime()) / (1000 * 60 * 60 * 24));
            const interval = recurrenceRule.interval || 1;

            while (currentStartDateUTC.getTime() <= recurrenceUntilUTC.getTime()) {
                const currentEndDateUTC = new Date(currentStartDateUTC.getTime());
                currentEndDateUTC.setUTCDate(currentEndDateUTC.getUTCDate() + eventDurationDays);
                
                if (currentStartDateUTC.getTime() <= viewEndUTC.getTime() && currentEndDateUTC.getTime() >= viewStartUTC.getTime()) {
                     expanded.push({
                        ...event,
                        id: `${event.id}-${toISOUTCDateString(currentStartDateUTC)}`,
                        originalId: event.id,
                        startDate: toISOUTCDateString(currentStartDateUTC),
                        endDate: toISOUTCDateString(currentEndDateUTC),
                        recurrenceRule: undefined,
                    });
                }
                
                if (currentStartDateUTC.getTime() > viewEndUTC.getTime()) break;

                switch (recurrenceRule.frequency) {
                    case 'daily': currentStartDateUTC.setUTCDate(currentStartDateUTC.getUTCDate() + interval); break;
                    case 'weekly': currentStartDateUTC.setUTCDate(currentStartDateUTC.getUTCDate() + (7 * interval)); break;
                    case 'monthly': currentStartDateUTC.setUTCMonth(currentStartDateUTC.getUTCMonth() + interval); break;
                    case 'yearly': currentStartDateUTC.setUTCFullYear(currentStartDateUTC.getUTCFullYear() + interval); break;
                }
            }
        } else {
            const eventStartUTC = parseUTCDate(event.startDate);
            const eventEndUTC = parseUTCDate(event.endDate);
            if (eventEndUTC.getTime() >= viewStartUTC.getTime() && eventStartUTC.getTime() <= viewEndUTC.getTime()) {
                expanded.push({ ...event, originalId: event.id });
            }
        }
    }
    return expanded;
};


export const calculatePersonHoursForDay = (
    person: Person,
    date: Date, // local date for the check
    allExpandedGlobalEvents: (GlobalEvent & { originalId: string })[],
    allExpandedPersonalEvents: (CalendarEvent & { originalId: string })[]
): number => {
    const dayStr = toISOLocalDate(date);

    // 1. Check for contract validity
    if (person.contractStartDate && dayStr < person.contractStartDate) return 0;
    if (person.contractEndDate && dayStr > person.contractEndDate) return 0;

    // 2. Find all events on this day
    const eventsOnThisDay = [
        ...allExpandedPersonalEvents.filter(e => dayStr >= e.startDate && dayStr <= e.endDate),
        ...allExpandedGlobalEvents.filter(e => dayStr >= e.startDate && dayStr <= e.endDate)
    ];
    
    // 3. Check for full day off
    const isFullDayOff = eventsOnThisDay.some(e => e.durationType === 'fullday' || e.durationType === 'multiday');
    if (isFullDayOff) return 0;

    // 4. Get base scheduled hours
    const applicablePatternEntry = person.workPatterns
        .filter(p => p.startDate <= dayStr)
        .sort((a, b) => b.startDate.localeCompare(a.startDate))[0];

    if (!applicablePatternEntry) return 0;
    const workPattern = applicablePatternEntry.pattern;
    
    const dayOfWeekIndex = (date.getDay() + 6) % 7; // Monday = 0, Sunday = 6
    const dayKey = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'][dayOfWeekIndex] as keyof WorkPattern['standardHours'];

    let scheduledHours = 0;
    if (workPattern) {
        if (workPattern.type === 'even-odd' && workPattern.evenWeekHours && workPattern.oddWeekHours) {
            scheduledHours = parseFloat((getWeekNumber(date) % 2 === 0 ? workPattern.evenWeekHours : workPattern.oddWeekHours)?.[dayKey] || '0');
        } else {
            scheduledHours = parseFloat(workPattern.standardHours?.[dayKey] || '0');
        }
    }

    if (scheduledHours <= 0) return 0;
    
    // 5. Calculate hour adjustments for this day
    let hourAdjustment = 0;
    const hourEventsOnThisDay = eventsOnThisDay.filter(e => e.durationType === 'hours');

    for (const event of hourEventsOnThisDay) {
        const hoursVal = parseFloat(event.hours || '0');
        if (event.type === 'extra') {
            hourAdjustment += hoursVal;
        } else {
            hourAdjustment -= hoursVal;
        }
    }
    
    // 6. Calculate final hours for the day
    return Math.max(0, scheduledHours + hourAdjustment);
};


// Calculates the total available hours for one person across a whole sprint, considering all events.
export const calculatePersonSprintHours = (
    person: Person,
    sprint: SprintPlan,
    allExpandedGlobalEvents: GlobalEvent[],
    allExpandedPersonalEvents: CalendarEvent[],
    teamMember?: TeamMember
): number => {
    let totalHours = 0;
    const sprintStart = new Date(sprint.startDate + 'T00:00:00');
    const sprintEnd = new Date(sprint.endDate + 'T00:00:00');

    const memberStart = teamMember?.startDate ? new Date(teamMember.startDate + 'T00:00:00') : null;
    const memberEnd = teamMember?.endDate ? new Date(teamMember.endDate + 'T00:00:00') : null;

    for (let d = new Date(sprintStart); d <= sprintEnd; d.setDate(d.getDate() + 1)) {
        // Check for team membership validity for this specific day
        if ((memberStart && d < memberStart) || (memberEnd && d > memberEnd)) continue;
        
        const dayHours = calculatePersonHoursForDay(
            person, 
            d, 
            allExpandedGlobalEvents as (GlobalEvent & { originalId: string; })[], 
            allExpandedPersonalEvents as (CalendarEvent & { originalId: string; })[]
        );
        totalHours += dayHours;
    }
    return totalHours;
};


// Calculates the capacity for a full sprint
export const calculateSprintCapacity = (
    sprint: SprintPlan,
    team: Team,
    teamMembers: TeamMember[],
    allPersons: Person[],
    allExpandedGlobalEvents: GlobalEvent[],
    allExpandedPersonEvents: Map<string, CalendarEvent[]>
): SprintCapacityResult => {
    
    const personHours: { personId: string, hours: number }[] = [];
    let totalRawHours = 0;

    const sprintMembers = teamMembers.filter(m => m.teamId === team.id);

    for (const member of sprintMembers) {
        const person = allPersons.find(p => p.id === member.personId);
        if (person) {
            const personEvents = allExpandedPersonEvents.get(person.id) || [];
            const hours = calculatePersonSprintHours(person, sprint, allExpandedGlobalEvents, personEvents, member);
            personHours.push({ personId: person.id, hours });
            totalRawHours += hours;
        }
    }
    
    const adhocPct = parseFloat(sprint.adhocPctOverride ?? team.defaultAdhocPct) / 100;
    const scrumPct = parseFloat(sprint.scrumPctOverride ?? team.defaultScrumPct) / 100;
    const adhocHours = totalRawHours * adhocPct;
    const scrumHours = totalRawHours * scrumPct;
    const totalAvailableHours = totalRawHours - adhocHours - scrumHours;

    return { sprintId: sprint.id, totalRawHours, adhocHours, scrumHours, totalAvailableHours, personHours };
};

export const generateSprintsForYear = (
    team: Team,
    year: number,
    allSprints: SprintPlan[],
    options?: { fromDate?: Date, fromSprintNumber?: number }
): SprintPlan[] => {
    const newSprints: SprintPlan[] = [];
    let nextStartDate: Date;
    let sprintCounter: number;

    if (options?.fromDate) {
        nextStartDate = new Date(options.fromDate);
        sprintCounter = options.fromSprintNumber || 1;
    } else {
        const teamSprints = allSprints.filter(s => s.teamId === team.id);
        const previousYearSprints = teamSprints
            .filter(s => new Date(s.startDate + 'T00:00:00').getFullYear() === year - 1)
            .sort((a, b) => new Date(b.endDate + 'T00:00:00').getTime() - new Date(a.endDate + 'T00:00:00').getTime());

        nextStartDate = new Date(year, 0, 1);
        if (previousYearSprints.length > 0) {
            nextStartDate = new Date(previousYearSprints[0].endDate + 'T00:00:00');
            nextStartDate.setDate(nextStartDate.getDate() + 1);
        }
        sprintCounter = 1;
    }

    const dayOfWeek = nextStartDate.getDay();
    if (dayOfWeek !== 1) { // 1 = Monday
        const diffToMonday = dayOfWeek === 0 ? 1 : (8 - dayOfWeek);
        nextStartDate.setDate(nextStartDate.getDate() + diffToMonday);
    }

    const sprintLengthWeeks = parseInt(team.defaultSprintLengthWeeks || '2', 10);
    const sprintDurationDays = (sprintLengthWeeks * 7);

    while (nextStartDate.getFullYear() <= year) {
        const sprintEndDate = new Date(nextStartDate);
        sprintEndDate.setDate(sprintEndDate.getDate() + sprintDurationDays - 1);

        if (sprintEndDate.getFullYear() > year && options?.fromDate) break; // Don't bleed into next year when regenerating
        if (sprintEndDate.getFullYear() > year && !options?.fromDate) break;

        newSprints.push({
            id: crypto.randomUUID(), teamId: team.id, name: `Sprint ${sprintCounter}`,
            startDate: nextStartDate.toISOString().split('T')[0],
            endDate: sprintEndDate.toISOString().split('T')[0],
        });

        sprintCounter++;
        nextStartDate.setDate(nextStartDate.getDate() + sprintDurationDays);
    }

    return newSprints;
};


export const recalculateSprintsAfter = (
  changedSprint: SprintPlan,
  allTeamSprints: SprintPlan[]
): SprintPlan[] => {
  const subsequentSprints = allTeamSprints
    .filter(s => new Date(s.startDate) > new Date(changedSprint.startDate))
    .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());

  if (subsequentSprints.length === 0) {
    return [];
  }

  const newSprints: SprintPlan[] = [];
  let lastEndDate = new Date(changedSprint.endDate + 'T00:00:00');

  for (const sprint of subsequentSprints) {
    const sprintDuration = getDayDiff(new Date(sprint.startDate), new Date(sprint.endDate));
    
    const newStartDate = new Date(lastEndDate);
    newStartDate.setDate(newStartDate.getDate() + 1);
    
    // Adjust to next Monday if the new start date is a weekend
    const dayOfWeek = newStartDate.getDay();
    if (dayOfWeek === 6) { // Saturday
        newStartDate.setDate(newStartDate.getDate() + 2);
    } else if (dayOfWeek === 0) { // Sunday
        newStartDate.setDate(newStartDate.getDate() + 1);
    }
    
    const newEndDate = new Date(newStartDate);
    newEndDate.setDate(newEndDate.getDate() + sprintDuration);

    newSprints.push({
      ...sprint,
      startDate: newStartDate.toISOString().split('T')[0],
      endDate: newEndDate.toISOString().split('T')[0],
    });

    lastEndDate = newEndDate;
  }

  return newSprints;
};