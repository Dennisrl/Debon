export type CostSavingItem = {
  id: string;
  description: string;
} & (
  | {
      type: 'time';
      timePerAction: string;
      timeUnit: 'minutes' | 'hours';
      actionsPerWeek: string;
      frequencyUnit: 'week' | 'month';
      hourlyRate: string;
    }
  | {
      type: 'fixed';
      amount: string;
      frequency: 'one-time' | 'monthly' | 'yearly';
    }
);

export interface RevenueItem {
  id: string;
  description: string;
  amount: string;
  count: string;
  frequency: 'one-time' | 'monthly' | 'yearly';
}

export interface ROI {
    revenues: RevenueItem[];
    costSavings: CostSavingItem[];
}

export interface WorkPattern {
  type: 'standard' | 'even-odd';
  standardHours: { mon: string; tue: string; wed: string; thu: string; fri: string; sat: string; sun: string; };
  evenWeekHours?: { mon: string; tue: string; wed: string; thu: string; fri: string; sat: string;sun: string; };
  oddWeekHours?: { mon: string; tue: string; wed: string; thu: string; fri: string; sat: string;sun: string; };
}

export interface WorkPatternEntry {
    id: string;
    startDate: string; // YYYY-MM-DD
    pattern: WorkPattern;
}

export interface RecurrenceRule {
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  interval?: number;
  until?: string; // YYYY-MM-DD - Optional for infinite recurrence
}

export type CalendarEventType = 'vacation' | 'sick' | 'extra' | 'other';

export interface CalendarEvent {
  id: string;
  originalId?: string; // To trace back an expanded instance to its source
  title: string;
  type: CalendarEventType;
  durationType: 'hours' | 'fullday' | 'multiday';
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD. For 'hours'/'fullday', this will equal startDate.
  hours?: string;    // Only if durationType is 'hours'
  recurrenceRule?: RecurrenceRule;
}

export type GlobalEventType = 'holiday' | 'company-day' | 'learning-day' | 'other';

export interface GlobalEvent {
  id: string;
  originalId?: string; // To trace back an expanded instance to its source
  title: string;
  type: GlobalEventType;
  durationType: 'hours' | 'fullday' | 'multiday';
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD. For 'hours'/'fullday', this will equal startDate.
  hours?: string;    // Only if durationType is 'hours'
  recurrenceRule?: RecurrenceRule;
}

export interface Person {
  id: string;
  name: string;
  contractStartDate: string;
  contractEndDate:string;
  workPatterns: WorkPatternEntry[];
  events?: CalendarEvent[];
}

export interface Team {
  id:string;
  name: string;
  defaultAdhocPct: string; // Stored as string for input compatibility
  defaultScrumPct: string;
  defaultSprintLengthWeeks?: string;
}

export interface TeamMember {
  id: string;
  teamId: string;
  personId: string;
  startDate: string; // YYYY-MM-DD
  endDate?: string;  // YYYY-MM-DD, optional for ongoing membership
}

export interface ProjectAssignment {
  id: string;
  teamId: string;
  projectId: string; // Can be empty for a new, unselected assignment row
  startDate: string; // YYYY-MM-DD
  endDate?: string;  // YYYY-MM-DD, optional for ongoing assignment
}

export interface SprintPlan {
  id: string;
  teamId: string;
  name: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  adhocPctOverride?: string;
  scrumPctOverride?: string;
}

export interface ProjectAllocation {
  id: string;
  sprintId: string;
  projectId: string;
  plannedHours: string;
}

export interface Project {
  id: string;
  name: string;
  color: string;
  totalPoints: string;
  avgHoursPerPoint: string;
  velocityPerSprint: string;
  totalBudget: string;
  budgetHours: string;
  hourlyRate: string;
  rangePercentage: string;
  sprints: SprintDetails[];
  roi?: ROI;
  isHidden?: boolean;
}

export interface SprintDetails {
  id: string;
  sprintNumber: number;
  actualPoints: string;
  actualHours: string;
  isAutomated: boolean;
}

export interface ScenarioForecast {
    optimistic: number;
    baseline: number;
    pessimistic: number;
}

export interface TimeSeriesDataPoint {
    sprint: number;
    time: ScenarioForecast;
    cost: ScenarioForecast;
    actualPoints?: number;
    actualCost?: number;
}

export interface SimulationResult {
  timeSeries: TimeSeriesDataPoint[];
  finalTime: ScenarioForecast;
  finalCost: ScenarioForecast;
  historicalDataPoints: number;
  usedDeviations: {
    optimistic: number;
    pessimistic: number;
  };
  historicalVelocity?: number;
  historicalAvgHoursPerPoint?: number;
  remainingSprints?: number;
}

export interface SimulationParams {
  totalPoints: number;
  pointsPerSprint: number[];
  hoursPerSprint: number[];
  plannedVelocity: number;
  avgHoursPerPoint: number;
  totalBudget?: number;
  hourlyRate?: number;
  optimisticDeviation: number; // e.g., 20 for 20% faster
  pessimisticDeviation: number; // e.g., 20 for 20% slower
}

// Calculated types for TeamPlanner
export interface SprintCapacityResult {
  sprintId: string;
  totalRawHours: number;
  adhocHours: number;
  scrumHours: number;
  totalAvailableHours: number;
  personHours: { personId: string, hours: number }[];
}

// Types for Harvest/XLSX Integration
export interface ActualHoursEntry {
  id: string;
  date: string; // YYYY-MM-DD
  personId?: string; // Optional: Links to a Person if they exist in the system
  personName: string; // Required: The name as it appears in the import
  projectId?: string;
  hours: number;
  client?: string;
  projectName?: string;
  projectCode?: string;
  task?: string;
  notes?: string;
  billable: boolean;
  billableRate?: number;
  billableAmount?: number;
  invoiced?: boolean;
  roles?: string;
  isEmployee?: boolean;
  costRate?: number;
  costAmount?: number;
  currency?: string;
  externalReferenceUrl?: string;
}

// Types for Management Dashboards
export interface PersonKPIs {
    person: Person;
    totalBookedHours: number;
    billablePercentage: number;
    focusRatio: number; // project vs non-project
    topProjects: { name: string; hours: number }[];
    leaveDays: number;
}