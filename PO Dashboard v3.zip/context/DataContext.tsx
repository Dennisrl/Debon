import React, { createContext, useContext, useState, useMemo, useEffect } from 'react';
import useSWR from 'swr';
import type { Project, Person, GlobalEvent, Team, TeamMember, SprintPlan, ProjectAllocation, ActualHoursEntry, ProjectAssignment } from '../types';
import { recalculateSprintsAfter } from '../services/planningService';

// The fetcher function for SWR. It assumes a REST API that returns JSON.
const fetcher = (url: string) => fetch(url).then(res => {
    if (!res.ok) {
        throw new Error('An error occurred while fetching the data.');
    }
    return res.json();
});

// Helper for making API mutation calls (POST, PUT, DELETE)
async function sendRequest(url: string, { arg }: { arg: any }, method: 'POST' | 'PUT' | 'DELETE') {
    const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: method !== 'DELETE' ? JSON.stringify(arg) : null,
    });
    if (!response.ok) {
        const errorInfo = await response.json();
        throw new Error(errorInfo.message || 'An API error occurred');
    }
    return method !== 'DELETE' ? response.json() : null;
}

// --- App State and API types ---
export interface AppData {
    projects: Project[];
    persons: Person[];
    globalEvents: GlobalEvent[];
    teams: Team[];
    teamMembers: TeamMember[];
    projectAssignments: ProjectAssignment[];
    sprintPlans: SprintPlan[];
    projectAllocations: ProjectAllocation[];
    actualHours: ActualHoursEntry[];
}

interface DataContextType {
    data: AppData | undefined;
    isLoading: boolean;
    error: any;
    // --- MUTATORS ---
    addProject: (newProjectData: Partial<Project>) => Promise<Project | undefined>;
    updateProject: (updatedProject: Partial<Project> & { id: string }) => Promise<void>;
    deleteProject: (projectId: string) => Promise<void>;
    updatePerson: (updatedPerson: Person) => Promise<void>;
    addPerson: (newPerson: Person) => Promise<Person | undefined>;
    deletePerson: (personId: string) => Promise<void>;
    setGlobalEvents: (events: GlobalEvent[]) => Promise<void>;
    deleteGlobalEvent: (eventId: string) => Promise<void>;
    deletePersonalEvent: (payload: { personId: string; eventId: string }) => Promise<void>;
    setAllAllocations: (allocations: ProjectAllocation[]) => Promise<void>;
    setActualHours: (hours: ActualHoursEntry[]) => Promise<void>;
    addTeam: (newTeamData: Partial<Team>) => Promise<Team | undefined>;
    updateTeam: (updatedTeam: Partial<Team> & { id: string }) => Promise<void>;
    deleteTeam: (teamId: string) => Promise<void>;
    setTeamMembers: (teamMembers: TeamMember[]) => Promise<void>;
    setSprintPlans: (sprintPlans: SprintPlan[]) => Promise<void>;
    updateSprintPlan: (updatedSprintPlan: Partial<SprintPlan> & { id: string }) => Promise<void>;
    updateSprintEndDateAndCascade: (payload: { sprintId: string; newEndDate: string; teamId: string; }) => Promise<void>;
    addProjectAssignment: (newAssignment: ProjectAssignment) => Promise<void>;
    updateProjectAssignment: (updatedAssignment: ProjectAssignment) => Promise<void>;
    deleteProjectAssignment: (assignmentId: string) => Promise<void>;
    
    // --- LOCAL UI STATE ---
    theme: 'light' | 'dark';
    setTheme: (theme: 'light' | 'dark') => void;
    activeProjectId: string | null;
    setActiveProjectId: (id: string | null) => void;
}

// --- Context Definition ---
const DataContext = createContext<DataContextType | undefined>(undefined);

// --- Provider Component ---
export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { data, error, isLoading, mutate } = useSWR<AppData>('/api/data', fetcher);
    
    const [theme, setThemeState] = useState<'light' | 'dark'>('light');
    const [activeProjectId, setActiveProjectId] = useState<string | null>(null);

    useEffect(() => {
        const savedTheme = localStorage.getItem('po-suite-theme') as 'light' | 'dark' | null;
        if (savedTheme) {
            setThemeState(savedTheme);
            document.documentElement.className = savedTheme;
        }
    }, []);

    const setTheme = (newTheme: 'light' | 'dark') => {
        setThemeState(newTheme);
        localStorage.setItem('po-suite-theme', newTheme);
        document.documentElement.className = newTheme;
    };
    
    useEffect(() => {
        if(data?.projects && data.projects.length > 0 && !activeProjectId) {
            setActiveProjectId(data.projects[0].id);
        }
    }, [data, activeProjectId]);

    // --- Mutation Functions ---
    const addProject = async (newProjectData: Partial<Project>): Promise<Project | undefined> => {
        try {
            const newProject = await sendRequest('/api/projects', { arg: newProjectData }, 'POST');
            mutate((currentData) => ({ ...currentData!, projects: [...(currentData?.projects || []), newProject] }), false);
            return newProject;
        } catch (e) { console.error('Failed to add project', e); }
    };
    
    const updateProject = async (updatedProject: Partial<Project> & { id: string }) => {
        mutate((d) => ({ ...d!, projects: d!.projects.map(p => p.id === updatedProject.id ? {...p, ...updatedProject} : p) }), false);
        await sendRequest(`/api/projects/${updatedProject.id}`, { arg: updatedProject }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const deleteProject = async (projectId: string) => {
        mutate((d) => ({ ...d!, projects: d!.projects.filter(p => p.id !== projectId) }), false);
        await sendRequest(`/api/projects/${projectId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };

    const addPerson = async (newPerson: Person) => {
        const createdPerson = await sendRequest('/api/persons', { arg: newPerson }, 'POST');
        mutate((d) => ({ ...d!, persons: [...(d?.persons || []), createdPerson] }), false);
        return createdPerson;
    };
    
    const updatePerson = async (updatedPerson: Person) => {
        mutate((d) => ({ ...d!, persons: d!.persons.map(p => p.id === updatedPerson.id ? updatedPerson : p) }), false);
        await sendRequest(`/api/persons/${updatedPerson.id}`, { arg: updatedPerson }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const deletePerson = async (personId: string) => {
        mutate((d) => ({ ...d!, persons: d!.persons.filter(p => p.id !== personId) }), false);
        await sendRequest(`/api/persons/${personId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };

    const setGlobalEvents = async (events: GlobalEvent[]) => {
        mutate((d) => ({ ...d!, globalEvents: events }), false);
        await sendRequest('/api/global-events', { arg: events }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const deleteGlobalEvent = async (eventId: string) => {
        mutate((d) => ({ ...d!, globalEvents: d!.globalEvents.filter(e => e.id !== eventId) }), false);
        await sendRequest(`/api/global-events/${eventId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };

    const deletePersonalEvent = async ({ personId, eventId }: { personId: string; eventId: string }) => {
        mutate(d => {
            if (!d) return d;
            return {
                ...d,
                persons: d.persons.map(p => {
                    if (p.id === personId) {
                        return { ...p, events: (p.events || []).filter(e => e.id !== eventId) };
                    }
                    return p;
                })
            }
        }, false);
        await sendRequest(`/api/persons/${personId}/events/${eventId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };
    
    const setAllAllocations = async (allocations: ProjectAllocation[]) => {
        mutate((d) => ({ ...d!, projectAllocations: allocations }), false);
        await sendRequest('/api/allocations', { arg: allocations }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const setActualHours = async (hours: ActualHoursEntry[]) => {
        mutate((d) => ({ ...d!, actualHours: hours }), false);
        await sendRequest('/api/actual-hours', { arg: hours }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const addTeam = async (newTeamData: Partial<Team>) => {
        const newTeam = await sendRequest('/api/teams', { arg: newTeamData }, 'POST');
        mutate((d) => ({ ...d!, teams: [...(d?.teams || []), newTeam] }), false);
        return newTeam;
    };
    
    const updateTeam = async (updatedTeam: Partial<Team> & { id: string }) => {
        mutate((d) => ({ ...d!, teams: d!.teams.map(t => t.id === updatedTeam.id ? {...t, ...updatedTeam} : t) }), false);
        await sendRequest(`/api/teams/${updatedTeam.id}`, { arg: updatedTeam }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const deleteTeam = async (teamId: string) => {
        mutate((d) => ({ ...d!, teams: d!.teams.filter(t => t.id !== teamId) }), false);
        await sendRequest(`/api/teams/${teamId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };
    
    const setTeamMembers = async (teamMembers: TeamMember[]) => {
        mutate((d) => ({ ...d!, teamMembers }), false);
        await sendRequest('/api/team-members', { arg: teamMembers }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const setSprintPlans = async (sprintPlans: SprintPlan[]) => {
        mutate((d) => ({ ...d!, sprintPlans }), false);
        await sendRequest('/api/sprints', { arg: sprintPlans }, 'PUT').catch(e => console.error(e));
        mutate();
    };
    
    const updateSprintPlan = async (updatedSprintPlan: Partial<SprintPlan> & { id: string }) => {
        mutate((d) => ({ ...d!, sprintPlans: d!.sprintPlans.map(s => s.id === updatedSprintPlan.id ? {...s, ...updatedSprintPlan} : s) }), false);
        await sendRequest(`/api/sprints/${updatedSprintPlan.id}`, { arg: updatedSprintPlan }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const updateSprintEndDateAndCascade = async (payload: { sprintId: string; newEndDate: string; teamId: string; }) => {
        const { sprintId, newEndDate, teamId } = payload;
        mutate(currentData => {
            if (!currentData) return currentData;
            const changedSprint = currentData.sprintPlans.find(s => s.id === sprintId);
            if (!changedSprint) return currentData;
            const updatedChangedSprint = { ...changedSprint, endDate: newEndDate };
            const teamSprints = currentData.sprintPlans.filter(s => s.teamId === teamId);
            const recalculatedSprints = recalculateSprintsAfter(updatedChangedSprint, teamSprints);
            const otherSprints = currentData.sprintPlans.filter(s => s.id !== sprintId && !recalculatedSprints.some(rs => rs.id === s.id));
            return { ...currentData, sprintPlans: [...otherSprints, updatedChangedSprint, ...recalculatedSprints] };
        }, false);
        await sendRequest(`/api/sprints/cascade-update`, { arg: payload }, 'POST').catch(e => console.error(e));
        mutate();
    };

    const addProjectAssignment = async (newAssignment: ProjectAssignment) => {
        mutate((d) => ({ ...d!, projectAssignments: [...d!.projectAssignments, newAssignment] }), false);
        await sendRequest('/api/project-assignments', { arg: newAssignment }, 'POST').catch(e => console.error(e));
        mutate();
    };

    const updateProjectAssignment = async (updatedAssignment: ProjectAssignment) => {
        mutate((d) => ({ ...d!, projectAssignments: d!.projectAssignments.map(a => a.id === updatedAssignment.id ? updatedAssignment : a) }), false);
        await sendRequest(`/api/project-assignments/${updatedAssignment.id}`, { arg: updatedAssignment }, 'PUT').catch(e => console.error(e));
        mutate();
    };

    const deleteProjectAssignment = async (assignmentId: string) => {
        mutate((d) => ({ ...d!, projectAssignments: d!.projectAssignments.filter(a => a.id !== assignmentId) }), false);
        await sendRequest(`/api/project-assignments/${assignmentId}`, { arg: null }, 'DELETE').catch(e => console.error(e));
        mutate();
    };

    const contextValue: DataContextType = useMemo(() => ({
        data, isLoading, error, addProject, updateProject, deleteProject, updatePerson, addPerson,
        deletePerson, setGlobalEvents, deleteGlobalEvent, deletePersonalEvent, setAllAllocations,
        setActualHours, addTeam, updateTeam, deleteTeam, setTeamMembers, setSprintPlans,
        updateSprintPlan, updateSprintEndDateAndCascade, addProjectAssignment, updateProjectAssignment,
        deleteProjectAssignment, theme, setTheme, activeProjectId, setActiveProjectId
    }), [data, isLoading, error, theme, activeProjectId]);

    return (
        <DataContext.Provider value={contextValue}>
            {children}
        </DataContext.Provider>
    );
};

// --- Custom Hook ---
export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
